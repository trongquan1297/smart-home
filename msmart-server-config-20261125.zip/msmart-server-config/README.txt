Cấu hình máy chủ MSmart (lấy từ /opt/msmart trên server hiện tại, ngày 2026-11-25)

docker-compose.server.yml  -> /opt/msmart/docker-compose.server.yml
   Ghi đè docker-compose.yml của repo: backend :18080, zigbee-sim :18081, cast-sim :18082,
   Postgres không mở ra ngoài, Mosquitto chỉ 127.0.0.1. Đổi cổng nếu server mới không bị trùng.

env.template               -> /opt/msmart/.env   (chmod 600)
   Các giá trị bí mật đã được che "<ĐIỀN-GIÁ-TRỊ-TỪ-SERVER-CŨ>": POSTGRES_PASSWORD, JWT_SECRET,
   MQTT_PASSWORD_*, GATEWAY_TOKEN, CAST_GATEWAY_TOKEN, GOOGLE_OAUTH_CLIENT_SECRET.
   Chuyển server: chép NGUYÊN các giá trị cũ (đổi JWT_SECRET = mọi người bị đăng xuất;
   GATEWAY_TOKEN/CAST_GATEWAY_TOKEN phải khớp mã băm trong DB).
   Dựng mới từ đầu: sinh ngẫu nhiên (openssl rand -hex 32).

msmart-firewall.sh         -> /usr/local/sbin/msmart-firewall.sh   (chmod 755)
msmart-firewall.service    -> /etc/systemd/system/msmart-firewall.service
   Chỉ cho máy chuyển tiếp Cloudflare (PROXY=) vào cổng 18080. Sửa PROXY= nếu đổi máy chuyển tiếp.
   systemctl daemon-reload && systemctl enable --now msmart-firewall

Không có trong gói này (lấy riêng, không gửi qua chat/email):
   secrets/fcm.json, secrets/AuthKey_93VVKX9K85.p8  (chown 10001, chmod 400)
   bản dump DB, volume smarthome_zigbee-sim-data (sim_state.json: thiết bị căn hộ demo)
