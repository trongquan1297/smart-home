#!/bin/sh
# MSmart: backend (cổng 18080) chỉ nhận kết nối từ máy chuyển tiếp Cloudflare (10.60.1.231), vì backend tin header
# CF-Connecting-IP (TRUSTED_IP_HEADER) để giới hạn đăng nhập theo IP thật. Nguồn khác gửi header giả được nên phải chặn.
# Luật nằm trong chuỗi DOCKER-USER (Docker không tự xoá); chạy lại nhiều lần không bị trùng.
PROXY=10.60.1.231
PORT=18080
for ipt in iptables ip6tables; do
  $ipt -S DOCKER-USER >/dev/null 2>&1 || continue
  while $ipt -D DOCKER-USER -p tcp -m conntrack --ctorigdstport $PORT --ctdir ORIGINAL -m comment --comment msmart-backend -j DROP 2>/dev/null; do :; done
  while $ipt -D DOCKER-USER -p tcp -m conntrack --ctorigdstport $PORT --ctdir ORIGINAL -s $PROXY -m comment --comment msmart-backend -j RETURN 2>/dev/null; do :; done
done
iptables -I DOCKER-USER -p tcp -m conntrack --ctorigdstport $PORT --ctdir ORIGINAL -m comment --comment msmart-backend -j DROP
iptables -I DOCKER-USER -p tcp -m conntrack --ctorigdstport $PORT --ctdir ORIGINAL -s $PROXY -m comment --comment msmart-backend -j RETURN
ip6tables -S DOCKER-USER >/dev/null 2>&1 && ip6tables -I DOCKER-USER -p tcp -m conntrack --ctorigdstport $PORT --ctdir ORIGINAL -m comment --comment msmart-backend -j DROP
exit 0
