--
-- PostgreSQL database dump
--

\restrict sl7bpm6AuhbGMjmzg31f71rcWbPceePSYiprj3DEssjbMvAd8m8Zc1dECMcAc1Z

-- Dumped from database version 16.16
-- Dumped by pg_dump version 16.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _sqlx_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._sqlx_migrations (
    version bigint NOT NULL,
    description text NOT NULL,
    installed_on timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    checksum bytea NOT NULL,
    execution_time bigint NOT NULL
);


--
-- Name: cameras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cameras (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    home_id uuid NOT NULL,
    gateway_id uuid NOT NULL,
    room_id uuid,
    name text NOT NULL,
    host text NOT NULL,
    manufacturer text,
    model text,
    has_ptz boolean DEFAULT false NOT NULL,
    has_events boolean DEFAULT false NOT NULL,
    motion_alerts boolean DEFAULT true NOT NULL,
    online boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: command_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.command_log (
    id bigint NOT NULL,
    device_id uuid NOT NULL,
    home_id uuid NOT NULL,
    user_id uuid,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: command_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.command_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: command_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.command_log_id_seq OWNED BY public.command_log.id;


--
-- Name: device_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    home_id uuid NOT NULL,
    device_id uuid NOT NULL,
    key text NOT NULL,
    kind text NOT NULL,
    delay_s integer,
    source_device_id uuid,
    source_key text,
    source_state text,
    target_state text,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    speaker_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    speak_text text,
    CONSTRAINT device_rules_check CHECK ((((kind = 'link'::text) AND (source_device_id IS NOT NULL) AND (source_key IS NOT NULL) AND (source_state IS NOT NULL) AND (target_state IS NOT NULL)) OR ((kind <> 'link'::text) AND (delay_s IS NOT NULL)))),
    CONSTRAINT device_rules_delay_s_check CHECK (((delay_s >= 1) AND (delay_s <= 86400))),
    CONSTRAINT device_rules_kind_check CHECK ((kind = ANY (ARRAY['auto_off'::text, 'auto_on'::text, 'link'::text]))),
    CONSTRAINT device_rules_source_state_check CHECK ((source_state = ANY (ARRAY['ON'::text, 'OFF'::text]))),
    CONSTRAINT device_rules_target_state_check CHECK ((target_state = ANY (ARRAY['ON'::text, 'OFF'::text])))
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    home_id uuid NOT NULL,
    gateway_id uuid NOT NULL,
    room_id uuid,
    ieee_address text NOT NULL,
    friendly_name text NOT NULL,
    name text NOT NULL,
    vendor text,
    model text,
    kind text DEFAULT 'other'::text NOT NULL,
    exposes jsonb DEFAULT '[]'::jsonb NOT NULL,
    state jsonb DEFAULT '{}'::jsonb NOT NULL,
    online boolean DEFAULT false NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    description text,
    channels jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: gateways; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateways (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    home_id uuid NOT NULL,
    name text NOT NULL,
    token_hash text NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: home_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_invites (
    token_hash text NOT NULL,
    home_id uuid NOT NULL,
    role text NOT NULL,
    created_by uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    duration_hours integer,
    starts_at timestamp with time zone,
    CONSTRAINT home_invites_renter_duration CHECK (((role = 'renter'::text) = (duration_hours IS NOT NULL))),
    CONSTRAINT home_invites_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'member'::text, 'renter'::text, 'guest'::text])))
);


--
-- Name: home_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_members (
    home_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    valid_from timestamp with time zone,
    valid_until timestamp with time zone,
    duration_hours integer,
    CONSTRAINT home_members_renter_window CHECK (((role = 'renter'::text) = ((valid_from IS NOT NULL) AND (valid_until IS NOT NULL) AND (duration_hours IS NOT NULL)))),
    CONSTRAINT home_members_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'member'::text, 'renter'::text, 'guest'::text])))
);


--
-- Name: homes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.homes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    address text,
    timezone text DEFAULT 'Asia/Ho_Chi_Minh'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    active_scene_id uuid,
    active_since timestamp with time zone,
    geo_lat double precision,
    geo_lng double precision,
    geo_radius_m integer DEFAULT 150 NOT NULL,
    CONSTRAINT homes_geo_lat_check CHECK (((geo_lat >= ('-90'::integer)::double precision) AND (geo_lat <= (90)::double precision))),
    CONSTRAINT homes_geo_lng_check CHECK (((geo_lng >= ('-180'::integer)::double precision) AND (geo_lng <= (180)::double precision))),
    CONSTRAINT homes_geo_radius_m_check CHECK (((geo_radius_m >= 50) AND (geo_radius_m <= 2000)))
);


--
-- Name: member_presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_presence (
    home_id uuid NOT NULL,
    user_id uuid NOT NULL,
    inside boolean NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    home_id uuid NOT NULL,
    scene_id uuid,
    device_id uuid,
    kind text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    camera_id uuid
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_codes (
    code_hash text NOT NULL,
    client_id text NOT NULL,
    user_id uuid NOT NULL,
    redirect_uri text NOT NULL,
    scope text DEFAULT ''::text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    grant_id uuid
);


--
-- Name: oauth_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id text NOT NULL,
    user_id uuid NOT NULL,
    scope text DEFAULT ''::text NOT NULL,
    refresh_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: oauth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_tokens (
    token_hash text NOT NULL,
    grant_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: pending_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_actions (
    rule_id uuid NOT NULL,
    home_id uuid NOT NULL,
    device_id uuid NOT NULL,
    key text NOT NULL,
    state text NOT NULL,
    due_at timestamp with time zone NOT NULL,
    CONSTRAINT pending_actions_state_check CHECK ((state = ANY (ARRAY['ON'::text, 'OFF'::text])))
);


--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    platform text NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT push_tokens_platform_check CHECK ((platform = ANY (ARRAY['ios'::text, 'android'::text])))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    family_id uuid NOT NULL,
    family_started_at timestamp with time zone DEFAULT now() NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rooms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    home_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    icon text
);


--
-- Name: scenes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scenes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    home_id uuid NOT NULL,
    name text NOT NULL,
    icon text DEFAULT 'home'::text NOT NULL,
    actions jsonb DEFAULT '[]'::jsonb NOT NULL,
    auto_enabled boolean DEFAULT false NOT NULL,
    auto_time time without time zone,
    auto_days smallint[] DEFAULT '{1,2,3,4,5,6,7}'::smallint[] NOT NULL,
    last_run_at timestamp with time zone,
    last_status text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    alert_devices uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    auto_leave boolean DEFAULT false NOT NULL,
    speaker_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    speak_text text,
    CONSTRAINT scenes_auto_days_check CHECK (((cardinality(auto_days) >= 1) AND (cardinality(auto_days) <= 7))),
    CONSTRAINT scenes_check CHECK (((NOT auto_enabled) OR (auto_time IS NOT NULL)))
);


--
-- Name: speakers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.speakers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    home_id uuid NOT NULL,
    name text NOT NULL,
    cast_id text NOT NULL,
    host text,
    port integer DEFAULT 8009 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    gateway_id uuid,
    CONSTRAINT speakers_port_check CHECK (((port >= 1) AND (port <= 65535)))
);


--
-- Name: tenant_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_members (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tenant_members_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text])))
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_identities (
    provider text NOT NULL,
    subject text NOT NULL,
    user_id uuid NOT NULL,
    email text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone DEFAULT now() NOT NULL,
    apple_refresh_token text,
    apple_client_id text,
    CONSTRAINT user_identities_provider_check CHECK ((provider = ANY (ARRAY['google'::text, 'apple'::text])))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: command_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_log ALTER COLUMN id SET DEFAULT nextval('public.command_log_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Data for Name: _sqlx_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._sqlx_migrations (version, description, installed_on, success, checksum, execution_time) FROM stdin;
1	init	2026-11-13 10:33:48.017651+07	t	\\x2270b165ead83e6a8d2334589bc782655bdb87897a3204d4b2afaa9f9cbae4ef86e927d6c74e8f50bbf9414585dcaffe	32044458
2	device channels	2026-11-13 11:17:35.934244+07	t	\\x6b7dc0abb312c82ecf4adf581504b75b12efa9959cdc027dce8dacb7c20e05685dd6a8175cab0f1d162ab63922117ea6	1832583
3	room icon	2026-11-13 11:46:15.998057+07	t	\\x5dee28014916a34265da4990f77e9d9034bb0b7619eb1db55b28caa0e0f5c6b08e42db5bfefb945033cb5cfab6828834	1188209
4	refresh tokens	2026-11-13 13:38:09.453407+07	t	\\x2b6ac39e7c2924d4711c446e589c824c4f5eeb9713ebbba3cebab20195345819546e93c3231db738cc4c1e67644e4acf	13914000
5	scenes	2026-11-13 14:02:02.074274+07	t	\\x47d5376617f241acaed7436b5010295e728c2c4ce53efe72eee3c36314ad62d1056392b52be165555ba789eb91ac7c5b	7953208
6	renter access	2026-11-13 16:16:12.088505+07	t	\\xe14fb7a18df5483c88b6b183073f4d3ba4686fbe58bfd8219f56e671d03a4d17235cf8ee4d2bc7dd1f1663a3348054a2	4194542
7	alerts	2026-11-14 12:33:34.511196+07	t	\\x853d82c76202965a8cecc1c8693fda4de4279c95b026957c377a3276d433e4bebb59ebc28d41d4fa648c8548d167aa64	32286742
8	auto leave	2026-11-14 13:08:37.819669+07	t	\\x775c316f28cb21d53cb018c79b9fc004e9cfc7894bc561f15d1c0adc8827ee9aa23ffa60b040fd52dfb9bd8f931f27b0	15399901
9	device rules	2026-11-17 10:11:35.085533+07	t	\\x052856fe3dcbfe101b619ba728bdfb1f9b6db2e73c32ae52531d5e099c05db37079f8c8ea0cf56e3024935dcf03d7c3e	32921645
10	speakers	2026-11-17 11:24:59.14342+07	t	\\x23f0dd93f582c3673ec57bf0a06f185232281715b07961c6852fdc42a0c942e917293dbff2d818674a4dccbd94fa38bf	15544663
11	speaker gateway	2026-11-17 11:36:28.780747+07	t	\\x912df6fa49689250954764795ff8d634c3a5270ff71a0dfd6723a37e55190c60c8fed328a64cecc086850e64b387e731	3752321
12	cameras	2026-11-19 16:36:02.934363+07	t	\\x38e91e1c60eee860dfb0def6f28d2f8d8a858222f2e99e1366357fd15a6e63f6e93d3122d3e2a1ee91b740e943713219	15519593
13	oauth	2026-11-19 16:36:02.951034+07	t	\\xac5b4b1b128214ae37622abee018c1451fb505571ede8faee2bb41e0446cc48d4680b7937efaf768a009de264ce12395	24516660
14	user identities	2026-11-19 18:35:56.495437+07	t	\\x95daa87d9f6bd06a3e9d25b2d8698704227e2d09b13b1e4b980cfad8b97f369f7dd6b0a9ca43002ac323023aa7cae693	15597222
15	timezone	2026-11-19 22:23:54.643715+07	t	\\x79129319161ba9f3ecd1181c234c834e67ee4dbeee0efacb43f735685bb0d2a9771006d36a980fde0a8e3e74ed0d7932	9685609
16	apple tokens	2026-11-20 17:14:45.892286+07	t	\\x745fd0df39848f81f64269ac043f9b6746b3dc28f1882f2d3f438b1a739d516cad01001d1d2f0ec5349540b2236b62e1	6765078
\.


--
-- Data for Name: cameras; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cameras (id, home_id, gateway_id, room_id, name, host, manufacturer, model, has_ptz, has_events, motion_alerts, online, created_at) FROM stdin;
\.


--
-- Data for Name: command_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.command_log (id, device_id, home_id, user_id, payload, created_at) FROM stdin;
277	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:16:11.951644+07
278	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:16:16.169723+07
279	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:16:17.797279+07
4	365a612d-7ea2-471b-9981-869ec92e723e	728b0ae0-61ca-498a-a580-8ed0c52dde5c	d90f5d76-5db4-4421-8e83-b2ff84049f92	{"state_2": "TOGGLE"}	2026-11-13 10:54:59.627627+07
280	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:16:22.309561+07
281	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 21:17:38.01796+07
282	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-19 21:17:38.020387+07
283	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:17:44.648548+07
284	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:17:44.650333+07
285	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 21:17:50.086837+07
286	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-19 21:17:50.089643+07
287	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:17:55.103437+07
288	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:17:55.107057+07
289	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 21:18:23.49748+07
290	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:18:40.12715+07
291	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:18:57.307534+07
292	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:19:00.061211+07
293	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:19:02.174155+07
294	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-19 21:36:44.34739+07
295	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-19 21:36:48.971786+07
296	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:37:00.270143+07
297	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:37:06.703901+07
298	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-19 21:37:56.466907+07
299	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-19 21:37:56.628163+07
300	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-19 21:39:04.47955+07
301	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 21:39:48.802596+07
302	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:40:24.18419+07
303	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:40:40.39463+07
304	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:48:43.53922+07
305	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-19 21:48:46.709174+07
306	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-19 21:50:48.691649+07
307	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 21:51:59.251944+07
308	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-19 21:52:15.486128+07
309	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 21:53:15.666589+07
310	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:53:15.668938+07
311	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:53:15.670867+07
312	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:53:15.673181+07
313	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-19 21:53:15.674815+07
314	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:53:15.676114+07
315	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 21:53:15.67778+07
316	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 21:53:15.67906+07
317	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 22:11:29.134126+07
318	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 22:11:43.494909+07
319	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 22:12:05.297021+07
320	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 22:12:05.299347+07
321	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:12:05.301036+07
322	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-19 22:12:05.302272+07
323	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:12:05.303525+07
324	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:12:05.304806+07
325	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-19 22:12:48.410113+07
326	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 22:14:01.22906+07
327	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-19 22:14:01.231306+07
328	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:14:01.232698+07
329	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-19 22:14:01.234058+07
330	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:14:01.235437+07
331	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-19 22:14:01.236776+07
332	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-19 22:23:23.809615+07
333	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-19 22:32:52.643988+07
334	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 07:50:54.485189+07
335	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 08:23:22.750141+07
336	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 08:23:22.752669+07
337	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-20 08:23:22.75436+07
338	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 08:23:22.756101+07
339	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 08:23:22.757837+07
340	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 08:24:52.594217+07
341	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 08:24:52.596119+07
342	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 08:25:23.612502+07
343	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 08:25:23.614036+07
344	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-20 08:25:23.615146+07
345	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 08:25:23.616426+07
352	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 08:30:53.534041+07
346	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 08:25:23.617744+07
348	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 08:26:39.819307+07
351	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-20 08:30:53.53196+07
347	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 08:26:16.635099+07
349	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 08:26:39.954753+07
350	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 08:30:52.914916+07
353	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 08:30:53.535616+07
354	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 09:39:12.173027+07
355	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 09:50:03.004529+07
356	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 09:50:03.009506+07
357	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-20 09:50:03.011235+07
358	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-20 09:50:03.013043+07
359	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 09:50:03.014863+07
360	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-20 10:19:21.334279+07
361	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-20 10:19:23.064783+07
399	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 19:39:17.451946+07
401	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 19:51:03.772543+07
403	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-20 19:51:03.778063+07
404	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 19:51:03.78032+07
405	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 19:51:03.781756+07
407	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 19:51:03.784661+07
408	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 19:51:03.785823+07
409	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 19:51:04.018918+07
411	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-20 19:52:52.588647+07
412	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "TOGGLE"}	2026-11-20 19:53:02.711772+07
413	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-20 19:53:18.636388+07
414	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-20 19:53:20.006571+07
415	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-20 19:53:56.573274+07
416	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-20 20:08:56.930992+07
417	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 20:10:39.066966+07
418	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-20 20:15:36.606458+07
419	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 20:20:03.281993+07
420	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 20:28:35.818668+07
421	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_1": "TOGGLE"}	2026-11-20 21:15:47.42686+07
422	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_2": "TOGGLE"}	2026-11-20 21:15:49.578649+07
423	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_2": "TOGGLE"}	2026-11-20 21:15:53.91791+07
424	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_1": "TOGGLE"}	2026-11-20 21:16:47.64802+07
425	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state": "TOGGLE"}	2026-11-20 21:20:17.07428+07
426	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state": "TOGGLE"}	2026-11-20 21:20:57.187851+07
427	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 21:28:14.378117+07
428	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 21:28:16.298981+07
429	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:51:32.284569+07
430	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:52:28.314006+07
432	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:52:46.585498+07
433	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 21:52:46.587333+07
434	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 21:54:00.758587+07
436	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-20 21:54:00.763878+07
437	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:54:00.765282+07
438	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 21:54:00.766854+07
440	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:54:00.770373+07
441	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:54:00.771668+07
442	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 21:56:38.353353+07
443	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 21:56:38.574233+07
444	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 21:56:47.907042+07
446	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 21:56:48.883572+07
448	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-20 21:56:50.644315+07
449	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 21:56:50.646739+07
450	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-20 21:56:51.632011+07
451	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 21:56:51.634034+07
452	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 21:57:55.068032+07
454	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-20 21:57:55.072442+07
455	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:57:55.073994+07
456	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 21:57:55.075526+07
458	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:57:55.077891+07
459	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 21:57:55.078942+07
460	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 22:01:52.347564+07
462	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 22:01:53.274568+07
464	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 22:02:24.839896+07
466	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 22:02:37.901454+07
467	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-20 22:02:38.915328+07
468	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 22:02:39.946832+07
469	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 22:02:40.813021+07
472	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-20 22:03:29.994471+07
473	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 22:05:56.247034+07
475	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 22:05:56.252145+07
476	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "TOGGLE"}	2026-11-20 22:12:19.184526+07
477	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-20 22:12:23.25764+07
478	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "TOGGLE"}	2026-11-20 22:12:29.095541+07
479	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 22:13:18.304696+07
480	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:13:18.308811+07
482	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 22:13:19.295505+07
483	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:13:19.297231+07
485	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 22:13:23.318938+07
486	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 22:13:23.322164+07
488	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 22:13:24.703525+07
489	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 22:13:24.70549+07
492	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-20 22:13:41.236529+07
493	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-20 22:13:41.238917+07
496	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:13:51.276527+07
497	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-20 22:30:13.462348+07
498	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "OFF"}	2026-11-20 22:30:13.4654+07
499	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:30:13.467513+07
500	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:30:13.46967+07
501	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-20 22:30:13.47177+07
502	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-20 22:33:30.191154+07
503	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "ON"}	2026-11-20 22:33:30.705236+07
504	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_2": "OFF"}	2026-11-20 22:40:30.722394+07
505	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 22:54:21.643435+07
506	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 22:54:22.605668+07
507	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 22:54:23.505003+07
508	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	{"state_3": "TOGGLE"}	2026-11-20 22:55:01.182915+07
509	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-21 07:09:31.618791+07
510	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 07:43:41.73543+07
511	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 07:43:41.737271+07
512	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 07:43:41.73909+07
513	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 07:43:41.740714+07
514	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 07:43:41.742215+07
515	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-21 07:45:37.726624+07
516	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-21 08:15:55.554952+07
517	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 08:17:17.499711+07
518	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 08:17:17.50155+07
519	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 08:17:17.503455+07
520	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 08:17:17.505179+07
521	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 08:17:17.506692+07
522	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 08:20:10.638216+07
523	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 08:20:10.639938+07
524	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 08:20:10.641407+07
525	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 08:20:10.642643+07
526	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 08:20:10.643869+07
533	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-21 14:32:59.143368+07
534	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 14:39:55.740819+07
535	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 14:39:55.742457+07
536	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 14:39:55.744489+07
537	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 14:39:55.746334+07
538	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 14:39:55.747991+07
539	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 14:53:38.332334+07
540	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 14:53:38.333967+07
541	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 14:53:38.335318+07
542	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 14:53:38.336536+07
543	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 14:53:38.337736+07
544	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 16:41:15.929839+07
556	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 21:23:37.952893+07
582	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 00:05:15.307819+07
591	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-22 20:51:44.127267+07
547	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-21 18:01:46.256653+07
557	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 21:23:37.954696+07
562	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 21:27:01.051107+07
583	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 00:05:19.212054+07
593	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-22 20:58:11.026816+07
603	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-22 23:55:57.791203+07
611	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "OFF"}	2026-11-23 21:18:17.522504+07
616	ab6ded2c-b9b1-43dc-ae20-4def1df6fffe	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state_1": "TOGGLE"}	2026-11-23 21:18:36.918154+07
624	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-25 00:23:21.877693+07
548	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-21 18:01:49.016529+07
552	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 18:03:11.324402+07
558	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 21:23:37.956653+07
584	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-22 11:19:00.774738+07
594	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 21:23:10.439998+07
604	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-22 23:55:57.793038+07
612	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "TOGGLE"}	2026-11-23 21:18:18.930223+07
613	3be4014d-efe5-43a5-9ea3-bfc8a227aafe	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state_1": "TOGGLE"}	2026-11-23 21:18:23.601305+07
617	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "OFF"}	2026-11-23 21:18:41.920573+07
625	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-25 00:23:21.879217+07
549	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 18:03:11.310415+07
559	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-21 21:26:41.475505+07
560	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-21 21:26:44.156141+07
566	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 21:39:04.132158+07
571	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-21 21:39:04.145396+07
585	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-22 12:39:11.786075+07
595	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 21:23:15.93053+07
597	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "TOGGLE"}	2026-11-22 21:23:22.76439+07
605	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-22 23:55:57.794807+07
614	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "TOGGLE"}	2026-11-23 21:18:33.171809+07
615	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "TOGGLE"}	2026-11-23 21:18:34.567623+07
618	cfc70a3e-3783-4ea3-a4cc-92f9d6cf314e	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "OFF"}	2026-11-23 21:18:41.923534+07
627	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-25 08:18:36.760632+07
550	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 18:03:11.320482+07
565	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 21:39:04.129044+07
568	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-21 21:39:04.135806+07
572	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-21 21:39:04.146812+07
586	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "OFF"}	2026-11-22 12:39:13.57902+07
596	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 21:23:22.242168+07
606	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-23 08:12:23.052081+07
619	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	\N	{"state": "OFF"}	2026-11-23 21:18:41.924839+07
628	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-25 08:18:36.763127+07
551	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-21 18:03:11.322556+07
567	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "ON"}	2026-11-21 21:39:04.134012+07
570	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 21:39:04.144057+07
573	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-21 21:44:55.466469+07
574	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-21 21:45:03.287042+07
587	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF"}	2026-11-22 14:40:25.863577+07
598	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-22 22:33:30.341493+07
599	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 22:33:34.429872+07
607	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-23 08:12:23.054312+07
620	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-24 17:23:04.259965+07
629	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-25 08:18:36.765326+07
553	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 18:03:11.325832+07
569	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-21 21:39:04.140762+07
577	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-21 21:45:13.394136+07
588	cfc70a3e-3783-4ea3-a4cc-92f9d6cf314e	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-22 20:38:10.53363+07
592	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "ON"}	2026-11-22 20:51:44.129603+07
600	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-22 22:33:36.816935+07
608	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}	2026-11-23 08:12:23.056034+07
621	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-24 20:24:10.027097+07
630	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-25 08:18:36.767322+07
554	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state": "OFF"}	2026-11-21 21:23:37.949308+07
564	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 21:27:36.292732+07
580	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-21 23:07:54.683534+07
589	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-22 20:38:10.536809+07
601	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-22 23:55:57.786626+07
609	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-23 08:12:23.057988+07
622	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-25 00:23:21.873107+07
626	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-25 00:23:21.88071+07
631	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-25 08:18:36.768888+07
555	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	{"state_1": "OFF", "state_2": "OFF"}	2026-11-21 21:23:37.951246+07
561	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 21:27:01.048967+07
563	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-21 21:27:36.290324+07
575	2c50892d-29d3-48e2-9f82-d19d7c153b8e	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "TOGGLE"}	2026-11-21 21:45:04.808176+07
576	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-21 21:45:12.394877+07
578	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "TOGGLE"}	2026-11-21 21:45:17.327199+07
579	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "TOGGLE"}	2026-11-21 21:45:21.126238+07
581	1de602d8-fbb7-4675-966a-a66291cdc033	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_2": "TOGGLE"}	2026-11-21 23:07:55.78181+07
590	c02a6a8e-fa64-4450-aebc-c216bf81316d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_3": "ON"}	2026-11-22 20:51:44.122404+07
602	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-22 23:55:57.789228+07
610	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "OFF"}	2026-11-23 08:12:23.059775+07
623	672cc8fd-9b2c-402d-af29-7d2c0da7b15d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state_1": "OFF", "state_2": "OFF"}	2026-11-25 00:23:21.875441+07
527	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state": "ON", "brightness": 203}	2026-11-21 09:17:47.857322+07
528	3be4014d-efe5-43a5-9ea3-bfc8a227aafe	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state_1": "ON"}	2026-11-21 09:17:48.020849+07
529	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state": "OFF"}	2026-11-21 09:18:03.085551+07
530	cfc70a3e-3783-4ea3-a4cc-92f9d6cf314e	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state": "OFF"}	2026-11-21 09:18:03.089334+07
531	e7032d71-ca10-40c1-a394-2ae85e0d3876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state": "OFF"}	2026-11-21 09:18:03.091139+07
532	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	{"state": "ON", "brightness": 203}	2026-11-21 09:18:03.493611+07
545	6bad8227-ab69-4c75-90db-f31625b7f2e8	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	{"state": "ON"}	2026-11-21 17:12:06.816804+07
\.


--
-- Data for Name: device_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_rules (id, home_id, device_id, key, kind, delay_s, source_device_id, source_key, source_state, target_state, enabled, created_at, speaker_ids, speak_text) FROM stdin;
54520927-6c9e-4096-b007-e36f8517d346	2efeb3d2-7c8e-4763-9a5f-5784853467cb	9ecd9ea0-2409-4a5e-ba9c-e194b277027d	state	auto_off	1200	\N	\N	\N	\N	t	2026-11-20 19:53:39.783028+07	{}	\N
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, tenant_id, home_id, gateway_id, room_id, ieee_address, friendly_name, name, vendor, model, kind, exposes, state, online, last_seen_at, created_at, description, channels) FROM stdin;
afeec224-6575-438c-8ff8-514766ec7734	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b0000000021	door_sensor	door_sensor	VSmart	HS-SEDR00ZB-VNM	sensor	[{"name": "contact", "type": "binary", "access": 1, "property": "contact", "value_on": false, "value_off": true}, {"name": "battery_low", "type": "binary", "access": 1, "property": "battery_low", "value_on": true, "value_off": false}, {"name": "tamper", "type": "binary", "access": 1, "property": "tamper", "value_on": true, "value_off": false}]	{"tamper": false, "contact": false, "battery_low": false, "linkquality": 123}	t	2026-11-13 11:11:14.268768+07	2026-11-13 10:54:30.39018+07	\N	{}
dbb377f4-f324-4631-8159-dedf300a485f	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b0000000012	sw_2_gang	custom_name	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "linkquality": 188}	t	2026-11-13 11:06:35.410731+07	2026-11-13 10:54:30.388657+07	\N	{}
678382c2-121f-4d9c-8f70-2c51bab555b3	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b0000000022	occupancy_sensor	occupancy_sensor	VSmart	HS-SEOC00ZB-VNM	sensor	[{"name": "battery", "type": "numeric", "unit": "%", "access": 1, "property": "battery", "value_max": 100, "value_min": 0}, {"name": "occupancy", "type": "binary", "access": 1, "property": "occupancy", "value_on": true, "value_off": false}]	{"battery": 93, "occupancy": true, "linkquality": 157}	t	2026-11-13 11:11:14.271055+07	2026-11-13 10:54:30.390723+07	\N	{}
365a612d-7ea2-471b-9981-869ec92e723e	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b0000000013	sw_3_gang	sw_3_gang	VSmart	HS-SW300ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_3", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF", "linkquality": 197}	t	2026-11-13 11:06:29.372081+07	2026-11-13 10:54:30.389664+07	\N	{}
2a3fb609-f698-47eb-a2f9-4c7416250f6e	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b0000000011	sw_1_gang	sw_1_gang	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state": "ON", "linkquality": 90}	t	2026-11-13 11:09:37.927347+07	2026-11-13 10:54:30.386783+07	\N	{}
092d9377-d458-4ac0-98a1-fcb1982508cf	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	171fb96c-0737-4a29-9c33-c1c0cc4e0c12	0x348d13fffe41faa2	0x348d13fffe41faa2	Cảm biến hiện diện	VSmart	HS-SEOC00ZB-VNM	sensor	[{"name": "battery", "type": "numeric", "unit": "%", "label": "Battery", "access": 5, "category": "diagnostic", "property": "battery", "value_max": 100, "value_min": 0, "description": "Remaining battery in %"}, {"name": "occupancy", "type": "binary", "label": "Occupancy", "access": 5, "property": "occupancy", "value_on": true, "value_off": false, "description": "Indicates whether the device detected occupancy"}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"battery": 100, "last_seen": "2026-11-25T03:28:23.366Z", "occupancy": false, "linkquality": 220}	t	2026-11-25 10:28:23.495896+07	2026-11-20 09:38:45.543477+07	Occupancy sensor	{}
0c576739-0eb9-4165-8cbe-02c4af09fc38	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b768308633e	0x00124b768308633e	Công tắc phòng khách	VSmart	HS-SW300ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_3", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF", "linkquality": 170}	t	2026-11-13 11:09:05.971446+07	2026-11-13 11:09:05.970052+07	\N	{"state_1": {"name": "Đèn trần", "type": "light"}, "state_2": {"name": "Quạt", "type": "fan"}, "state_3": {"name": "", "type": "outlet"}}
56fe851f-3d68-48f1-8546-1c0651eba93c	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124bbc92e2c251	0x00124bbc92e2c251	0x00124bbc92e2c251	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state": "OFF", "linkquality": 181}	t	2026-11-13 11:08:54.046577+07	2026-11-13 11:08:54.041893+07	\N	{}
ecd876ce-2a71-45a6-8c75-17fec039d45c	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b9da54a9cf2	0x00124b9da54a9cf2	0x00124b9da54a9cf2	VSmart	HS-SW400ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_3", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_4", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF", "state_4": "OFF", "linkquality": 196}	t	2026-11-13 11:09:11.005106+07	2026-11-13 11:09:11.00404+07	\N	{}
b6eeb780-a7eb-458b-b491-1bcc53a46422	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124b00a06b4cda	0x00124b00a06b4cda	0x00124b00a06b4cda	VSmart	HS-SEDR00ZB-VNM	sensor	[{"name": "contact", "type": "binary", "access": 1, "property": "contact", "value_on": false, "value_off": true}, {"name": "battery_low", "type": "binary", "access": 1, "property": "battery_low", "value_on": true, "value_off": false}, {"name": "tamper", "type": "binary", "access": 1, "property": "tamper", "value_on": true, "value_off": false}]	{"tamper": false, "contact": true, "battery_low": false, "linkquality": 138}	t	2026-11-13 11:11:14.27292+07	2026-11-13 11:09:16.075041+07	\N	{}
4e88a0b2-32cc-4d73-9bbc-aacff061a3ea	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124bcd71440d10	0x00124bcd71440d10	0x00124bcd71440d10	VSmart	HS-SEOC00ZB-VNM	sensor	[{"name": "battery", "type": "numeric", "unit": "%", "access": 1, "property": "battery", "value_max": 100, "value_min": 0}, {"name": "occupancy", "type": "binary", "access": 1, "property": "occupancy", "value_on": true, "value_off": false}]	{"battery": 97, "occupancy": false, "linkquality": 167}	t	2026-11-13 11:11:14.274239+07	2026-11-13 11:09:20.833105+07	\N	{}
ac6983cd-e1ad-4b17-b8c4-4b57f5c0b264	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	e3ee0ad2-009c-48ac-93ae-ffb55b581415	\N	0x00124bfa47705b99	0x00124bfa47705b99	0x00124bfa47705b99	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "linkquality": 132}	t	2026-11-13 11:09:01.499779+07	2026-11-13 11:09:01.496428+07	\N	{}
2c50892d-29d3-48e2-9f82-d19d7c153b8e	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	b315ab85-c840-4792-9179-50c80522490a	0x348d13fffe6006d3	0x348d13fffe6006d3	Công tắc	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"name": "led_indicator_color_on", "type": "text", "label": "Led indicator color on", "access": 2, "property": "led_indicator_color_on", "description": "LED indicator color when switch is ON (hex format: #RRGGBB, e.g., #ff0000 for red)"}, {"name": "led_indicator_color_off", "type": "text", "label": "Led indicator color off", "access": 2, "property": "led_indicator_color_off", "description": "LED indicator color when switch is OFF (hex format: #RRGGBB, e.g., #ffffff for white)"}, {"name": "vibration_intensity", "type": "numeric", "unit": "%", "label": "Vibration intensity", "access": 2, "property": "vibration_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Button vibration intensity (0-100%)"}, {"name": "time_periods", "type": "composite", "label": "Time periods", "access": 2, "features": [{"name": "morning_start_hour", "type": "numeric", "unit": "h", "label": "Morning start hour", "access": 2, "property": "morning_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Morning period start hour (0-23)"}, {"name": "evening_start_hour", "type": "numeric", "unit": "h", "label": "Evening start hour", "access": 2, "property": "evening_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Evening period start hour (0-23)"}, {"name": "night_start_hour", "type": "numeric", "unit": "h", "label": "Night start hour", "access": 2, "property": "night_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Night period start hour (0-23)"}], "property": "time_periods", "description": "Time period settings for switch behavior. Morning must start before evening, evening must start before night."}, {"name": "morning_led_intensity", "type": "numeric", "unit": "%", "label": "Morning led intensity", "access": 2, "property": "morning_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for morning period (0-100%)"}, {"name": "evening_led_intensity", "type": "numeric", "unit": "%", "label": "Evening led intensity", "access": 2, "property": "evening_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for evening period (0-100%)"}, {"name": "night_led_intensity", "type": "numeric", "unit": "%", "label": "Night led intensity", "access": 2, "property": "night_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for night period (0-100%)"}, {"name": "led_brightness_levels", "type": "composite", "label": "Led brightness levels", "access": 2, "features": [{"name": "low_brightness_percent", "type": "numeric", "unit": "%", "label": "Low brightness percent", "access": 2, "property": "low_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Low brightness level percentage (0-100%)"}, {"name": "medium_brightness_percent", "type": "numeric", "unit": "%", "label": "Medium brightness percent", "access": 2, "property": "medium_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Medium brightness level percentage (0-100%)"}, {"name": "high_brightness_percent", "type": "numeric", "unit": "%", "label": "High brightness percent", "access": 2, "property": "high_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "High brightness level percentage (0-100%)"}], "property": "led_brightness_levels", "description": "LED brightness levels for different intensity settings. Low must be lower than medium, Medium must be lower than high."}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"state": "OFF", "last_seen": "2026-11-25T03:41:22.636Z", "linkquality": 220, "led_indicator_color_on": "#0bd6a0", "led_indicator_color_off": "#db34eb"}	t	2026-11-25 10:41:22.695995+07	2026-11-19 21:19:51.994317+07	Wall switch 1 gang	{"state": {"name": "Ban công", "type": "light"}}
82ef9317-3796-4cd5-a695-8da79835d04e	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	8d375758-9da9-433d-8f9b-1f330908b0d4	7810bf84-a854-4a1a-aed1-519f076c015d	E8:F6:0A:2C:78:C2	karofi-e8f60a2c78c2	Máy lọc nước	Karofi	TCM-40A00036595	purifier	[{"type": "numeric", "unit": "ppm", "access": 1, "property": "tds"}, {"type": "enum", "access": 1, "values": ["good", "fair", "poor", "unknown"], "property": "quality"}, {"type": "composite", "access": 1, "property": "filters"}, {"type": "numeric", "unit": "%", "access": 1, "property": "filter_min"}, {"type": "list", "access": 1, "property": "errors"}, {"type": "numeric", "access": 2, "property": "reset_filter", "value_max": 16, "value_min": 1}]	{"tds": 5, "errors": [], "filters": [{"no": 1, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}, {"no": 2, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}, {"no": 3, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}, {"no": 4, "percent": 100, "days_left": 1079, "life_days": 1080, "hours_left": 3599, "hours_total": 3600}, {"no": 5, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}, {"no": 6, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}, {"no": 7, "percent": 100, "days_left": 359, "life_days": 360, "hours_left": 1199, "hours_total": 1200}], "quality": "good", "filter_min": 100}	f	2026-11-25 10:39:05.958071+07	2026-11-21 17:58:54.431471+07	Water purifier (Bluetooth)	{}
7243d86e-17a7-48d5-983a-b46987f0d06b	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	6d547385-b419-473c-bd16-8e597ae94a97	0x00124b0000000021	Cảm biến cửa ra vào	Cảm biến cửa ra vào	VSmart	HS-SEDR00ZB-VNM	sensor	[{"name": "contact", "type": "binary", "access": 1, "property": "contact", "value_on": false, "value_off": true}, {"name": "battery_low", "type": "binary", "access": 1, "property": "battery_low", "value_on": true, "value_off": false}, {"name": "tamper", "type": "binary", "access": 1, "property": "tamper", "value_on": true, "value_off": false}]	{"tamper": false, "contact": true, "battery_low": false, "linkquality": 197}	t	2026-11-25 10:41:31.594133+07	2026-11-21 09:17:19.810901+07	Door/window sensor	{}
3be4014d-efe5-43a5-9ea3-bfc8a227aafe	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	6d547385-b419-473c-bd16-8e597ae94a97	0x00124bd3ecc6f5d8	Công tắc phòng khách 1	Công tắc phòng khách 1	VSmart	HS-SW300ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "3", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "3", "property": "state_3", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF", "linkquality": 84}	t	2026-11-23 21:18:23.644687+07	2026-11-21 09:17:19.819892+07	Wall switch 3 gang	{}
ab6ded2c-b9b1-43dc-ae20-4def1df6fffe	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	e04fb436-aee8-4c49-a368-d031775a4152	0x00124b6632417cd4	Công tắc phòng ngủ	Công tắc phòng ngủ	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "ON", "state_2": "OFF", "linkquality": 159}	t	2026-11-23 21:18:36.919429+07	2026-11-21 09:17:19.821342+07	Wall switch 2 gang	{}
129da822-b042-4ba8-8d6c-8088cf9aa672	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	e04fb436-aee8-4c49-a368-d031775a4152	0x00124b0000000022	Cảm biến hiện diện	Cảm biến hiện diện	VSmart	HS-SEOC00ZB-VNM	sensor	[{"name": "battery", "type": "numeric", "unit": "%", "access": 1, "property": "battery", "value_max": 100, "value_min": 0}, {"name": "occupancy", "type": "binary", "access": 1, "property": "occupancy", "value_on": true, "value_off": false}]	{"battery": 1, "occupancy": true, "linkquality": 182}	t	2026-11-25 10:41:31.596137+07	2026-11-21 09:17:19.812989+07	Occupancy sensor	{}
cfc70a3e-3783-4ea3-a4cc-92f9d6cf314e	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	8d8e4422-06a9-47a7-88ee-da2dedc1cc1b	0x00124bdd35d0ddaf	Bình nóng lạnh	Bình nóng lạnh	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state": "OFF", "linkquality": 109}	t	2026-11-23 21:18:41.961422+07	2026-11-21 09:17:19.814787+07	Wall switch 1 gang	{"state": {"name": "", "type": "outlet"}}
e7032d71-ca10-40c1-a394-2ae85e0d3876	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	0cdb8e7e-2d60-47bb-929d-c255bc51d771	0x00124bd74973202b	Đèn ban công	Đèn ban công	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state": "OFF", "linkquality": 90}	t	2026-11-23 21:18:41.963873+07	2026-11-21 09:17:19.822788+07	Wall switch 1 gang	{"state": {"name": "", "type": "light"}}
c02a6a8e-fa64-4450-aebc-c216bf81316d	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	171fb96c-0737-4a29-9c33-c1c0cc4e0c12	0xd4fe28fffebdc3c5	0xd4fe28fffebdc3c5	Công tắc phòng khách	VSmart	HS-SW300ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "3", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "3", "property": "state_3", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"name": "led_indicator_color_on", "type": "text", "label": "Led indicator color on", "access": 2, "property": "led_indicator_color_on", "description": "LED indicator color when switch is ON (hex format: #RRGGBB, e.g., #ff0000 for red)"}, {"name": "led_indicator_color_off", "type": "text", "label": "Led indicator color off", "access": 2, "property": "led_indicator_color_off", "description": "LED indicator color when switch is OFF (hex format: #RRGGBB, e.g., #ffffff for white)"}, {"name": "vibration_intensity", "type": "numeric", "unit": "%", "label": "Vibration intensity", "access": 2, "property": "vibration_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Button vibration intensity (0-100%)"}, {"name": "time_periods", "type": "composite", "label": "Time periods", "access": 2, "features": [{"name": "morning_start_hour", "type": "numeric", "unit": "h", "label": "Morning start hour", "access": 2, "property": "morning_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Morning period start hour (0-23)"}, {"name": "evening_start_hour", "type": "numeric", "unit": "h", "label": "Evening start hour", "access": 2, "property": "evening_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Evening period start hour (0-23)"}, {"name": "night_start_hour", "type": "numeric", "unit": "h", "label": "Night start hour", "access": 2, "property": "night_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Night period start hour (0-23)"}], "property": "time_periods", "description": "Time period settings for switch behavior. Morning must start before evening, evening must start before night."}, {"name": "morning_led_intensity", "type": "numeric", "unit": "%", "label": "Morning led intensity", "access": 2, "property": "morning_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for morning period (0-100%)"}, {"name": "evening_led_intensity", "type": "numeric", "unit": "%", "label": "Evening led intensity", "access": 2, "property": "evening_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for evening period (0-100%)"}, {"name": "night_led_intensity", "type": "numeric", "unit": "%", "label": "Night led intensity", "access": 2, "property": "night_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for night period (0-100%)"}, {"name": "led_brightness_levels", "type": "composite", "label": "Led brightness levels", "access": 2, "features": [{"name": "low_brightness_percent", "type": "numeric", "unit": "%", "label": "Low brightness percent", "access": 2, "property": "low_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Low brightness level percentage (0-100%)"}, {"name": "medium_brightness_percent", "type": "numeric", "unit": "%", "label": "Medium brightness percent", "access": 2, "property": "medium_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Medium brightness level percentage (0-100%)"}, {"name": "high_brightness_percent", "type": "numeric", "unit": "%", "label": "High brightness percent", "access": 2, "property": "high_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "High brightness level percentage (0-100%)"}], "property": "led_brightness_levels", "description": "LED brightness levels for different intensity settings. Low must be lower than medium, Medium must be lower than high."}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"state_1": "OFF", "state_2": "OFF", "state_3": "OFF", "last_seen": "2026-11-25T03:41:40.349Z", "linkquality": 120, "vibration_intensity": 84, "led_indicator_color_on": "#0bd6a0", "led_indicator_color_off": "#db34eb"}	t	2026-11-25 10:41:40.407416+07	2026-11-19 21:41:58.077037+07	Wall switch 3 gang	{"state_1": {"name": "Phòng khách", "type": "light"}, "state_2": {"name": "Quạt trần", "type": "fan"}, "state_3": {"name": "Đèn ngủ", "type": "light"}}
9ecd9ea0-2409-4a5e-ba9c-e194b277027d	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	4b06d730-f1a1-463d-a065-0617172efe37	0x348d13fffe60cd6f	0x348d13fffe60cd6f	Công tắc phòng tắm	VSmart	HS-SW100ZB-VNM	switch	[{"type": "switch", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"name": "led_indicator_color_on", "type": "text", "label": "Led indicator color on", "access": 2, "property": "led_indicator_color_on", "description": "LED indicator color when switch is ON (hex format: #RRGGBB, e.g., #ff0000 for red)"}, {"name": "led_indicator_color_off", "type": "text", "label": "Led indicator color off", "access": 2, "property": "led_indicator_color_off", "description": "LED indicator color when switch is OFF (hex format: #RRGGBB, e.g., #ffffff for white)"}, {"name": "vibration_intensity", "type": "numeric", "unit": "%", "label": "Vibration intensity", "access": 2, "property": "vibration_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Button vibration intensity (0-100%)"}, {"name": "time_periods", "type": "composite", "label": "Time periods", "access": 2, "features": [{"name": "morning_start_hour", "type": "numeric", "unit": "h", "label": "Morning start hour", "access": 2, "property": "morning_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Morning period start hour (0-23)"}, {"name": "evening_start_hour", "type": "numeric", "unit": "h", "label": "Evening start hour", "access": 2, "property": "evening_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Evening period start hour (0-23)"}, {"name": "night_start_hour", "type": "numeric", "unit": "h", "label": "Night start hour", "access": 2, "property": "night_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Night period start hour (0-23)"}], "property": "time_periods", "description": "Time period settings for switch behavior. Morning must start before evening, evening must start before night."}, {"name": "morning_led_intensity", "type": "numeric", "unit": "%", "label": "Morning led intensity", "access": 2, "property": "morning_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for morning period (0-100%)"}, {"name": "evening_led_intensity", "type": "numeric", "unit": "%", "label": "Evening led intensity", "access": 2, "property": "evening_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for evening period (0-100%)"}, {"name": "night_led_intensity", "type": "numeric", "unit": "%", "label": "Night led intensity", "access": 2, "property": "night_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for night period (0-100%)"}, {"name": "led_brightness_levels", "type": "composite", "label": "Led brightness levels", "access": 2, "features": [{"name": "low_brightness_percent", "type": "numeric", "unit": "%", "label": "Low brightness percent", "access": 2, "property": "low_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Low brightness level percentage (0-100%)"}, {"name": "medium_brightness_percent", "type": "numeric", "unit": "%", "label": "Medium brightness percent", "access": 2, "property": "medium_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Medium brightness level percentage (0-100%)"}, {"name": "high_brightness_percent", "type": "numeric", "unit": "%", "label": "High brightness percent", "access": 2, "property": "high_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "High brightness level percentage (0-100%)"}], "property": "led_brightness_levels", "description": "LED brightness levels for different intensity settings. Low must be lower than medium, Medium must be lower than high."}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"state": "OFF", "last_seen": "2026-11-25T03:41:07.144Z", "linkquality": 220, "night_led_intensity": 73, "vibration_intensity": 80, "evening_led_intensity": 70, "led_indicator_color_on": "#0bd6a0", "led_indicator_color_off": "#db34eb"}	t	2026-11-25 10:41:07.206881+07	2026-11-19 21:49:17.198079+07	Wall switch 1 gang	{"state": {"name": "Bình nóng lạnh", "type": "water_heater"}}
9ca0caa0-a25b-4949-8cd4-4bfb861c5f9a	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	8d8e4422-06a9-47a7-88ee-da2dedc1cc1b	0x00124bc603018fca	Công tắc cửa nhà vệ sinh	Công tắc cửa nhà vệ sinh	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}]}]	{"state_1": "OFF", "state_2": "OFF", "linkquality": 98}	t	2026-11-21 23:02:59.142987+07	2026-11-21 09:17:19.818014+07	Wall switch 2 gang	{}
6bad8227-ab69-4c75-90db-f31625b7f2e8	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	5b21d37f-a180-4358-82ad-c2c51903f38d	6d547385-b419-473c-bd16-8e597ae94a97	0x00124bc516fb9a88	Đèn trần phòng khách	Đèn trần phòng khách	IKEA	LED1623G12	light	[{"type": "light", "features": [{"name": "state", "type": "binary", "access": 7, "property": "state", "value_on": "ON", "value_off": "OFF", "value_toggle": "TOGGLE"}, {"name": "brightness", "type": "numeric", "access": 7, "property": "brightness", "value_max": 254, "value_min": 0}]}]	{"state": "OFF", "brightness": 203, "linkquality": 168}	t	2026-11-23 21:18:41.920325+07	2026-11-21 09:17:19.825902+07	TRADFRI LED bulb E27 dimmable	{}
aaad431d-119c-4a97-9ed0-ed5c152411b6	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	171fb96c-0737-4a29-9c33-c1c0cc4e0c12	0x54dce9fffe0e8c31	0x54dce9fffe0e8c31	Cảm biến cửa	VSmart	HS-SEDR00ZB-VNM	sensor	[{"name": "contact", "type": "binary", "label": "Contact", "access": 1, "property": "contact", "value_on": false, "value_off": true, "description": "Indicates whether the device is opened or closed"}, {"name": "battery_low", "type": "binary", "label": "Battery low", "access": 1, "category": "diagnostic", "property": "battery_low", "value_on": true, "value_off": false, "description": "Indicates whether the battery of the device is almost empty"}, {"name": "tamper", "type": "binary", "label": "Tamper", "access": 1, "category": "diagnostic", "property": "tamper", "value_on": true, "value_off": false, "description": "Indicates whether the device is tampered"}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"tamper": false, "contact": true, "last_seen": "2026-11-25T03:36:21.113Z", "battery_low": false, "linkquality": 120}	t	2026-11-25 10:36:21.207403+07	2026-11-20 08:07:13.305186+07	Door/window sensor	{}
672cc8fd-9b2c-402d-af29-7d2c0da7b15d	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	7810bf84-a854-4a1a-aed1-519f076c015d	0x348d13fffe5fb4bd	0x348d13fffe5fb4bd	Công tắc bếp	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"name": "led_indicator_color_on", "type": "text", "label": "Led indicator color on", "access": 2, "property": "led_indicator_color_on", "description": "LED indicator color when switch is ON (hex format: #RRGGBB, e.g., #ff0000 for red)"}, {"name": "led_indicator_color_off", "type": "text", "label": "Led indicator color off", "access": 2, "property": "led_indicator_color_off", "description": "LED indicator color when switch is OFF (hex format: #RRGGBB, e.g., #ffffff for white)"}, {"name": "vibration_intensity", "type": "numeric", "unit": "%", "label": "Vibration intensity", "access": 2, "property": "vibration_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Button vibration intensity (0-100%)"}, {"name": "time_periods", "type": "composite", "label": "Time periods", "access": 2, "features": [{"name": "morning_start_hour", "type": "numeric", "unit": "h", "label": "Morning start hour", "access": 2, "property": "morning_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Morning period start hour (0-23)"}, {"name": "evening_start_hour", "type": "numeric", "unit": "h", "label": "Evening start hour", "access": 2, "property": "evening_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Evening period start hour (0-23)"}, {"name": "night_start_hour", "type": "numeric", "unit": "h", "label": "Night start hour", "access": 2, "property": "night_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Night period start hour (0-23)"}], "property": "time_periods", "description": "Time period settings for switch behavior. Morning must start before evening, evening must start before night."}, {"name": "morning_led_intensity", "type": "numeric", "unit": "%", "label": "Morning led intensity", "access": 2, "property": "morning_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for morning period (0-100%)"}, {"name": "evening_led_intensity", "type": "numeric", "unit": "%", "label": "Evening led intensity", "access": 2, "property": "evening_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for evening period (0-100%)"}, {"name": "night_led_intensity", "type": "numeric", "unit": "%", "label": "Night led intensity", "access": 2, "property": "night_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for night period (0-100%)"}, {"name": "led_brightness_levels", "type": "composite", "label": "Led brightness levels", "access": 2, "features": [{"name": "low_brightness_percent", "type": "numeric", "unit": "%", "label": "Low brightness percent", "access": 2, "property": "low_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Low brightness level percentage (0-100%)"}, {"name": "medium_brightness_percent", "type": "numeric", "unit": "%", "label": "Medium brightness percent", "access": 2, "property": "medium_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Medium brightness level percentage (0-100%)"}, {"name": "high_brightness_percent", "type": "numeric", "unit": "%", "label": "High brightness percent", "access": 2, "property": "high_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "High brightness level percentage (0-100%)"}], "property": "led_brightness_levels", "description": "LED brightness levels for different intensity settings. Low must be lower than medium, Medium must be lower than high."}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"state_1": "OFF", "state_2": "OFF", "last_seen": "2026-11-25T03:40:51.557Z", "linkquality": 136, "led_indicator_color_on": "#0bd6a0", "led_indicator_color_off": "#db34eb"}	t	2026-11-25 10:40:51.617738+07	2026-11-19 21:15:01.954786+07	Wall switch 2 gang	{"state_1": {"name": "Đèn bếp", "type": "light"}, "state_2": {"name": "Đèn bàn ăn", "type": "light"}}
1de602d8-fbb7-4675-966a-a66291cdc033	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	c1e12dd7-e557-4de6-a141-850a1c0125b9	4b06d730-f1a1-463d-a065-0617172efe37	0x348d13fffe5fb58f	0x348d13fffe5fb58f	Công tắc phòng tắm	VSmart	HS-SW200ZB-VNM	switch	[{"type": "switch", "endpoint": "1", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "1", "property": "state_1", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"type": "switch", "endpoint": "2", "features": [{"name": "state", "type": "binary", "label": "State", "access": 7, "endpoint": "2", "property": "state_2", "value_on": "ON", "value_off": "OFF", "description": "On/off state of the switch", "value_toggle": "TOGGLE"}]}, {"name": "led_indicator_color_on", "type": "text", "label": "Led indicator color on", "access": 2, "property": "led_indicator_color_on", "description": "LED indicator color when switch is ON (hex format: #RRGGBB, e.g., #ff0000 for red)"}, {"name": "led_indicator_color_off", "type": "text", "label": "Led indicator color off", "access": 2, "property": "led_indicator_color_off", "description": "LED indicator color when switch is OFF (hex format: #RRGGBB, e.g., #ffffff for white)"}, {"name": "vibration_intensity", "type": "numeric", "unit": "%", "label": "Vibration intensity", "access": 2, "property": "vibration_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Button vibration intensity (0-100%)"}, {"name": "time_periods", "type": "composite", "label": "Time periods", "access": 2, "features": [{"name": "morning_start_hour", "type": "numeric", "unit": "h", "label": "Morning start hour", "access": 2, "property": "morning_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Morning period start hour (0-23)"}, {"name": "evening_start_hour", "type": "numeric", "unit": "h", "label": "Evening start hour", "access": 2, "property": "evening_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Evening period start hour (0-23)"}, {"name": "night_start_hour", "type": "numeric", "unit": "h", "label": "Night start hour", "access": 2, "property": "night_start_hour", "value_max": 23, "value_min": 0, "value_step": 1, "description": "Night period start hour (0-23)"}], "property": "time_periods", "description": "Time period settings for switch behavior. Morning must start before evening, evening must start before night."}, {"name": "morning_led_intensity", "type": "numeric", "unit": "%", "label": "Morning led intensity", "access": 2, "property": "morning_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for morning period (0-100%)"}, {"name": "evening_led_intensity", "type": "numeric", "unit": "%", "label": "Evening led intensity", "access": 2, "property": "evening_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for evening period (0-100%)"}, {"name": "night_led_intensity", "type": "numeric", "unit": "%", "label": "Night led intensity", "access": 2, "property": "night_led_intensity", "value_max": 100, "value_min": 0, "value_step": 1, "description": "LED intensity for night period (0-100%)"}, {"name": "led_brightness_levels", "type": "composite", "label": "Led brightness levels", "access": 2, "features": [{"name": "low_brightness_percent", "type": "numeric", "unit": "%", "label": "Low brightness percent", "access": 2, "property": "low_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Low brightness level percentage (0-100%)"}, {"name": "medium_brightness_percent", "type": "numeric", "unit": "%", "label": "Medium brightness percent", "access": 2, "property": "medium_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "Medium brightness level percentage (0-100%)"}, {"name": "high_brightness_percent", "type": "numeric", "unit": "%", "label": "High brightness percent", "access": 2, "property": "high_brightness_percent", "value_max": 100, "value_min": 0, "value_step": 1, "description": "High brightness level percentage (0-100%)"}], "property": "led_brightness_levels", "description": "LED brightness levels for different intensity settings. Low must be lower than medium, Medium must be lower than high."}, {"name": "linkquality", "type": "numeric", "unit": "lqi", "label": "Linkquality", "access": 1, "category": "diagnostic", "property": "linkquality", "value_max": 255, "value_min": 0, "description": "Link quality (signal strength)"}]	{"state_1": "OFF", "state_2": "OFF", "last_seen": "2026-11-25T03:41:21.879Z", "linkquality": 192, "led_indicator_color_on": "#0bd6a0", "led_indicator_color_off": "#db34eb"}	t	2026-11-25 10:41:21.938559+07	2026-11-19 21:25:37.987531+07	Wall switch 2 gang	{"state_1": {"name": "Đèn phòng tắm", "type": "light"}, "state_2": {"name": "Quạt hút mùi", "type": "fan"}}
\.


--
-- Data for Name: gateways; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateways (id, tenant_id, home_id, name, token_hash, last_seen_at, created_at) FROM stdin;
e3ee0ad2-009c-48ac-93ae-ffb55b581415	911236fb-22ec-448b-a599-be539a6e8665	728b0ae0-61ca-498a-a580-8ed0c52dde5c	Raspberry Pi 3	316daf18e7aed294f18566bc268828ae2e54b4e2296502f06ec3de938bb04b61	2026-11-13 11:10:59.361423+07	2026-11-13 10:33:49.606736+07
5b21d37f-a180-4358-82ad-c2c51903f38d	aa0cab41-42bd-45f8-87da-dd066cb90080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Bộ điều khiển	ce73ec53c682bedf4463261a358285a815717face3bd9c3e3aaff6abe99fcdbe	2026-11-25 10:41:29.111625+07	2026-11-21 09:17:09.205834+07
8d375758-9da9-433d-8f9b-1f330908b0d4	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Addon camera & máy lọc nước	fb0bde150e60200d6af85dc9d53205415cc8fbbcdd3fdd2afefb98916e0f0850	2026-11-25 10:41:35.914718+07	2026-11-21 16:55:32.072616+07
d804977f-e69e-4ddd-9e7d-5aea428fa46d	e665bb28-ac94-4a20-ad8a-33bf0c109fde	22b0f8c1-1a7c-4f83-9a23-01c5dceff230	Raspberry Pi	4b3d5d1b12b0e96b74cf81e4a7b23ccc6153d73adf86986ea53536bf7d95e7ba	\N	2026-11-13 15:56:38.131946+07
c1e12dd7-e557-4de6-a141-850a1c0125b9	e665bb28-ac94-4a20-ad8a-33bf0c109fde	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Pi 4	92a721f6e55fb39d2588386bca5bfd16afaefc6d5f5d426e758778ea2bcb220e	2026-11-25 10:41:38.554121+07	2026-11-19 13:09:36.70284+07
\.


--
-- Data for Name: home_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_invites (token_hash, home_id, role, created_by, expires_at, used_at, duration_hours, starts_at) FROM stdin;
a6776f9484d36135991e20b8d3b5579679fa28aced73d095922d2d63ff738f6d	728b0ae0-61ca-498a-a580-8ed0c52dde5c	guest	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 10:34:04.578197+07	\N	\N	\N
5eb8b905c0de080a6779f544d0318523c107d039459714f66d22bd6ee10721e8	728b0ae0-61ca-498a-a580-8ed0c52dde5c	guest	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 10:34:21.869074+07	\N	\N	\N
ca0b3d54133b76e9a0f65564fae714bec063b7e4648e2775cf1dee18bdb8a807	728b0ae0-61ca-498a-a580-8ed0c52dde5c	guest	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 10:34:37.472388+07	2026-11-13 10:34:37.488714+07	\N	\N
89a0b62f8e737ecebe1508095426684a1ea01e83f50f71c007ef80f644563196	2efeb3d2-7c8e-4763-9a5f-5784853467cb	member	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 13:36:07.742861+07	\N	\N	\N
3ff6e654bc0a51951397e7da18492ac43e89c4c6fbda8b8cb7dfcfd912064560	2efeb3d2-7c8e-4763-9a5f-5784853467cb	guest	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 13:46:52.228969+07	2026-11-13 13:47:35.314453+07	\N	\N
d22520453a22d1006b80e1b30c71d02023479d710617ada17967d7b9f0736ebe	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:16:25.514768+07	2026-11-13 16:16:25.516898+07	2	\N
bd4651cb714835934477a9151c68e51af876fca33052c105fe7cbc9c82aad2e5	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:16:27.093719+07	2026-11-13 16:16:27.095554+07	3	2026-11-14 16:16:27+07
d42e096cce1cb059a06bfd859be5dbe693dde6a815bc525ac20c672423e49dbc	728b0ae0-61ca-498a-a580-8ed0c52dde5c	member	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:16:37.389212+07	2026-11-13 16:16:37.391302+07	\N	\N
8525f659ee028329e48b03fb05a6e96186a216229766179dcd0155618143911e	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:18:41.740212+07	2026-11-13 16:18:41.742134+07	2	\N
41b4787dbbf8c5176956735d8e4c038393dd0f7760736a5039c78b5151ca379a	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:18:44.553974+07	2026-11-13 16:18:44.556443+07	3	2026-11-14 16:18:44+07
38b4a185781cb1a2f6ce4f74c78fa169eb36c0a4d9e686012cf46cdced9e3621	728b0ae0-61ca-498a-a580-8ed0c52dde5c	member	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:18:54.772948+07	2026-11-13 16:18:54.775229+07	\N	\N
771989d12259d6c9aba0b2c02be9248c0db53f5032fc15f6b0ffd817da404ea0	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:21:30.618264+07	2026-11-13 16:21:30.624885+07	26	\N
f4a0c9e45d070fd0a13a28cb83540b4e20430b712e93f602dfd2187d413cd98e	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:22:46.997373+07	2026-11-13 16:22:47.001343+07	26	\N
af4725b4dd2c4dd5d2e5f92757795ffbfe892a3527907489e200d620dc8bc4ae	728b0ae0-61ca-498a-a580-8ed0c52dde5c	renter	d90f5d76-5db4-4421-8e83-b2ff84049f92	2026-11-20 16:23:00.983459+07	2026-11-13 16:23:00.986465+07	3	\N
3d7c4e31a4eaa02df859dd7975a08318f968f100c51808f5bc28a46e649e263b	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 16:36:36.940728+07	2026-11-13 16:37:00.522733+07	24	\N
ce0d8ecf93ee1ad870e697106d0d2e2f1b1ab062cd3d08f3f6c692b4435ce2c6	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 17:24:29.146504+07	2026-11-13 17:24:40.742898+07	24	2026-11-13 18:30:00+07
f5873b2a52a15278da407339723ddf362e306c89a27dfe1e404f02c15ad36070	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 17:53:38.106654+07	2026-11-13 17:53:46.350612+07	24	2026-11-13 18:58:00+07
e49e20594e936a5a0c1f53278f6dc46267f391d032388bef14d39b2fc785c516	2efeb3d2-7c8e-4763-9a5f-5784853467cb	member	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 17:57:40.789448+07	\N	\N	\N
c91a997850207f62105e6b650997c587e5fffc365384457b172032514c14baf3	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-20 17:58:05.95094+07	2026-11-13 17:58:11.891989+07	24	2026-11-13 17:59:00+07
ecf3c41e86b9be9be0a99327bceffcbf320c87012622295a6afcffe52b8c4487	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-21 22:49:10.348008+07	2026-11-14 22:50:13.585897+07	24	\N
2a92cb08e98c94eda82132e23f0ee13c896883a981230cac6dd69713e2d96b6a	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-27 19:35:36.21339+07	\N	24	\N
fbed8d55a0e13a9e2be1ecafc4d3b37d27f04b1d33258e9b4a4136213fe3bfd4	2efeb3d2-7c8e-4763-9a5f-5784853467cb	renter	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	2026-11-27 19:35:58.505508+07	2026-11-20 19:41:21.886771+07	12	\N
4e9b6a19e8413211e7376ae521f0cd836f2c10f262bb83d90dbbc909f2dbac12	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	member	1398ff97-2866-4c04-b061-7e7abf3d38e0	2026-11-30 09:33:36.092332+07	\N	\N	\N
f720af642faead9b33ee320d0360c6af5a76ccba35125b16b28315bc4f6709bf	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	member	1398ff97-2866-4c04-b061-7e7abf3d38e0	2026-11-30 21:17:13.368452+07	2026-11-23 21:18:07.196474+07	\N	\N
\.


--
-- Data for Name: home_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_members (home_id, user_id, role, created_at, valid_from, valid_until, duration_hours) FROM stdin;
728b0ae0-61ca-498a-a580-8ed0c52dde5c	d90f5d76-5db4-4421-8e83-b2ff84049f92	owner	2026-11-13 10:33:49.573742+07	\N	\N	\N
728b0ae0-61ca-498a-a580-8ed0c52dde5c	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	guest	2026-11-13 10:34:37.488714+07	\N	\N	\N
2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	owner	2026-11-13 10:59:09.546283+07	\N	\N	\N
22b0f8c1-1a7c-4f83-9a23-01c5dceff230	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	owner	2026-11-13 15:56:24.290223+07	\N	\N	\N
5572ca83-3a71-4ab9-a970-9fa7034ffc7d	1398ff97-2866-4c04-b061-7e7abf3d38e0	owner	2026-11-20 17:34:29.957115+07	\N	\N	\N
2efeb3d2-7c8e-4763-9a5f-5784853467cb	feee6658-cda5-43b0-b70e-f38b39b592d4	renter	2026-11-20 19:41:21.886771+07	2026-11-20 19:41:21.8875+07	2026-11-21 07:41:21.8875+07	12
\.


--
-- Data for Name: homes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.homes (id, tenant_id, name, address, timezone, created_at, active_scene_id, active_since, geo_lat, geo_lng, geo_radius_m) FROM stdin;
728b0ae0-61ca-498a-a580-8ed0c52dde5c	911236fb-22ec-448b-a599-be539a6e8665	Căn hộ A-1203	Hà Nội	Asia/Ho_Chi_Minh	2026-11-13 10:33:49.573742+07	\N	\N	\N	\N	150
4a82f9a1-7582-40e5-8eb0-0016cce821ad	d8f54e4d-99cb-4a37-be27-fa22eef15292	H	\N	Asia/Ho_Chi_Minh	2026-11-13 14:05:40.305073+07	\N	\N	\N	\N	150
22b0f8c1-1a7c-4f83-9a23-01c5dceff230	e665bb28-ac94-4a20-ad8a-33bf0c109fde	LD22307	\N	Asia/Ho_Chi_Minh	2026-11-13 15:56:24.290223+07	\N	\N	\N	\N	150
2efeb3d2-7c8e-4763-9a5f-5784853467cb	e665bb28-ac94-4a20-ad8a-33bf0c109fde	LD22306	\N	Asia/Ho_Chi_Minh	2026-11-13 10:59:09.546283+07	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	2026-11-25 08:18:36.770296+07	20.9972149	105.9394294	150
5572ca83-3a71-4ab9-a970-9fa7034ffc7d	aa0cab41-42bd-45f8-87da-dd066cb90080	LD22808	\N	Asia/Ho_Chi_Minh	2026-11-20 17:34:29.957115+07	48d3996a-4bb4-4134-aa64-2b7abed308a9	2026-11-23 21:18:41.926447+07	\N	\N	150
\.


--
-- Data for Name: member_presence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_presence (home_id, user_id, inside, updated_at) FROM stdin;
2efeb3d2-7c8e-4763-9a5f-5784853467cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	f	2026-11-25 08:18:26.85459+07
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, home_id, scene_id, device_id, kind, title, body, created_at, camera_id) FROM stdin;
1221	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:04:28.391015+07	\N
1227	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:07:28.400039+07	\N
1628	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:05:49.090407+07	\N
1631	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:07:49.095906+07	\N
1632	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:08:29.096172+07	\N
1633	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:09:49.099684+07	\N
1637	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:12:29.106596+07	\N
1638	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:13:29.109975+07	\N
2055	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:17:49.823169+07	\N
2057	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:19:09.825838+07	\N
2062	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:23:09.836768+07	\N
2066	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:27:09.845476+07	\N
2076	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:33:49.86564+07	\N
2083	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:39:29.875867+07	\N
2088	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:43:29.884808+07	\N
2089	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:44:29.88621+07	\N
2090	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:44:49.887682+07	\N
2092	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:47:09.893372+07	\N
2412	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:53:50.491883+07	\N
2651	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:52:30.90515+07	\N
2746	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:01:51.068784+07	\N
2749	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:03:11.07469+07	\N
2750	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:04:31.075015+07	\N
2751	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:04:51.077442+07	\N
2755	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:07:51.084829+07	\N
2757	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:09:11.087644+07	\N
2758	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:09:51.087165+07	\N
1	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:39:24.327468+07	\N
2	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:40:44.331074+07	\N
3	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:42:04.334187+07	\N
4	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:43:24.338297+07	\N
6	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:44:44.340835+07	\N
8	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:46:04.344103+07	\N
10	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:47:24.346624+07	\N
12	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 12:48:44.349075+07	\N
13	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 13:22:44.422767+07	\N
2759	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:11:11.090254+07	\N
2776	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:23:11.121329+07	\N
2781	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:27:11.127135+07	\N
2785	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:30:51.138285+07	\N
2789	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:33:51.14372+07	\N
15	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 14:04:04.514139+07	\N
16	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 14:05:24.517003+07	\N
17	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-14 14:06:44.519718+07	\N
18	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-17 17:26:54.625041+07	\N
5	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-14 12:44:24.341674+07	\N
7	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-14 12:45:44.344312+07	\N
9	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-14 12:47:04.347491+07	\N
11	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-14 12:48:24.350172+07	\N
14	2efeb3d2-7c8e-4763-9a5f-5784853467cb	\N	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-14 13:23:04.425078+07	\N
21	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	scene_auto	Đã tự chuyển sang "Ra ngoài"	Không còn ai ở nhà	2026-11-21 07:43:41.747867+07	\N
22	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	scene_auto	Đã tự chuyển sang "Ra ngoài"	Không còn ai ở nhà	2026-11-21 08:17:17.51085+07	\N
23	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-21 09:18:17.909359+07	\N
27	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	scene_auto	Đã tự chuyển sang "Ra ngoài"	Không còn ai ở nhà	2026-11-21 14:39:55.75197+07	\N
1222	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:04:28.393803+07	\N
1228	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:08:28.400782+07	\N
37	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	scene_auto	Đã tự chuyển sang "Ra ngoài"	Không còn ai ở nhà	2026-11-21 14:53:38.341368+07	\N
1230	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:09:48.406585+07	\N
19	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-20 08:23:38.835012+07	\N
20	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-20 08:25:51.122966+07	\N
24	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-21 14:29:36.724324+07	\N
29	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-21 14:40:11.130226+07	\N
30	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-21 14:46:45.134368+07	\N
25	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:29:38.61922+07	\N
26	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:31:17.255565+07	\N
28	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:40:06.179069+07	\N
31	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:46:47.101566+07	\N
32	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:47:50.826798+07	\N
33	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:49:09.782338+07	\N
34	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:50:17.684248+07	\N
1231	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:11:08.406686+07	\N
1234	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:13:48.412985+07	\N
1235	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:14:08.415045+07	\N
1240	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:17:48.422871+07	\N
1642	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:15:49.118657+07	\N
1643	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:16:29.117142+07	\N
1644	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:17:09.118487+07	\N
2074	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:32:29.858634+07	\N
2080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:37:49.870589+07	\N
2084	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:40:29.876903+07	\N
2087	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:43:09.883185+07	\N
2093	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:48:29.896783+07	\N
2417	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:57:50.496756+07	\N
35	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:51:33.726736+07	\N
36	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:52:35.001827+07	\N
38	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 14:53:40.729941+07	\N
39	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	\N	scene_auto	Đã tự chuyển sang "Ra ngoài"	Không còn ai ở nhà	2026-11-21 21:23:37.960973+07	\N
40	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	aaad431d-119c-4a97-9ed0-ed5c152411b6	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-21 21:38:48.860702+07	\N
41	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 21:38:50.625254+07	\N
42	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 21:39:52.599856+07	\N
43	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 21:40:59.656753+07	\N
44	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 22:09:51.710211+07	\N
45	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 22:11:14.751957+07	\N
46	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-21 22:33:26.524059+07	\N
47	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:19:06.326741+07	\N
48	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:19:26.328923+07	\N
49	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:20:26.330133+07	\N
50	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:20:26.33379+07	\N
51	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:21:46.332698+07	\N
52	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:22:06.335701+07	\N
53	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:23:06.336933+07	\N
54	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:23:06.340966+07	\N
55	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:24:26.339835+07	\N
56	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:24:26.342656+07	\N
57	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:25:46.343327+07	\N
58	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:26:26.347103+07	\N
59	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:27:06.346342+07	\N
60	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:28:06.349459+07	\N
61	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:28:26.349622+07	\N
62	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:29:46.352347+07	\N
63	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:29:46.355555+07	\N
64	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:31:06.356051+07	\N
65	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:31:06.359271+07	\N
66	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:32:26.358743+07	\N
67	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:33:46.362668+07	\N
68	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:34:06.36461+07	\N
69	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:35:06.365281+07	\N
70	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:35:46.370012+07	\N
71	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:36:26.369544+07	\N
72	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:37:06.371817+07	\N
73	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:37:46.372441+07	\N
74	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:38:26.375506+07	\N
77	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:40:46.382448+07	\N
79	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:43:06.386931+07	\N
80	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:43:26.390215+07	\N
81	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:44:26.390496+07	\N
85	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:47:06.396158+07	\N
95	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:53:46.410943+07	\N
98	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:55:06.416916+07	\N
106	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:01:46.429539+07	\N
1223	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:05:28.395873+07	\N
1224	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:05:48.395618+07	\N
1225	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:06:28.398017+07	\N
1226	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:07:08.397472+07	\N
1229	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:09:48.403587+07	\N
1233	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:12:28.410098+07	\N
1237	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:15:48.41856+07	\N
1238	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:16:28.420502+07	\N
1241	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:19:08.42578+07	\N
1248	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:23:08.43991+07	\N
1249	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:24:28.438615+07	\N
1250	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:25:08.442551+07	\N
1255	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:28:28.449453+07	\N
1259	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:32:28.456512+07	\N
1645	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:17:49.118089+07	\N
1649	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:20:29.125796+07	\N
1652	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	aaad431d-119c-4a97-9ed0-ed5c152411b6	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-24 17:22:30.085466+07	\N
1655	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:23:38.246194+07	\N
2075	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:33:49.861645+07	\N
2085	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:40:29.880156+07	\N
2086	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:41:49.880007+07	\N
2426	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:04:30.513273+07	\N
2429	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:06:10.517163+07	\N
2430	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:07:10.517443+07	\N
2439	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:13:50.533704+07	\N
2448	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:21:30.553817+07	\N
2454	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:25:50.564355+07	\N
2458	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:28:30.570477+07	\N
2462	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:31:10.576325+07	\N
2752	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:05:51.078019+07	\N
75	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:39:06.375685+07	\N
1232	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:11:28.408148+07	\N
1243	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:20:28.430138+07	\N
1244	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:20:28.432816+07	\N
1245	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:21:48.432164+07	\N
1246	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:21:48.435639+07	\N
1646	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:18:29.122626+07	\N
1647	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:19:09.122069+07	\N
1648	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:19:49.125537+07	\N
1651	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:21:49.128719+07	\N
1658	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:24:49.137626+07	\N
1661	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:27:09.142063+07	\N
1663	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:28:29.14783+07	\N
1665	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:29:49.151489+07	\N
1668	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:32:29.153484+07	\N
1669	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:33:49.160897+07	\N
1677	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:38:09.169646+07	\N
1678	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:39:09.170773+07	\N
1683	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:41:49.179539+07	\N
1685	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:43:49.182707+07	\N
2077	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:35:09.864408+07	\N
2078	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:36:29.867536+07	\N
2079	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:36:49.86862+07	\N
2081	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:37:49.87415+07	\N
2082	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:39:09.873671+07	\N
2091	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:45:49.889582+07	\N
2427	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:05:10.516424+07	\N
2431	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:07:50.520519+07	\N
2434	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:09:50.523759+07	\N
2441	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:15:10.539909+07	\N
2442	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:16:30.54056+07	\N
2444	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:17:50.543668+07	\N
2446	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:19:10.546477+07	\N
2447	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:20:30.550009+07	\N
2452	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:24:30.559421+07	\N
2664	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:01:50.930475+07	\N
2670	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:07:30.94198+07	\N
2672	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:08:30.944822+07	\N
76	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:40:26.379275+07	\N
78	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:41:46.382999+07	\N
82	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:44:26.395253+07	\N
83	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:45:46.393202+07	\N
84	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:46:26.395734+07	\N
86	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:47:26.397578+07	\N
87	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:48:26.398359+07	\N
88	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:48:46.400473+07	\N
89	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:49:46.401354+07	\N
90	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:50:06.403436+07	\N
91	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:51:06.405004+07	\N
92	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:51:26.405875+07	\N
93	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:52:26.407233+07	\N
94	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:52:46.410129+07	\N
96	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:53:46.413437+07	\N
97	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:55:06.414103+07	\N
99	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:56:26.417778+07	\N
100	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:56:46.419445+07	\N
101	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:57:46.420346+07	\N
102	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 21:58:26.423432+07	\N
103	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 21:59:06.423379+07	\N
104	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:00:06.42692+07	\N
105	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:00:26.426312+07	\N
107	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:02:06.431829+07	\N
108	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:03:06.432566+07	\N
109	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:04:26.436189+07	\N
110	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:05:26.440103+07	\N
111	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:05:46.439308+07	\N
112	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:07:06.442753+07	\N
113	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:08:06.447198+07	\N
114	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:08:26.448724+07	\N
115	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:09:06.449891+07	\N
116	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:09:46.449846+07	\N
117	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:11:06.452477+07	\N
118	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:12:06.456126+07	\N
119	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:12:26.455501+07	\N
120	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:13:46.458623+07	\N
121	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:14:06.461738+07	\N
122	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:15:06.461015+07	\N
125	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:17:46.468087+07	\N
130	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:21:06.475573+07	\N
132	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:22:06.478359+07	\N
148	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:33:46.5048+07	\N
1236	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:15:08.415589+07	\N
1239	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:17:28.422555+07	\N
1242	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:19:28.427663+07	\N
1247	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:23:08.436272+07	\N
1251	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:25:48.441586+07	\N
1252	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:26:28.445222+07	\N
1254	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:28:28.446488+07	\N
1256	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:29:48.45039+07	\N
1264	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:36:28.46485+07	\N
1650	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:21:29.129419+07	\N
1656	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:24:29.1358+07	\N
1660	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:25:49.142045+07	\N
1666	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:31:09.150975+07	\N
2094	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:49:49.903064+07	\N
2096	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:51:09.908329+07	\N
2102	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:56:29.920065+07	\N
2107	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:00:29.930342+07	\N
2428	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:05:50.514333+07	\N
2432	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:08:30.520691+07	\N
2433	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:09:30.524216+07	\N
2435	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:11:10.527828+07	\N
2436	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:11:50.53047+07	\N
2438	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:13:10.535302+07	\N
2449	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:21:50.553102+07	\N
2450	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:23:10.555521+07	\N
2451	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:23:50.559112+07	\N
2456	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:27:30.566793+07	\N
2459	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:29:50.570775+07	\N
2466	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:34:50.583248+07	\N
2467	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:35:10.582742+07	\N
2667	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:04:30.933195+07	\N
2673	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:09:50.945734+07	\N
2674	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:09:50.949112+07	\N
2682	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:15:10.958576+07	\N
123	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:16:06.464613+07	\N
124	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:16:26.465052+07	\N
126	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:17:46.472174+07	\N
127	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:19:06.470728+07	\N
128	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:19:26.472034+07	\N
129	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:20:26.473343+07	\N
131	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:21:46.476443+07	\N
133	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:23:06.479223+07	\N
134	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:24:26.482545+07	\N
135	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:25:06.485947+07	\N
136	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:25:46.485313+07	\N
137	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:27:06.489428+07	\N
138	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:27:26.492029+07	\N
139	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:28:26.492501+07	\N
140	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:28:46.495019+07	\N
141	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:29:46.49548+07	\N
142	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:29:46.498255+07	\N
143	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:30:46.498858+07	\N
144	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:31:06.498767+07	\N
145	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:31:46.501465+07	\N
146	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:32:26.501792+07	\N
147	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:33:26.505009+07	\N
149	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:34:46.507257+07	\N
150	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:35:06.50745+07	\N
151	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:36:26.511269+07	\N
152	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:36:46.513798+07	\N
153	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:37:46.513613+07	\N
154	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:39:06.516287+07	\N
155	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:39:46.520499+07	\N
156	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:40:26.520598+07	\N
157	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:41:26.525754+07	\N
158	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:41:46.523873+07	\N
159	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:42:26.528463+07	\N
160	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:43:06.525891+07	\N
161	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:44:26.52884+07	\N
162	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:45:06.532882+07	\N
163	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:45:46.533622+07	\N
164	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:46:46.535871+07	\N
165	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:47:06.535837+07	\N
167	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:48:26.537938+07	\N
1253	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:27:08.444263+07	\N
1257	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:31:08.453253+07	\N
1258	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:31:48.455866+07	\N
1262	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:35:08.462333+07	\N
1263	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:35:28.464104+07	\N
1265	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:36:48.467025+07	\N
1268	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:39:08.470624+07	\N
1653	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:22:31.844637+07	\N
1654	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:23:09.132004+07	\N
1657	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:24:43.58954+07	\N
1659	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:25:49.138956+07	\N
1662	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:28:29.144787+07	\N
1675	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	aaad431d-119c-4a97-9ed0-ed5c152411b6	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-24 17:37:45.281351+07	\N
1680	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:40:29.173521+07	\N
1682	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:41:49.176486+07	\N
1690	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:47:49.193168+07	\N
1693	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:49:49.196011+07	\N
2095	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:49:49.906669+07	\N
2097	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:52:29.910279+07	\N
2101	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:55:49.920387+07	\N
2105	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:59:09.92674+07	\N
2116	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:06:09.947859+07	\N
2123	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:12:29.958861+07	\N
2128	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:16:29.968067+07	\N
2130	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:17:49.970758+07	\N
2437	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:12:30.53208+07	\N
2440	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:15:10.536445+07	\N
2443	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:17:10.544197+07	\N
2445	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:18:50.547575+07	\N
2453	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:24:50.560607+07	\N
2455	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:27:10.565103+07	\N
2457	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:28:30.567454+07	\N
2461	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:31:10.573027+07	\N
2463	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:32:30.57737+07	\N
2464	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:32:50.578958+07	\N
2465	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:33:50.579235+07	\N
2471	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:38:30.591174+07	\N
166	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:48:06.538043+07	\N
172	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:52:26.547011+07	\N
173	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:53:06.550567+07	\N
1260	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:33:48.460445+07	\N
1266	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:37:48.468201+07	\N
1267	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:38:08.471271+07	\N
1664	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:29:49.147828+07	\N
1667	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:32:09.153885+07	\N
1670	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:33:49.163721+07	\N
1672	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:36:29.163887+07	\N
1674	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:37:33.362451+07	\N
1676	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:37:49.167127+07	\N
1681	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:40:29.176274+07	\N
1688	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:45:49.186565+07	\N
1689	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:47:09.190594+07	\N
1691	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:48:29.19344+07	\N
1692	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:48:49.195608+07	\N
1697	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:52:29.204332+07	\N
1700	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:54:29.210391+07	\N
2098	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:53:29.914037+07	\N
2099	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:53:49.913355+07	\N
2100	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:55:09.917198+07	\N
2103	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:57:29.924361+07	\N
2104	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:57:49.924154+07	\N
2109	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:01:29.934355+07	\N
2110	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:01:49.933884+07	\N
2460	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:29:50.576361+07	\N
2469	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:37:10.588781+07	\N
2470	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:37:50.58857+07	\N
2474	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:40:30.598361+07	\N
2476	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:42:50.601667+07	\N
2478	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:43:50.604193+07	\N
2482	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:47:10.609954+07	\N
2483	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:48:10.614317+07	\N
2484	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:48:30.613471+07	\N
2489	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:51:50.622103+07	\N
2491	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:53:30.625294+07	\N
2494	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:55:10.631001+07	\N
168	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:49:46.540489+07	\N
169	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:50:06.542598+07	\N
170	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:51:06.543429+07	\N
171	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:51:46.547621+07	\N
174	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:53:46.549939+07	\N
175	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:55:06.553177+07	\N
176	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 22:55:26.554839+07	\N
177	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:56:26.556893+07	\N
178	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:57:46.560199+07	\N
179	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 22:59:06.563417+07	\N
180	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:00:06.567402+07	\N
181	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:00:26.566469+07	\N
182	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:01:46.569534+07	\N
183	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:01:46.572643+07	\N
184	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:03:06.572826+07	\N
185	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:03:06.575404+07	\N
186	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:04:26.576663+07	\N
187	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:04:26.57907+07	\N
188	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:05:46.579663+07	\N
189	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:06:26.582906+07	\N
190	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:07:06.58266+07	\N
191	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:08:06.586576+07	\N
192	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:08:26.585328+07	\N
193	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:09:06.587616+07	\N
194	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:09:46.588174+07	\N
195	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:10:06.59047+07	\N
196	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:11:06.591854+07	\N
197	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:12:06.595061+07	\N
198	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:12:26.59469+07	\N
199	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:13:46.597969+07	\N
200	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:13:46.602003+07	\N
201	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:15:06.600911+07	\N
202	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:16:26.604167+07	\N
203	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:16:26.607907+07	\N
204	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:17:46.60713+07	\N
205	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:18:06.609845+07	\N
206	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:19:06.609663+07	\N
207	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:20:06.612856+07	\N
208	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:20:26.6128+07	\N
209	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:21:26.61604+07	\N
210	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:21:46.615114+07	\N
214	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:24:26.621357+07	\N
222	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:29:46.635128+07	\N
224	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:31:06.635858+07	\N
225	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:31:46.637832+07	\N
226	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:32:26.638627+07	\N
230	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:35:06.645002+07	\N
238	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:40:26.656609+07	\N
1261	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:34:28.462448+07	\N
1269	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:39:28.473684+07	\N
1671	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:35:09.161725+07	\N
1673	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:36:49.171067+07	\N
1679	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:39:29.172725+07	\N
1684	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:43:09.17988+07	\N
1686	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:44:29.182408+07	\N
1687	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:45:09.18589+07	\N
1701	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:55:09.209377+07	\N
1702	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:55:49.213319+07	\N
1705	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:57:49.216048+07	\N
1707	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:59:09.220558+07	\N
1710	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:01:49.224875+07	\N
1712	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:03:09.229557+07	\N
1713	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	aaad431d-119c-4a97-9ed0-ed5c152411b6	door_open	Cửa vừa mở	Cảm biến cửa vừa mở · chế độ "Ra ngoài"	2026-11-24 18:03:47.1599+07	\N
2106	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:59:29.92909+07	\N
2108	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:00:29.933098+07	\N
2468	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:36:30.585969+07	\N
2472	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:39:10.591614+07	\N
2480	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:45:50.606166+07	\N
2485	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:49:10.616295+07	\N
2486	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:49:50.616419+07	\N
2490	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:52:30.623182+07	\N
2493	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:55:10.628328+07	\N
2497	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:57:50.634568+07	\N
2501	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:00:30.643633+07	\N
2504	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:03:10.647775+07	\N
2669	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:07:10.939802+07	\N
2675	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:10:50.949632+07	\N
2685	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:18:30.966636+07	\N
211	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:22:26.617883+07	\N
212	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:23:06.618541+07	\N
217	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:27:06.626548+07	\N
227	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:32:46.640359+07	\N
228	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:33:46.642047+07	\N
235	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:37:46.650377+07	\N
236	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:39:06.653193+07	\N
1270	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:40:28.47371+07	\N
1275	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:44:08.485163+07	\N
1278	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:45:48.488964+07	\N
1281	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:48:28.492256+07	\N
1694	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:50:09.199354+07	\N
1695	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:51:09.200608+07	\N
1706	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:58:29.220111+07	\N
1708	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:00:29.222327+07	\N
1709	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:00:29.226735+07	\N
1711	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:01:49.227731+07	\N
1716	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:04:29.230393+07	\N
1717	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:05:49.233878+07	\N
1721	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:08:09.239727+07	\N
1723	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:09:49.242413+07	\N
1729	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:14:09.254407+07	\N
1731	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:15:09.259832+07	\N
2111	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:02:49.93707+07	\N
2114	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:04:49.943896+07	\N
2115	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:05:49.944966+07	\N
2117	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:07:09.945704+07	\N
2120	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:09:49.953225+07	\N
2121	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:11:09.957061+07	\N
2124	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:13:49.961917+07	\N
2125	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:14:09.964328+07	\N
2126	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:15:09.96548+07	\N
2131	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:18:09.974024+07	\N
2134	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:20:29.977804+07	\N
2135	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:21:29.981157+07	\N
2136	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:21:49.981072+07	\N
2138	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:24:29.989302+07	\N
2142	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:27:09.995714+07	\N
2145	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:29:50.000968+07	\N
213	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:23:46.620883+07	\N
221	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:29:46.632339+07	\N
229	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:33:46.645001+07	\N
231	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:35:06.647485+07	\N
233	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:36:26.647749+07	\N
234	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:37:06.650268+07	\N
237	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:39:26.65483+07	\N
239	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:41:06.658696+07	\N
1271	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:41:28.476258+07	\N
1272	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:41:48.475931+07	\N
1276	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:44:28.48417+07	\N
1277	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:45:48.48613+07	\N
1284	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:51:08.497898+07	\N
1287	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:52:28.504033+07	\N
1288	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:53:48.505497+07	\N
1290	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:55:08.508777+07	\N
1293	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:57:48.515084+07	\N
1300	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:02:28.525971+07	\N
1301	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:03:08.525844+07	\N
1302	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:03:28.527965+07	\N
1696	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:52:09.204365+07	\N
1698	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:53:29.206342+07	\N
1699	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:53:49.206531+07	\N
1703	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:56:29.212837+07	\N
1704	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:57:09.216149+07	\N
1722	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:08:29.240131+07	\N
1726	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:12:29.249023+07	\N
1728	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:13:49.252752+07	\N
1730	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:15:09.256798+07	\N
1732	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:16:29.259039+07	\N
1733	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:16:49.262302+07	\N
1734	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:17:49.264048+07	\N
1736	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:19:09.268148+07	\N
2112	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:03:09.93878+07	\N
2113	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:04:29.940175+07	\N
2119	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:08:29.949402+07	\N
2127	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:16:09.968754+07	\N
2129	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:17:09.971145+07	\N
2132	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:19:09.974801+07	\N
215	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:25:46.623845+07	\N
216	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:25:46.627691+07	\N
218	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:27:06.629238+07	\N
219	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:28:06.630301+07	\N
220	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:28:26.629587+07	\N
223	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:30:46.636224+07	\N
232	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:36:06.647923+07	\N
240	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:41:46.659054+07	\N
241	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:42:06.660827+07	\N
242	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:43:06.662602+07	\N
243	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:44:06.666057+07	\N
244	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:44:26.665445+07	\N
245	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:45:06.669112+07	\N
246	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:45:46.668981+07	\N
247	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:47:06.672129+07	\N
248	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:47:06.676008+07	\N
249	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:48:26.674961+07	\N
250	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:48:46.677207+07	\N
251	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:49:46.678553+07	\N
252	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:50:06.680669+07	\N
253	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:51:06.684622+07	\N
254	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:51:46.686081+07	\N
255	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:52:26.685817+07	\N
256	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:53:26.690432+07	\N
257	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:53:46.689345+07	\N
258	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:54:26.693478+07	\N
259	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:55:06.692877+07	\N
260	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:56:26.695137+07	\N
261	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:56:26.698619+07	\N
262	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:57:46.698566+07	\N
263	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:57:46.70131+07	\N
264	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-23 23:58:46.702462+07	\N
265	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-23 23:59:06.701818+07	\N
266	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:00:26.705559+07	\N
267	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:01:06.708615+07	\N
268	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:01:46.709112+07	\N
269	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:03:06.712039+07	\N
270	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:03:46.715455+07	\N
271	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:04:26.717231+07	\N
272	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:04:46.718661+07	\N
1273	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:42:48.479946+07	\N
1274	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:43:08.479477+07	\N
1283	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:49:48.500747+07	\N
1285	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:51:08.501257+07	\N
1286	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:52:28.501473+07	\N
1289	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:54:48.50843+07	\N
1714	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:03:49.216522+07	\N
1715	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:04:09.23096+07	\N
1720	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:07:09.236301+07	\N
1737	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:19:49.2701+07	\N
1740	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:21:49.276271+07	\N
1746	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:27:09.284873+07	\N
1749	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:28:29.29393+07	\N
1750	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:29:49.29268+07	\N
1754	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:32:29.301033+07	\N
2118	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:07:29.949305+07	\N
2122	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:11:09.961088+07	\N
2140	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:25:49.992268+07	\N
2141	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:26:49.99587+07	\N
2473	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:40:30.595128+07	\N
2678	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:12:30.952047+07	\N
2679	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:12:50.954185+07	\N
2680	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:13:50.955383+07	\N
2753	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:05:51.081488+07	\N
2777	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:24:11.121557+07	\N
2782	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:27:11.129881+07	\N
2783	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:28:31.130654+07	\N
2784	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:29:51.134542+07	\N
2790	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:34:11.144776+07	\N
2796	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:38:51.156781+07	\N
2799	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:40:31.160674+07	\N
2800	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:41:31.163877+07	\N
2802	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:42:31.166032+07	\N
2805	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:44:31.169317+07	\N
2806	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:44:31.171988+07	\N
273	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:05:46.71932+07	\N
274	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:06:06.722701+07	\N
276	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:07:06.726601+07	\N
278	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:09:06.728753+07	\N
279	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:09:46.730537+07	\N
280	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:11:06.735101+07	\N
1279	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:47:08.489122+07	\N
1280	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:47:28.49065+07	\N
1294	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:57:48.517356+07	\N
1298	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:00:28.52344+07	\N
1304	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:04:48.531596+07	\N
1308	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:07:28.536912+07	\N
1309	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:08:28.538859+07	\N
1311	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:09:48.541691+07	\N
1314	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:12:28.548349+07	\N
1316	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:13:48.550115+07	\N
1718	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:05:49.236672+07	\N
1719	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:06:49.237183+07	\N
1724	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:09:49.245145+07	\N
1725	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:11:09.246587+07	\N
1727	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:12:29.251644+07	\N
1735	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:18:09.265249+07	\N
1738	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:20:29.269127+07	\N
1739	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:21:49.272663+07	\N
1741	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:23:09.275547+07	\N
1742	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:23:29.277236+07	\N
1745	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:25:49.286085+07	\N
1747	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:27:29.288055+07	\N
2133	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:19:09.978525+07	\N
2137	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:23:09.984952+07	\N
2139	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:24:49.99048+07	\N
2144	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:28:30.001772+07	\N
2475	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:41:50.598171+07	\N
2481	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:46:50.610527+07	\N
2492	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:53:50.625253+07	\N
2495	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:56:30.631024+07	\N
2505	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:03:30.649143+07	\N
2684	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:17:50.963478+07	\N
275	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:07:06.722875+07	\N
277	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:08:26.726199+07	\N
281	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:12:06.737698+07	\N
283	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:13:26.739169+07	\N
285	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:15:06.74301+07	\N
1282	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:49:48.495586+07	\N
1292	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:56:28.515993+07	\N
1296	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:59:08.517261+07	\N
1297	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:00:28.520524+07	\N
1305	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:05:48.532662+07	\N
1307	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:07:08.535537+07	\N
1310	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:09:08.541223+07	\N
1315	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:13:08.55016+07	\N
1320	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:16:28.556789+07	\N
1743	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:24:29.278151+07	\N
1752	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:31:09.298161+07	\N
1753	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:32:29.298408+07	\N
1755	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:33:49.301897+07	\N
1757	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:35:09.304462+07	\N
1762	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:37:49.313942+07	\N
1765	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:40:29.318454+07	\N
1769	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:43:09.323638+07	\N
2143	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:28:29.998371+07	\N
2146	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:30:10.004245+07	\N
2147	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:31:10.004279+07	\N
2148	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:32:30.007229+07	\N
2149	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:33:50.01074+07	\N
2155	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:39:10.024037+07	\N
2162	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:44:10.036103+07	\N
2164	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:45:50.037765+07	\N
2166	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:47:10.041065+07	\N
2167	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:47:10.044774+07	\N
2477	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:43:10.602679+07	\N
2479	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:44:30.603141+07	\N
2487	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:50:10.619298+07	\N
2488	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:51:10.618946+07	\N
2496	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:56:50.633114+07	\N
2499	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:59:10.638+07	\N
2503	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:02:10.646789+07	\N
282	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:12:26.736175+07	\N
284	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:13:46.738883+07	\N
286	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:15:26.744931+07	\N
287	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:16:26.746918+07	\N
288	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:17:06.749447+07	\N
289	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:17:46.748792+07	\N
290	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:19:06.751377+07	\N
291	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:19:26.753288+07	\N
292	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:20:26.75429+07	\N
293	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:21:46.75792+07	\N
294	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:22:46.761794+07	\N
295	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:23:06.762788+07	\N
296	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:24:26.764474+07	\N
297	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:24:26.767571+07	\N
298	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:25:46.767257+07	\N
299	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:26:26.771643+07	\N
300	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:27:06.772062+07	\N
301	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:28:06.775572+07	\N
302	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:28:26.77534+07	\N
303	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:29:06.778682+07	\N
304	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:29:46.779313+07	\N
305	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:31:06.781798+07	\N
306	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:31:26.784067+07	\N
307	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:32:26.784145+07	\N
308	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:33:06.787328+07	\N
309	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:33:46.787104+07	\N
310	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:34:06.791139+07	\N
311	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:35:06.791264+07	\N
312	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:35:26.792081+07	\N
313	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:36:26.793263+07	\N
314	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:36:26.796035+07	\N
315	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:37:46.796424+07	\N
316	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:38:06.798456+07	\N
317	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:39:06.799603+07	\N
318	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:40:06.803155+07	\N
319	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:40:26.802559+07	\N
320	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:41:06.807134+07	\N
321	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:41:46.805182+07	\N
322	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:43:06.808985+07	\N
323	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:43:26.810478+07	\N
324	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:44:26.811692+07	\N
325	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:44:46.814257+07	\N
326	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:45:46.815579+07	\N
327	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:47:06.817625+07	\N
328	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:47:46.820695+07	\N
329	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:48:26.820393+07	\N
330	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:48:46.823163+07	\N
331	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:49:46.825101+07	\N
332	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:50:06.826722+07	\N
333	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:51:06.827469+07	\N
334	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:52:26.831414+07	\N
335	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:53:06.833739+07	\N
336	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:53:46.834815+07	\N
337	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:54:06.835257+07	\N
338	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:55:06.837569+07	\N
339	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:55:06.840426+07	\N
340	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:56:26.840116+07	\N
341	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:56:26.843251+07	\N
342	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:57:46.843804+07	\N
343	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:57:46.847339+07	\N
344	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 00:59:06.846591+07	\N
345	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 00:59:06.848998+07	\N
346	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:00:26.850049+07	\N
347	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:01:46.852723+07	\N
348	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:01:46.855833+07	\N
349	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:03:06.855564+07	\N
350	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:03:06.858144+07	\N
351	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:04:26.8587+07	\N
352	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:04:46.861901+07	\N
353	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:05:46.862543+07	\N
354	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:05:46.865394+07	\N
355	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:07:06.866259+07	\N
356	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:08:06.869406+07	\N
357	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:08:26.868369+07	\N
358	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:09:46.872664+07	\N
359	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:11:06.878428+07	\N
360	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:11:26.877994+07	\N
361	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:12:26.878861+07	\N
362	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:12:26.881984+07	\N
363	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:13:46.882284+07	\N
366	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:16:26.887942+07	\N
389	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:33:46.92894+07	\N
390	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:34:06.928658+07	\N
397	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:39:06.939033+07	\N
1291	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:56:28.511978+07	\N
1295	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:58:48.51792+07	\N
1299	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:01:48.523378+07	\N
1303	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:04:28.530459+07	\N
1312	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:11:08.544045+07	\N
1313	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:11:28.545903+07	\N
1321	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:17:48.560348+07	\N
1322	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:18:48.563864+07	\N
1327	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:21:48.572775+07	\N
1330	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:24:28.574734+07	\N
1744	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:25:49.282364+07	\N
1756	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:34:29.304148+07	\N
1764	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:39:09.314505+07	\N
1767	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:41:49.320485+07	\N
1772	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:45:49.330412+07	\N
2150	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:35:10.014345+07	\N
2151	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:35:10.018603+07	\N
2152	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:36:30.017417+07	\N
2153	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:37:10.020744+07	\N
2154	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:37:50.022121+07	\N
2157	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:40:30.026884+07	\N
2163	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:44:30.035908+07	\N
2168	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:48:30.043481+07	\N
2170	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:49:50.04639+07	\N
2175	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:53:10.060577+07	\N
2179	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:55:50.062321+07	\N
2181	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:57:30.06615+07	\N
2182	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:57:50.066565+07	\N
2184	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:59:50.072391+07	\N
2498	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:57:50.637854+07	\N
2500	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:00:30.640297+07	\N
2502	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:01:50.644308+07	\N
364	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:14:26.884902+07	\N
365	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:15:06.884874+07	\N
367	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:17:26.892314+07	\N
368	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:17:46.890751+07	\N
369	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:19:06.894389+07	\N
370	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:20:26.898671+07	\N
371	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:20:26.902123+07	\N
372	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:21:46.901081+07	\N
373	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:21:46.904557+07	\N
374	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:23:06.903574+07	\N
375	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:23:46.906903+07	\N
376	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:24:26.907046+07	\N
377	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:24:46.908303+07	\N
378	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:25:46.90985+07	\N
379	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:26:06.915126+07	\N
380	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:27:06.913034+07	\N
381	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:27:46.91548+07	\N
382	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:28:26.916024+07	\N
383	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:29:06.918895+07	\N
384	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:29:46.918715+07	\N
385	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:30:26.920993+07	\N
386	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:31:06.921229+07	\N
387	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:32:26.924128+07	\N
388	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:32:26.927216+07	\N
391	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:35:06.929747+07	\N
392	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:35:46.932129+07	\N
393	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:36:26.932425+07	\N
394	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:36:46.934362+07	\N
395	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:37:46.93572+07	\N
396	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:38:26.938579+07	\N
398	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:40:26.942449+07	\N
399	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:41:06.944988+07	\N
400	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:41:46.945397+07	\N
401	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:42:26.947845+07	\N
402	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:43:06.948241+07	\N
403	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:43:26.951628+07	\N
404	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:44:26.951571+07	\N
405	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:44:46.953211+07	\N
406	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:45:46.954003+07	\N
1306	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:06:08.535413+07	\N
1323	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:19:08.562576+07	\N
1325	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:20:28.566433+07	\N
1329	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:23:28.576116+07	\N
1331	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:25:28.578283+07	\N
1333	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:26:48.581477+07	\N
1337	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:29:48.586873+07	\N
1340	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:32:28.592878+07	\N
1342	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:33:48.595859+07	\N
1748	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:28:29.288114+07	\N
1751	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:31:09.295132+07	\N
1759	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:36:29.308821+07	\N
1760	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:36:49.310177+07	\N
1761	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:37:49.311185+07	\N
1773	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:47:09.33297+07	\N
1777	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:50:09.34143+07	\N
1780	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:52:29.34533+07	\N
1781	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:52:49.348598+07	\N
1782	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:53:49.348917+07	\N
1784	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:55:09.351971+07	\N
2156	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:39:30.027732+07	\N
2158	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:41:10.030071+07	\N
2160	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:42:30.031921+07	\N
2161	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:43:10.032698+07	\N
2172	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:51:10.049796+07	\N
2176	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:53:50.056045+07	\N
2186	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:01:30.085611+07	\N
2194	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:08:10.095603+07	\N
2506	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:04:30.65068+07	\N
2508	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:05:50.653585+07	\N
2509	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:06:10.655157+07	\N
2516	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:11:10.665052+07	\N
2686	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:19:10.966382+07	\N
2703	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:31:10.994714+07	\N
2754	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:07:11.080906+07	\N
2766	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:16:31.10244+07	\N
2767	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:17:31.105277+07	\N
2770	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:19:11.108808+07	\N
407	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:46:06.956925+07	\N
408	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:47:06.958478+07	\N
409	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:48:26.963554+07	\N
410	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:48:26.967158+07	\N
411	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:49:46.965932+07	\N
412	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:50:26.968259+07	\N
413	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:51:06.968256+07	\N
414	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:52:06.978336+07	\N
415	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:52:26.972652+07	\N
416	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:53:26.980856+07	\N
417	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:53:46.977272+07	\N
418	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:55:06.980398+07	\N
419	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:55:26.98045+07	\N
420	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:56:26.983819+07	\N
421	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:57:06.983983+07	\N
422	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:57:46.983864+07	\N
423	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:58:26.986864+07	\N
424	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 01:59:06.98716+07	\N
425	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 01:59:26.992524+07	\N
426	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:00:26.992841+07	\N
427	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:01:07.000502+07	\N
428	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:01:47.000784+07	\N
429	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:02:27.010989+07	\N
430	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:03:07.004081+07	\N
431	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:04:27.006687+07	\N
432	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:05:07.011635+07	\N
433	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:05:47.011495+07	\N
434	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:06:27.017648+07	\N
435	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:07:07.013215+07	\N
436	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:07:27.021145+07	\N
437	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:08:27.016435+07	\N
438	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:09:07.025529+07	\N
439	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:09:47.021035+07	\N
440	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:11:07.022064+07	\N
441	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:11:27.029359+07	\N
442	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:12:27.025612+07	\N
443	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:13:07.029161+07	\N
444	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:13:47.02668+07	\N
445	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:14:07.034166+07	\N
448	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:16:27.034989+07	\N
1317	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:14:28.553669+07	\N
1318	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:15:08.553962+07	\N
1319	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:15:48.556552+07	\N
1324	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:19:48.566024+07	\N
1326	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:21:48.569339+07	\N
1328	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:23:08.572033+07	\N
1332	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:25:48.578131+07	\N
1334	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:27:08.581283+07	\N
1339	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:31:08.59019+07	\N
1345	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:36:48.603818+07	\N
1758	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:35:29.306135+07	\N
1763	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:38:49.315153+07	\N
1766	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:40:29.320891+07	\N
1768	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:41:49.323847+07	\N
1770	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:44:29.327135+07	\N
1771	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:44:29.330126+07	\N
1775	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:48:29.336422+07	\N
1778	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:51:09.342516+07	\N
1779	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:51:29.343683+07	\N
1786	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:56:49.356141+07	\N
1787	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:57:49.357649+07	\N
1788	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:59:09.361036+07	\N
1789	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:00:09.364443+07	\N
1792	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:01:49.366438+07	\N
1793	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:03:09.370237+07	\N
2159	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:41:50.030952+07	\N
2165	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:46:10.03966+07	\N
2173	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:51:50.05264+07	\N
2174	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:52:30.052999+07	\N
2177	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:54:30.058546+07	\N
2180	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:56:30.062518+07	\N
2185	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:00:30.079148+07	\N
2187	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:01:50.079455+07	\N
2507	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:05:10.652759+07	\N
2511	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:07:30.865375+07	\N
2512	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:08:30.659478+07	\N
446	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:15:07.032062+07	\N
1335	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:28:28.58444+07	\N
1338	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:30:28.590303+07	\N
1341	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:32:48.594629+07	\N
1343	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:35:08.599087+07	\N
1344	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:36:28.60141+07	\N
1346	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:37:48.60506+07	\N
1349	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:39:28.610292+07	\N
1351	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:41:08.61494+07	\N
1356	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:44:28.623786+07	\N
1358	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:46:08.62655+07	\N
1359	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:47:08.62735+07	\N
1362	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:48:28.633076+07	\N
1774	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:48:09.336402+07	\N
1776	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:49:49.339674+07	\N
1783	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 18:54:29.350466+07	\N
1785	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 18:56:29.353617+07	\N
1794	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:03:49.373998+07	\N
1799	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:07:09.379574+07	\N
1801	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:08:29.38253+07	\N
1807	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:12:29.392694+07	\N
1808	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:13:09.395298+07	\N
1811	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:15:09.402261+07	\N
2169	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:48:30.047132+07	\N
2171	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 23:50:50.049798+07	\N
2178	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:55:10.059469+07	\N
2183	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 23:59:10.069492+07	\N
2510	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:07:10.6571+07	\N
2517	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:12:30.668095+07	\N
2519	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:13:50.671109+07	\N
2541	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:29:50.70976+07	\N
2543	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:31:10.71198+07	\N
2547	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:34:50.721826+07	\N
2687	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:19:30.968367+07	\N
2689	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:20:50.972143+07	\N
2695	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:25:10.982195+07	\N
2698	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:27:10.985806+07	\N
2699	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:28:30.988851+07	\N
447	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:15:07.042202+07	\N
449	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:17:07.03819+07	\N
450	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:17:47.035534+07	\N
451	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:18:27.040456+07	\N
452	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:19:07.040667+07	\N
453	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:20:07.046977+07	\N
454	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:20:27.04084+07	\N
455	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:21:07.047226+07	\N
456	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:21:47.043276+07	\N
457	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:22:07.04919+07	\N
458	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:23:07.045652+07	\N
459	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:24:27.05137+07	\N
460	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:25:27.059723+07	\N
461	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:25:47.052723+07	\N
462	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:27:07.056743+07	\N
463	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:27:27.059311+07	\N
464	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:28:27.060528+07	\N
465	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:29:47.064045+07	\N
466	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:31:07.06949+07	\N
467	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:31:07.085073+07	\N
468	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:32:27.069501+07	\N
469	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:32:27.074158+07	\N
470	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:33:47.073818+07	\N
471	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:34:07.076575+07	\N
472	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:35:07.075667+07	\N
473	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:35:27.080941+07	\N
474	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:36:27.080384+07	\N
475	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:37:47.083583+07	\N
476	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:38:07.090562+07	\N
477	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:39:07.086491+07	\N
478	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:39:07.09493+07	\N
479	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:40:27.091101+07	\N
480	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:41:47.092749+07	\N
481	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:41:47.096169+07	\N
482	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:42:47.096627+07	\N
483	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:43:07.095799+07	\N
484	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:43:47.098711+07	\N
485	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:44:27.098392+07	\N
486	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:45:27.104021+07	\N
488	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:46:47.105352+07	\N
1336	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:28:28.588484+07	\N
1347	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:38:28.608071+07	\N
1348	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:39:08.608318+07	\N
1352	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:41:48.613983+07	\N
1353	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:42:48.618391+07	\N
1355	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:44:28.621094+07	\N
1357	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:45:48.624299+07	\N
1364	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:50:08.637025+07	\N
1371	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:55:08.648147+07	\N
1790	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:00:29.366285+07	\N
1791	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:01:29.367712+07	\N
1814	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:17:49.406335+07	\N
1819	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:21:29.415665+07	\N
2188	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:03:10.083704+07	\N
2190	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:04:30.084033+07	\N
2191	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:05:50.085352+07	\N
2193	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:07:10.092858+07	\N
2195	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:08:30.094309+07	\N
2197	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:09:50.103965+07	\N
2202	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:15:10.107981+07	\N
2204	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:16:30.112422+07	\N
2205	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:16:50.113922+07	\N
2207	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:17:50.117555+07	\N
2213	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:23:10.126377+07	\N
2214	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:24:30.130655+07	\N
2513	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:09:30.662667+07	\N
2515	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:10:30.665816+07	\N
2520	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:15:10.673895+07	\N
2523	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:17:10.679573+07	\N
2526	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:19:10.684772+07	\N
2530	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:21:50.690678+07	\N
2531	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:22:50.693855+07	\N
2533	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:24:30.696298+07	\N
2534	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:24:50.698577+07	\N
2535	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:25:50.699392+07	\N
2537	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:26:50.704276+07	\N
487	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:45:47.10295+07	\N
489	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:47:07.107082+07	\N
490	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:48:27.110966+07	\N
491	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:49:47.111773+07	\N
492	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:50:07.115833+07	\N
493	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:51:07.114309+07	\N
494	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:52:27.11775+07	\N
495	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:53:07.120984+07	\N
496	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:53:47.122148+07	\N
497	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:55:07.126026+07	\N
498	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:55:07.131767+07	\N
499	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:56:27.128275+07	\N
500	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:56:47.137513+07	\N
501	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:57:47.131917+07	\N
502	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 02:58:47.135649+07	\N
503	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 02:59:07.134299+07	\N
504	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:00:27.137806+07	\N
505	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:00:27.141158+07	\N
506	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:01:27.150655+07	\N
507	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:01:47.14291+07	\N
508	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:03:07.143656+07	\N
509	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:03:27.147672+07	\N
510	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:04:27.147849+07	\N
511	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:05:07.150798+07	\N
512	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:05:47.152972+07	\N
513	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:06:27.160332+07	\N
514	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:07:07.154306+07	\N
515	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:07:47.15811+07	\N
516	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:08:27.155272+07	\N
517	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:09:27.160115+07	\N
518	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:09:47.157857+07	\N
519	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:10:27.162603+07	\N
520	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:11:07.161344+07	\N
521	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:12:27.16493+07	\N
522	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:12:27.168024+07	\N
523	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:13:27.177998+07	\N
524	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:13:47.168476+07	\N
525	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:14:47.171984+07	\N
526	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:15:07.172367+07	\N
527	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:16:27.176282+07	\N
528	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:16:47.179175+07	\N
530	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:18:47.182475+07	\N
531	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:19:07.181974+07	\N
1350	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:40:28.611857+07	\N
1354	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:43:08.618656+07	\N
1361	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:48:28.630487+07	\N
1365	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:51:08.637396+07	\N
1366	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:51:28.639236+07	\N
1373	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:56:28.652625+07	\N
1377	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:00:08.658652+07	\N
1379	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:01:08.660555+07	\N
1381	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:03:08.663228+07	\N
1382	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:03:48.665848+07	\N
1795	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:04:29.373549+07	\N
1798	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:06:09.379188+07	\N
1802	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:08:49.383836+07	\N
1803	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:09:49.386107+07	\N
1805	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:11:09.389042+07	\N
1809	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:13:49.39526+07	\N
1812	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:16:29.402473+07	\N
1816	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:19:09.409123+07	\N
1820	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:21:49.415041+07	\N
2189	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:03:30.092213+07	\N
2196	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:09:50.096471+07	\N
2198	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:11:10.103625+07	\N
2199	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:12:30.102207+07	\N
2200	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:13:10.1052+07	\N
2209	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:19:50.120799+07	\N
2219	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:28:30.138993+07	\N
2514	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:09:50.662309+07	\N
2521	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:15:10.677379+07	\N
2522	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:16:30.676475+07	\N
2524	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:17:50.6798+07	\N
2529	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:21:10.690903+07	\N
2536	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:25:50.702417+07	\N
2688	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:20:30.970308+07	\N
2691	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:22:30.976522+07	\N
2692	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:23:10.976734+07	\N
529	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:17:47.180409+07	\N
532	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:20:27.186559+07	\N
533	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:20:27.190225+07	\N
534	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:21:47.188864+07	\N
535	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:23:07.191726+07	\N
536	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:23:07.194859+07	\N
537	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:24:27.195173+07	\N
538	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:25:27.198348+07	\N
539	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:25:47.197974+07	\N
540	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:27:07.201219+07	\N
541	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:27:07.204978+07	\N
542	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:28:27.204491+07	\N
543	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:29:07.207817+07	\N
544	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:29:47.207381+07	\N
545	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:31:07.211962+07	\N
546	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:32:27.21478+07	\N
547	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:32:47.218198+07	\N
548	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:33:47.218119+07	\N
549	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:35:07.221047+07	\N
550	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:35:47.22427+07	\N
551	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:36:27.224433+07	\N
552	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:37:27.228603+07	\N
553	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:37:47.233491+07	\N
554	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:39:07.231164+07	\N
555	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:39:07.234694+07	\N
556	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:40:27.234996+07	\N
557	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:41:27.238172+07	\N
558	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:41:47.238324+07	\N
559	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:42:47.241636+07	\N
560	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:43:07.240876+07	\N
561	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:44:07.24466+07	\N
562	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:44:27.243594+07	\N
563	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:45:47.246369+07	\N
564	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:45:47.249267+07	\N
565	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:47:07.250089+07	\N
566	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:47:47.252775+07	\N
567	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:48:27.252098+07	\N
568	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:49:47.255271+07	\N
569	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:49:47.258796+07	\N
570	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:51:07.258243+07	\N
573	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:52:27.264507+07	\N
575	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:55:07.267787+07	\N
577	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:56:27.273249+07	\N
579	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:57:47.274055+07	\N
584	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:02:47.285993+07	\N
587	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:04:27.294107+07	\N
1360	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:47:08.630442+07	\N
1363	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:49:48.634112+07	\N
1368	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:53:48.642908+07	\N
1369	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:54:08.644921+07	\N
1372	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:56:28.649511+07	\N
1383	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:04:28.666297+07	\N
1384	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:05:08.668452+07	\N
1387	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:07:28.674651+07	\N
1394	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:12:28.685736+07	\N
1796	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:05:09.377209+07	\N
1797	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:05:49.376643+07	\N
1800	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:07:29.381987+07	\N
1804	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:09:49.389178+07	\N
1806	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:12:09.392676+07	\N
1810	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:15:09.399448+07	\N
1813	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:16:49.409561+07	\N
1815	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:18:49.409796+07	\N
1817	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:19:49.412577+07	\N
1818	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:20:29.412611+07	\N
1821	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:22:29.422067+07	\N
1823	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:24:29.421662+07	\N
1827	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:27:49.431308+07	\N
1832	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:31:09.437663+07	\N
1834	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:32:29.440544+07	\N
2192	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:06:30.094402+07	\N
2203	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:15:10.110642+07	\N
2211	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:21:50.124071+07	\N
2221	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:29:50.142906+07	\N
2518	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:12:50.671444+07	\N
2525	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:18:30.683091+07	\N
2527	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:19:30.685709+07	\N
571	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:51:07.262673+07	\N
572	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:52:27.261823+07	\N
574	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:53:47.264892+07	\N
576	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:55:07.271811+07	\N
578	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:56:27.276097+07	\N
582	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:00:27.279885+07	\N
583	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:01:47.281868+07	\N
1367	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:52:28.640494+07	\N
1370	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:55:08.645547+07	\N
1375	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 13:58:28.654781+07	\N
1378	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:00:28.657888+07	\N
1380	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:01:48.660353+07	\N
1386	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:07:08.673553+07	\N
1388	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:08:28.676176+07	\N
1390	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:09:48.678726+07	\N
1391	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:10:28.682431+07	\N
1822	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:23:09.418581+07	\N
1824	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:24:29.424032+07	\N
1826	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:27:09.427729+07	\N
1830	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:29:49.434527+07	\N
1836	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:34:49.446976+07	\N
2201	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:13:50.108592+07	\N
2206	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:17:50.114703+07	\N
2208	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:19:10.116984+07	\N
2210	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:20:30.121242+07	\N
2212	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:21:50.127245+07	\N
2216	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:25:50.133597+07	\N
2218	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:27:50.139441+07	\N
2225	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:32:30.149849+07	\N
2226	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:33:50.1524+07	\N
2227	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:34:10.154217+07	\N
2230	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:36:50.160504+07	\N
2233	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:39:10.167899+07	\N
2528	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:20:30.687948+07	\N
2532	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:23:10.693348+07	\N
2539	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:28:30.706085+07	\N
2555	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:40:30.732395+07	\N
2690	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:21:50.973639+07	\N
2693	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:24:10.980383+07	\N
580	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 03:58:07.275242+07	\N
581	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 03:59:07.276175+07	\N
585	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:03:07.285746+07	\N
586	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:04:27.289521+07	\N
588	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:05:47.291915+07	\N
589	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:05:47.296513+07	\N
590	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:07:07.294582+07	\N
591	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:07:07.297532+07	\N
592	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:08:07.29903+07	\N
593	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:08:27.297733+07	\N
594	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:09:07.301158+07	\N
595	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:09:47.300664+07	\N
596	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:10:27.303981+07	\N
597	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:11:07.304985+07	\N
598	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:12:27.307228+07	\N
599	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:13:47.310437+07	\N
600	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:14:07.311667+07	\N
601	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:15:07.312767+07	\N
602	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:15:07.316105+07	\N
603	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:16:07.316644+07	\N
604	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:16:27.316192+07	\N
605	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:17:47.319071+07	\N
606	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:18:07.327901+07	\N
607	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:19:07.322504+07	\N
608	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:19:47.325694+07	\N
609	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:20:27.324965+07	\N
610	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:20:47.327788+07	\N
611	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:21:47.329213+07	\N
612	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:22:27.33204+07	\N
613	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:23:07.333125+07	\N
614	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:23:27.334544+07	\N
615	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:24:27.335517+07	\N
616	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:24:47.337066+07	\N
617	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:25:47.338584+07	\N
618	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:27:07.341499+07	\N
619	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:27:27.343589+07	\N
620	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:28:27.351926+07	\N
621	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:29:27.355508+07	\N
622	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:29:47.346881+07	\N
628	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:35:07.358606+07	\N
1374	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:57:48.652098+07	\N
1376	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 13:59:08.654685+07	\N
1392	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:11:08.682042+07	\N
1393	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:12:08.685432+07	\N
1395	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:13:28.688795+07	\N
1397	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:14:48.691886+07	\N
1398	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:15:08.691478+07	\N
1401	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:18:08.699537+07	\N
1402	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:19:08.701103+07	\N
1403	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:19:08.704116+07	\N
1404	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:20:28.704181+07	\N
1407	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:22:08.709218+07	\N
1411	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:24:48.715961+07	\N
1825	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:25:49.425281+07	\N
1828	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:28:29.432255+07	\N
1829	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:29:09.43469+07	\N
1833	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:32:09.441052+07	\N
1841	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:37:49.453258+07	\N
1842	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:39:09.454849+07	\N
1843	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:39:29.457555+07	\N
1854	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:49:49.479888+07	\N
1856	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:51:09.483354+07	\N
2215	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:25:10.133241+07	\N
2217	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:27:10.135598+07	\N
2220	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:29:30.143137+07	\N
2222	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:30:30.145338+07	\N
2223	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:31:10.14811+07	\N
2224	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:31:30.148282+07	\N
2236	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:41:50.171022+07	\N
2245	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:49:50.189663+07	\N
2538	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:27:10.703075+07	\N
2542	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:30:10.711953+07	\N
2545	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:32:30.718089+07	\N
2694	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:24:30.978838+07	\N
2696	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:25:50.98225+07	\N
2700	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:28:30.991207+07	\N
623	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:31:07.350303+07	\N
624	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:32:27.352901+07	\N
626	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:33:47.355598+07	\N
627	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:34:47.359185+07	\N
629	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:36:07.362867+07	\N
630	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:36:27.361695+07	\N
631	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:37:47.364683+07	\N
1385	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:05:48.669177+07	\N
1389	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:09:28.678411+07	\N
1396	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:13:48.688442+07	\N
1399	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:16:28.69474+07	\N
1408	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:23:08.710948+07	\N
1410	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:24:28.713813+07	\N
1412	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:25:48.717112+07	\N
1419	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:30:28.729695+07	\N
1831	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:30:29.437851+07	\N
1835	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:33:49.443388+07	\N
1837	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:35:09.446508+07	\N
1838	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:36:09.450443+07	\N
1839	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:36:29.449929+07	\N
1840	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:37:09.452352+07	\N
1844	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:40:29.458682+07	\N
1846	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:41:49.461294+07	\N
1847	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:42:49.463827+07	\N
1850	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:45:49.470663+07	\N
1852	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:47:49.476282+07	\N
1855	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:49:49.482702+07	\N
1857	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:51:09.485893+07	\N
2228	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:35:10.15577+07	\N
2231	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:37:50.162078+07	\N
2232	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:39:10.164725+07	\N
2234	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:40:30.168032+07	\N
2237	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:42:30.174318+07	\N
2238	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:43:10.175365+07	\N
2240	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:44:30.18147+07	\N
2243	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:47:10.187796+07	\N
2244	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:48:30.187813+07	\N
2247	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:51:10.193073+07	\N
2248	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:51:50.19695+07	\N
625	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:32:47.354882+07	\N
632	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:38:27.368281+07	\N
635	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:40:27.370297+07	\N
639	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:43:07.375591+07	\N
644	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:47:07.386284+07	\N
649	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:50:47.396264+07	\N
650	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:51:07.395686+07	\N
651	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:52:07.399247+07	\N
652	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:52:27.398452+07	\N
657	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:56:27.406574+07	\N
659	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:57:47.409817+07	\N
663	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:00:27.419187+07	\N
664	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:01:27.419948+07	\N
665	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:01:47.418192+07	\N
669	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:04:27.425401+07	\N
672	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:07:07.430864+07	\N
1400	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:17:48.698024+07	\N
1409	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:23:48.713902+07	\N
1413	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:26:28.72631+07	\N
1414	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:27:08.719866+07	\N
1416	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:28:28.72286+07	\N
1418	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:29:48.726589+07	\N
1424	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:33:48.734529+07	\N
1427	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:35:28.739501+07	\N
1428	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:36:28.74015+07	\N
1432	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:39:28.747832+07	\N
1434	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:40:48.75119+07	\N
1845	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:41:29.461627+07	\N
1848	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:43:09.46415+07	\N
1849	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:44:29.466784+07	\N
1851	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:47:09.473362+07	\N
2229	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:36:30.158945+07	\N
2235	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:41:30.172429+07	\N
2241	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:45:50.18157+07	\N
2242	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:47:10.184508+07	\N
2255	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:57:30.209589+07	\N
2258	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:59:10.212766+07	\N
2540	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:28:50.708007+07	\N
2544	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:32:30.714785+07	\N
633	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:39:07.368263+07	\N
634	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:39:27.369417+07	\N
636	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:40:47.372426+07	\N
637	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:41:47.373233+07	\N
638	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:42:27.375375+07	\N
640	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:44:27.378778+07	\N
641	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:45:27.382436+07	\N
642	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:45:47.382198+07	\N
643	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:46:27.385642+07	\N
645	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:47:47.389283+07	\N
646	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:48:27.389567+07	\N
647	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:49:07.397571+07	\N
648	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:49:47.39323+07	\N
653	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:53:47.401515+07	\N
654	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:54:07.403192+07	\N
655	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:55:07.404278+07	\N
656	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:56:07.406912+07	\N
658	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:57:27.410912+07	\N
660	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 04:59:07.412598+07	\N
661	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 04:59:07.415452+07	\N
662	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:00:27.415998+07	\N
666	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:02:47.424485+07	\N
667	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:03:07.482125+07	\N
668	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:03:47.425556+07	\N
670	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:04:47.426936+07	\N
671	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:05:47.428138+07	\N
673	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:07:07.433925+07	\N
674	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:08:27.434696+07	\N
675	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:09:27.4378+07	\N
676	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:09:47.439041+07	\N
677	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:10:47.442235+07	\N
678	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:11:07.439557+07	\N
679	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:12:07.446426+07	\N
680	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:12:27.442761+07	\N
681	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:13:07.446317+07	\N
682	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:13:47.445836+07	\N
683	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:15:07.448714+07	\N
684	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:16:27.451536+07	\N
685	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:16:27.455372+07	\N
687	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:19:07.45732+07	\N
1405	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:21:08.70776+07	\N
1406	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:21:48.7071+07	\N
1415	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:28:08.723199+07	\N
1417	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:29:08.726734+07	\N
1422	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:32:28.732819+07	\N
1425	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:33:48.737272+07	\N
1429	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:37:08.743514+07	\N
1430	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:37:48.74271+07	\N
1436	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:42:48.755552+07	\N
1437	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:43:08.754504+07	\N
1439	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:44:28.757996+07	\N
1440	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:45:48.761193+07	\N
1443	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:48:28.766584+07	\N
1853	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:48:29.476949+07	\N
2239	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:44:30.178043+07	\N
2246	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:49:50.192568+07	\N
2249	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:52:30.196329+07	\N
2250	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:53:50.199715+07	\N
2252	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:55:10.2035+07	\N
2260	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:00:50.218068+07	\N
2262	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:01:50.222353+07	\N
2263	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:03:10.224077+07	\N
2546	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:33:50.719096+07	\N
2550	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:36:30.739739+07	\N
2551	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:37:50.728399+07	\N
2552	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:38:50.732158+07	\N
2556	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:41:30.735953+07	\N
2558	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:42:30.737932+07	\N
2559	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:43:10.738859+07	\N
2560	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:44:30.742264+07	\N
2561	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:45:50.74655+07	\N
2563	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:47:10.748913+07	\N
2565	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:48:30.751637+07	\N
2569	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:51:10.75839+07	\N
2571	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:52:30.761425+07	\N
2575	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:56:30.770491+07	\N
2583	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:02:10.788387+07	\N
686	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:17:47.454448+07	\N
688	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:19:07.460182+07	\N
691	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:21:47.582577+07	\N
1420	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:31:08.729192+07	\N
1421	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:31:28.731429+07	\N
1423	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:32:48.734399+07	\N
1426	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:35:08.738196+07	\N
1435	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:41:48.751377+07	\N
1438	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:43:48.75727+07	\N
1441	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:45:48.765024+07	\N
1444	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:48:48.769482+07	\N
1858	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:52:29.48578+07	\N
1860	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:53:49.48965+07	\N
1862	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:55:09.491403+07	\N
1872	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:01:49.50811+07	\N
1877	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:04:29.512294+07	\N
2251	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:53:50.203097+07	\N
2253	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:56:10.207005+07	\N
2257	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 00:58:30.212671+07	\N
2259	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:00:30.215869+07	\N
2261	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:01:50.219212+07	\N
2548	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:35:10.720937+07	\N
2549	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:36:30.736325+07	\N
2554	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:39:50.733066+07	\N
2557	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:41:50.736149+07	\N
2564	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:47:10.752599+07	\N
2566	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:48:30.754197+07	\N
2567	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:49:50.755043+07	\N
2572	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:53:50.764845+07	\N
2573	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:54:10.767896+07	\N
2697	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:26:10.984952+07	\N
2701	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:29:50.991647+07	\N
2702	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:30:50.994923+07	\N
2706	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:33:51.000114+07	\N
2710	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:36:31.007191+07	\N
2711	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:36:51.008847+07	\N
2712	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:37:51.01049+07	\N
2715	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:39:11.015939+07	\N
689	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:20:27.460838+07	\N
690	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:20:47.463857+07	\N
693	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:23:07.466761+07	\N
695	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:24:27.471065+07	\N
696	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:25:47.473938+07	\N
698	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:27:07.476566+07	\N
1431	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:39:08.74652+07	\N
1433	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:40:28.748638+07	\N
1445	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:49:48.769673+07	\N
1446	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:50:08.771349+07	\N
1859	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:52:49.488089+07	\N
1867	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:57:49.501167+07	\N
2254	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:56:30.207185+07	\N
2256	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 00:57:50.208981+07	\N
2264	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:03:10.227591+07	\N
2265	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:04:30.228215+07	\N
2266	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:05:30.231163+07	\N
2267	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:05:50.231736+07	\N
2268	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:06:30.235236+07	\N
2269	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:07:10.233988+07	\N
2273	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:10:30.244406+07	\N
2276	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:12:30.250766+07	\N
2282	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:17:10.257367+07	\N
2283	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:17:50.257524+07	\N
2290	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:23:10.270591+07	\N
2553	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:39:10.730373+07	\N
2562	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:45:50.749202+07	\N
2570	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:52:10.762189+07	\N
2576	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:56:50.772621+07	\N
2577	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:57:50.774106+07	\N
2582	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:01:50.784968+07	\N
2704	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:32:30.997155+07	\N
2705	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:32:51.000011+07	\N
2708	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:35:11.004027+07	\N
2709	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:35:31.005578+07	\N
2716	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:40:31.016111+07	\N
2721	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:43:11.025366+07	\N
2756	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:08:31.084894+07	\N
2762	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:12:31.093475+07	\N
692	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:22:27.468402+07	\N
694	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:23:27.469325+07	\N
697	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:26:07.475651+07	\N
699	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:28:27.479546+07	\N
700	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:28:27.482464+07	\N
701	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:29:27.483509+07	\N
702	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:29:47.482331+07	\N
703	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:31:07.486004+07	\N
704	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:31:07.489788+07	\N
705	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:32:27.489258+07	\N
706	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:33:47.492597+07	\N
707	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:34:47.495963+07	\N
708	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:35:07.495687+07	\N
709	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:36:27.498287+07	\N
710	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:36:47.501452+07	\N
711	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:37:47.501209+07	\N
712	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:39:07.504658+07	\N
713	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:39:27.506569+07	\N
714	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:40:27.507633+07	\N
715	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:41:47.511015+07	\N
716	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:41:47.51454+07	\N
717	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:43:07.515174+07	\N
718	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:43:27.515715+07	\N
719	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:44:27.516814+07	\N
720	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:45:47.519974+07	\N
721	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:45:47.523576+07	\N
722	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:47:07.523398+07	\N
723	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:47:07.526176+07	\N
724	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:48:27.526403+07	\N
725	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:48:27.534479+07	\N
726	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:49:47.529728+07	\N
727	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:51:07.533243+07	\N
728	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:51:47.535878+07	\N
729	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:52:27.536018+07	\N
730	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:53:47.54013+07	\N
731	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:54:47.543192+07	\N
732	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:55:07.542793+07	\N
733	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:56:27.545408+07	\N
735	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:57:47.549477+07	\N
734	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:57:07.547695+07	\N
742	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:03:07.5615+07	\N
1442	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:47:08.763788+07	\N
1861	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:53:49.49263+07	\N
1865	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:56:29.499009+07	\N
1866	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:57:49.498532+07	\N
1868	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:58:49.506327+07	\N
1870	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:00:29.504624+07	\N
1875	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:04:04.918785+07	\N
1880	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:06:09.518157+07	\N
1885	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:08:29.524537+07	\N
1896	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:17:49.54367+07	\N
2270	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:08:10.239176+07	\N
2277	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:13:50.250203+07	\N
2279	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:15:10.252402+07	\N
2280	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:15:50.254833+07	\N
2284	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:18:10.267576+07	\N
2288	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:21:30.26803+07	\N
2289	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:21:50.267579+07	\N
2291	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:23:30.272811+07	\N
2296	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:27:10.280531+07	\N
2298	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:28:10.28529+07	\N
2300	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:29:10.287496+07	\N
2568	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:50:10.757128+07	\N
2574	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:55:10.768576+07	\N
2578	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 04:58:10.776554+07	\N
2579	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 04:59:10.778794+07	\N
2581	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:00:50.783934+07	\N
2584	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:03:10.787625+07	\N
2585	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:03:10.791879+07	\N
2587	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:04:30.793693+07	\N
2707	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:33:51.003797+07	\N
2760	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:11:11.093528+07	\N
2761	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:12:11.094051+07	\N
2792	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:35:51.149568+07	\N
2801	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:41:51.163075+07	\N
2808	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:46:51.175504+07	\N
736	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:58:27.551533+07	\N
741	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:01:47.558966+07	\N
743	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:03:47.56553+07	\N
1447	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:51:08.77234+07	\N
1448	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:51:48.775214+07	\N
1453	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:55:08.781162+07	\N
1460	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:00:28.794864+07	\N
1461	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:00:48.796894+07	\N
1462	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:01:48.798195+07	\N
1471	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:08:28.814538+07	\N
1477	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:13:48.827102+07	\N
1479	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:15:08.830963+07	\N
1863	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 19:55:09.494769+07	\N
1864	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:56:29.495832+07	\N
1869	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 19:59:09.501377+07	\N
1873	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:01:49.511858+07	\N
1874	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:03:09.510721+07	\N
1890	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:12:29.530977+07	\N
1891	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:12:49.534588+07	\N
1902	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:21:49.5524+07	\N
2271	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:08:30.238781+07	\N
2281	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:16:30.254972+07	\N
2286	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:19:50.264383+07	\N
2294	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:25:50.276867+07	\N
2295	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:26:10.279311+07	\N
2297	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:27:10.283653+07	\N
2301	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:29:50.287239+07	\N
2580	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:00:30.781712+07	\N
2586	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:04:30.790526+07	\N
2589	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:06:50.798069+07	\N
2591	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:08:30.800675+07	\N
2594	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:11:10.824704+07	\N
2601	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:15:30.822769+07	\N
2603	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:16:50.822509+07	\N
2607	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:20:30.830808+07	\N
2608	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:20:50.832126+07	\N
2610	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:22:50.838505+07	\N
2713	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:37:51.01393+07	\N
2714	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:39:11.012782+07	\N
737	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 05:59:07.551293+07	\N
738	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 05:59:47.555079+07	\N
739	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:00:27.555987+07	\N
740	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:01:07.562262+07	\N
744	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:04:27.565176+07	\N
745	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:05:07.568242+07	\N
746	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:05:47.568317+07	\N
747	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:06:07.569974+07	\N
748	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:07:07.570949+07	\N
749	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:07:47.573673+07	\N
750	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:08:27.573448+07	\N
751	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:09:27.576737+07	\N
752	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:09:47.577166+07	\N
753	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:10:47.580493+07	\N
754	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:11:07.579925+07	\N
755	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:11:47.582546+07	\N
756	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:12:27.582348+07	\N
757	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:12:47.585185+07	\N
758	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:13:47.585232+07	\N
759	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:14:07.586858+07	\N
760	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:15:07.588018+07	\N
761	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:15:47.591959+07	\N
762	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:16:27.590246+07	\N
763	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:17:47.593703+07	\N
764	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:17:47.596633+07	\N
765	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:18:47.596838+07	\N
766	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:19:07.596755+07	\N
767	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:20:07.600675+07	\N
768	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:20:27.600599+07	\N
769	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:21:47.603093+07	\N
770	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:22:07.604525+07	\N
771	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:23:07.606225+07	\N
772	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:23:27.607955+07	\N
773	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:24:27.609043+07	\N
774	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:24:27.61239+07	\N
775	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:25:27.612725+07	\N
776	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:25:47.612768+07	\N
777	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:27:07.615451+07	\N
778	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:27:27.61726+07	\N
780	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:29:47.622441+07	\N
784	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:32:27.633336+07	\N
787	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:35:07.636855+07	\N
789	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:36:27.638045+07	\N
790	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:37:47.640289+07	\N
1449	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:52:28.775485+07	\N
1452	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:54:28.781133+07	\N
1455	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:56:28.785151+07	\N
1456	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:57:48.787745+07	\N
1459	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:59:28.792846+07	\N
1871	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:00:29.507751+07	\N
1876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:04:09.513058+07	\N
1881	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:06:27.340514+07	\N
1884	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:08:29.5216+07	\N
1886	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:09:29.525266+07	\N
1888	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:11:09.531441+07	\N
1889	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:11:49.531393+07	\N
1894	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:16:29.540369+07	\N
1895	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:16:29.543565+07	\N
1899	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:20:09.549798+07	\N
1903	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:23:09.556181+07	\N
1907	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:25:49.562136+07	\N
1910	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:27:49.568354+07	\N
1911	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:28:29.569315+07	\N
2272	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:09:50.24165+07	\N
2274	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:11:10.244299+07	\N
2275	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:12:30.247511+07	\N
2278	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:14:30.25265+07	\N
2285	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:19:10.260825+07	\N
2287	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:20:30.264183+07	\N
2293	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:25:10.277237+07	\N
2299	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:28:30.284139+07	\N
2302	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:31:10.29185+07	\N
2304	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:32:30.293221+07	\N
2307	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:34:10.299228+07	\N
2309	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:35:30.302871+07	\N
2313	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:39:10.313985+07	\N
779	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:28:27.618491+07	\N
781	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:31:07.626362+07	\N
785	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:33:47.632733+07	\N
786	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:35:07.63381+07	\N
788	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:36:07.639364+07	\N
1450	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:53:08.778221+07	\N
1457	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:57:48.791329+07	\N
1458	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:59:08.790938+07	\N
1463	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:01:48.80098+07	\N
1469	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:07:08.811681+07	\N
1470	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:08:08.815412+07	\N
1472	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:09:08.819246+07	\N
1474	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:11:08.820926+07	\N
1476	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:12:28.82384+07	\N
1878	2efeb3d2-7c8e-4763-9a5f-5784853467cb	4c81b8a8-6123-4134-b8ce-a0be2b2500f3	092d9377-d458-4ac0-98a1-fcb1982508cf	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:05:26.119391+07	\N
1879	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:05:49.515859+07	\N
1882	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:07:09.518329+07	\N
1883	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:07:09.520983+07	\N
1900	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:20:29.54935+07	\N
1901	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:21:29.552783+07	\N
1905	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:24:29.559391+07	\N
1908	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:26:29.564419+07	\N
1909	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:27:09.5665+07	\N
1919	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:33:49.583519+07	\N
1920	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:35:09.583609+07	\N
2292	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:24:30.275218+07	\N
2303	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:31:30.292053+07	\N
2305	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:32:30.297415+07	\N
2306	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:33:50.297756+07	\N
2310	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:36:30.303954+07	\N
2311	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:37:50.307076+07	\N
2312	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:39:10.311339+07	\N
2314	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:40:30.314952+07	\N
2315	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:40:50.316939+07	\N
2319	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:44:30.323853+07	\N
2324	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:49:10.336412+07	\N
2327	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:51:10.339955+07	\N
2329	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:52:30.343199+07	\N
2588	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:05:50.79654+07	\N
782	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:31:27.627046+07	\N
1451	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 14:53:48.777479+07	\N
1454	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 14:56:08.78418+07	\N
1887	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:09:49.524821+07	\N
1892	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:13:49.53411+07	\N
1893	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:15:09.536923+07	\N
1897	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:18:29.546831+07	\N
1898	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:19:09.54644+07	\N
1904	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:23:09.559666+07	\N
1906	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:24:49.561661+07	\N
1916	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:32:29.577798+07	\N
1922	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:36:29.586829+07	\N
1924	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:37:49.589672+07	\N
2308	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:35:10.300342+07	\N
2325	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:49:50.336405+07	\N
2330	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:53:50.346649+07	\N
2332	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:55:30.353186+07	\N
2333	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:56:30.352557+07	\N
2337	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:00:10.361867+07	\N
2338	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:00:30.360868+07	\N
2339	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:01:50.364445+07	\N
2342	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:03:10.371759+07	\N
2590	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:07:10.797029+07	\N
2593	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:09:50.804448+07	\N
2596	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:12:30.809791+07	\N
2606	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:19:10.827876+07	\N
2611	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:23:10.836384+07	\N
2614	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:25:50.842624+07	\N
2617	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:27:30.847584+07	\N
2622	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:31:10.856931+07	\N
2717	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:40:31.019588+07	\N
2724	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:46:11.031095+07	\N
2728	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:49:31.039126+07	\N
2729	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:49:51.038979+07	\N
2730	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:50:31.041462+07	\N
2733	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:52:31.044825+07	\N
2735	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:53:51.047984+07	\N
2737	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:55:31.053653+07	\N
2738	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:56:31.054157+07	\N
783	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:32:27.62978+07	\N
791	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:38:27.6432+07	\N
792	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:39:07.644129+07	\N
793	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:40:07.647656+07	\N
794	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:40:27.648025+07	\N
795	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:41:47.649026+07	\N
796	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:41:47.652501+07	\N
797	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:43:07.653036+07	\N
798	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:43:07.656998+07	\N
799	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:44:27.656426+07	\N
800	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:45:47.658028+07	\N
801	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:46:07.660441+07	\N
802	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:47:07.661077+07	\N
803	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:47:27.662685+07	\N
804	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:48:27.664161+07	\N
805	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:49:47.66707+07	\N
806	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:51:07.670351+07	\N
807	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:52:07.673578+07	\N
808	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:52:27.672813+07	\N
809	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:53:47.674927+07	\N
810	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:53:47.677716+07	\N
811	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:55:07.678501+07	\N
812	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:55:07.681406+07	\N
813	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:56:27.681386+07	\N
814	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:57:27.685379+07	\N
815	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:57:47.684671+07	\N
816	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 06:59:07.688975+07	\N
817	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 06:59:07.692106+07	\N
818	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:00:27.691416+07	\N
819	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:00:47.694187+07	\N
820	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:01:47.69461+07	\N
821	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:02:27.69803+07	\N
822	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:03:07.697742+07	\N
823	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:04:27.701253+07	\N
824	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:05:47.703067+07	\N
825	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:06:47.706526+07	\N
826	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:07:07.705525+07	\N
827	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:08:27.708701+07	\N
828	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:08:47.710776+07	\N
829	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:09:47.714579+07	\N
830	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:10:07.71514+07	\N
831	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:11:07.716508+07	\N
832	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:11:27.718266+07	\N
833	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:12:27.718385+07	\N
834	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:13:47.722493+07	\N
835	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:13:47.72707+07	\N
836	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:15:07.726175+07	\N
837	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:16:27.728272+07	\N
838	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:17:27.732015+07	\N
839	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:17:47.731465+07	\N
840	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:19:07.734524+07	\N
841	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:19:07.736983+07	\N
842	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:20:07.738366+07	\N
843	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:20:27.737667+07	\N
844	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:21:27.74114+07	\N
845	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:21:47.740882+07	\N
846	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:23:07.74469+07	\N
847	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:23:47.747871+07	\N
848	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:24:27.746721+07	\N
849	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:25:47.749651+07	\N
850	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:25:47.75314+07	\N
851	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:27:07.752572+07	\N
852	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:27:47.754878+07	\N
853	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:28:27.755343+07	\N
854	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:29:47.758231+07	\N
855	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:31:07.760926+07	\N
856	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:31:07.763948+07	\N
857	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:32:27.76351+07	\N
858	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:33:47.766413+07	\N
859	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:33:47.768829+07	\N
860	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:34:47.770254+07	\N
861	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:35:07.769576+07	\N
862	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:36:27.772324+07	\N
863	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:37:27.776073+07	\N
864	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:37:47.774945+07	\N
865	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:38:27.778142+07	\N
866	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:39:07.778895+07	\N
867	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:39:47.78724+07	\N
868	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:40:27.78206+07	\N
869	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:41:27.784322+07	\N
870	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:41:47.784006+07	\N
871	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:43:07.787762+07	\N
872	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:43:27.789717+07	\N
874	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:44:47.792396+07	\N
875	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:45:47.793373+07	\N
878	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:47:07.799672+07	\N
880	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:48:47.801009+07	\N
882	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:50:27.803978+07	\N
883	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:51:07.804197+07	\N
884	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:51:27.806538+07	\N
886	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:52:47.81+07	\N
888	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:53:47.813603+07	\N
891	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:56:27.816281+07	\N
896	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:00:07.8252+07	\N
898	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:01:47.828071+07	\N
900	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:02:47.831538+07	\N
904	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:05:47.836533+07	\N
905	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:06:27.839193+07	\N
909	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:09:47.845738+07	\N
1464	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:03:08.801743+07	\N
1465	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:03:08.806823+07	\N
1468	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:05:48.812562+07	\N
1473	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:09:48.817373+07	\N
1475	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:11:08.824528+07	\N
1481	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:16:28.832795+07	\N
1486	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:20:28.840914+07	\N
1488	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:21:48.84402+07	\N
1491	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:23:28.849801+07	\N
1912	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:29:29.573988+07	\N
1913	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:29:49.572111+07	\N
1925	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:38:09.591797+07	\N
1928	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:40:29.595754+07	\N
1933	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:44:29.606278+07	\N
1937	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:47:09.612412+07	\N
1943	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:52:29.622671+07	\N
1944	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:52:49.62497+07	\N
873	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:44:27.790291+07	\N
876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:46:07.79516+07	\N
879	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:48:27.798491+07	\N
885	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:52:27.8075+07	\N
1466	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:04:28.805568+07	\N
1467	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:05:48.808598+07	\N
1478	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:14:08.828525+07	\N
1482	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:16:48.834641+07	\N
1484	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:18:08.83882+07	\N
1492	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:24:28.851579+07	\N
1500	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:31:08.866694+07	\N
1914	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:30:49.576593+07	\N
1915	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:31:09.575543+07	\N
1917	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:32:49.579597+07	\N
1921	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:35:49.586444+07	\N
1927	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:39:09.596023+07	\N
1929	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:40:29.598384+07	\N
1931	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:43:09.602684+07	\N
1939	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:48:29.61475+07	\N
1940	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:49:49.617714+07	\N
1941	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:50:29.620411+07	\N
1952	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:58:09.636907+07	\N
1953	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:59:09.637597+07	\N
2316	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:41:50.318387+07	\N
2321	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:45:50.32752+07	\N
2323	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:48:30.334347+07	\N
2326	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:50:30.339281+07	\N
2592	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:08:50.804057+07	\N
2595	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:11:50.81071+07	\N
2597	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:13:30.814042+07	\N
2598	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:13:50.813889+07	\N
2599	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:14:30.817413+07	\N
2602	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:16:30.820346+07	\N
2613	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:25:10.841573+07	\N
2615	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:26:30.847471+07	\N
2616	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:27:10.845715+07	\N
2619	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:28:30.853103+07	\N
2621	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:30:10.862696+07	\N
877	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:47:07.795997+07	\N
881	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:49:47.801938+07	\N
887	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:53:47.810622+07	\N
889	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:55:07.814148+07	\N
890	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:55:07.817108+07	\N
892	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:56:27.819139+07	\N
893	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:57:47.818961+07	\N
894	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 07:57:47.821642+07	\N
895	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 07:59:07.821605+07	\N
897	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:00:27.824953+07	\N
899	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:01:47.831062+07	\N
901	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:03:07.83129+07	\N
902	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:04:27.833112+07	\N
903	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:04:47.835176+07	\N
906	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:07:07.839534+07	\N
907	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:08:27.842946+07	\N
908	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:08:47.844978+07	\N
910	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:10:07.84899+07	\N
911	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:11:07.848777+07	\N
912	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:11:27.851188+07	\N
913	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:12:27.851739+07	\N
914	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:13:47.855381+07	\N
915	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:13:47.858349+07	\N
916	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:14:47.86022+07	\N
917	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:15:07.85994+07	\N
918	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:16:27.862511+07	\N
919	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:16:47.863918+07	\N
920	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:17:47.865451+07	\N
921	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:18:07.867935+07	\N
922	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:19:07.86853+07	\N
923	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:19:27.87119+07	\N
924	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:20:27.87197+07	\N
925	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:21:47.88119+07	\N
926	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:21:47.884942+07	\N
927	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:23:07.878909+07	\N
928	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:24:07.883252+07	\N
929	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:24:27.883576+07	\N
930	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:25:27.884853+07	\N
931	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:25:47.88706+07	\N
932	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:27:07.887714+07	\N
933	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:27:07.890619+07	\N
934	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:28:27.890211+07	\N
939	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:32:27.897653+07	\N
940	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:32:27.900306+07	\N
943	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:35:07.903207+07	\N
945	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:36:27.906999+07	\N
947	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:37:47.908904+07	\N
950	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:40:27.915104+07	\N
1480	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:15:28.831755+07	\N
1483	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:17:48.834282+07	\N
1485	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:19:08.83854+07	\N
1487	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:20:28.843853+07	\N
1489	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:22:08.847451+07	\N
1490	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:23:08.848063+07	\N
1494	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:25:48.855195+07	\N
1495	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:27:08.858267+07	\N
1499	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:29:48.863183+07	\N
1507	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:36:28.879127+07	\N
1510	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:39:08.886194+07	\N
1513	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:40:48.891537+07	\N
1515	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:43:08.894879+07	\N
1918	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:33:49.580496+07	\N
1923	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:36:49.589069+07	\N
1926	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:39:09.59237+07	\N
1935	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:45:49.609158+07	\N
1936	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:46:49.612069+07	\N
1942	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:51:09.620199+07	\N
1945	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:53:49.625995+07	\N
1947	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:54:49.629711+07	\N
1948	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:55:09.629336+07	\N
1950	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:57:09.634371+07	\N
2317	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:43:10.32128+07	\N
2318	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:43:50.324375+07	\N
2320	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:44:50.326546+07	\N
2322	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:47:10.330591+07	\N
2328	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:52:10.34379+07	\N
2334	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 01:57:30.358572+07	\N
2335	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:57:50.355393+07	\N
935	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:29:27.894189+07	\N
938	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:31:07.898044+07	\N
941	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:33:47.900742+07	\N
944	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:35:47.906372+07	\N
1493	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:25:28.855237+07	\N
1496	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:27:28.859736+07	\N
1501	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:31:08.869564+07	\N
1503	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:33:08.872474+07	\N
1509	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:37:48.882181+07	\N
1511	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:39:08.890039+07	\N
1516	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:43:28.896917+07	\N
1521	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:47:08.905342+07	\N
1930	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:41:49.599461+07	\N
1932	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:43:49.606177+07	\N
1934	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:44:49.608031+07	\N
1938	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:47:49.614276+07	\N
1946	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:53:49.628179+07	\N
1951	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:57:49.634356+07	\N
1958	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:03:09.646675+07	\N
1959	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:03:09.649483+07	\N
1963	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:06:09.659646+07	\N
2331	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:55:10.349454+07	\N
2336	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 01:59:10.358491+07	\N
2340	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:02:10.367181+07	\N
2341	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:03:10.368335+07	\N
2345	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:05:50.375393+07	\N
2346	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:06:30.379578+07	\N
2351	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:09:50.38485+07	\N
2352	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:10:30.389851+07	\N
2600	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:15:10.817648+07	\N
2604	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:17:50.823836+07	\N
2605	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:18:30.826905+07	\N
2609	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:21:50.833044+07	\N
2612	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:24:30.838873+07	\N
2618	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:28:30.850205+07	\N
2627	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:35:10.867784+07	\N
2629	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:36:30.871722+07	\N
2636	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:42:30.88402+07	\N
936	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:29:47.893112+07	\N
942	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:34:07.902805+07	\N
1497	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:28:28.861065+07	\N
1498	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:29:28.864019+07	\N
1502	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:32:28.870175+07	\N
1505	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:34:48.876606+07	\N
1512	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:40:28.889234+07	\N
1517	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:44:28.898207+07	\N
1527	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:51:08.917918+07	\N
1528	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:52:28.918435+07	\N
1529	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:52:48.920158+07	\N
1531	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:53:48.924098+07	\N
1949	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 20:56:29.631723+07	\N
1954	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 20:59:29.639047+07	\N
1965	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:07:49.659481+07	\N
1966	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:08:29.660233+07	\N
1975	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:14:29.675554+07	\N
1979	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:17:49.683653+07	\N
1982	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:20:29.68965+07	\N
1983	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:20:49.691331+07	\N
2343	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:04:30.371454+07	\N
2620	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:29:50.853155+07	\N
2623	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:32:30.859082+07	\N
2625	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:33:50.862478+07	\N
2633	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:40:30.877735+07	\N
2634	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:41:10.881703+07	\N
2637	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:43:10.88443+07	\N
2638	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:43:30.88622+07	\N
2718	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:41:51.018451+07	\N
2719	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:42:11.019892+07	\N
2720	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:43:11.022284+07	\N
2722	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:44:31.026213+07	\N
2723	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:45:51.028727+07	\N
2727	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:48:31.035952+07	\N
2736	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:55:11.051145+07	\N
2742	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:59:11.061826+07	\N
2763	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:13:51.096191+07	\N
2764	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:15:11.099009+07	\N
2765	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:15:51.103935+07	\N
937	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:31:07.894563+07	\N
946	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:37:27.910033+07	\N
948	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:38:27.911475+07	\N
949	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:39:07.911645+07	\N
951	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:40:47.917986+07	\N
952	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:41:47.918531+07	\N
953	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:43:07.921001+07	\N
954	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:43:47.923905+07	\N
955	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:44:27.923515+07	\N
956	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:45:27.92742+07	\N
957	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:45:47.926658+07	\N
958	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:47:07.929716+07	\N
959	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:47:27.93199+07	\N
960	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:48:27.932531+07	\N
961	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:48:47.933629+07	\N
962	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:49:47.934357+07	\N
963	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:51:07.937835+07	\N
964	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:51:07.940771+07	\N
965	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:52:27.940685+07	\N
966	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:52:47.942441+07	\N
967	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:53:47.943443+07	\N
968	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:53:47.946114+07	\N
969	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:54:47.947119+07	\N
970	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:55:07.946848+07	\N
971	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:56:27.949778+07	\N
972	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:57:07.952697+07	\N
973	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:57:47.952806+07	\N
974	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:58:07.954047+07	\N
975	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 08:59:07.954442+07	\N
976	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 08:59:07.957864+07	\N
977	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:00:27.957769+07	\N
978	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:00:47.960036+07	\N
979	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:01:47.960666+07	\N
980	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:02:27.963442+07	\N
981	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:03:07.963377+07	\N
982	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:04:27.966083+07	\N
983	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:04:47.967622+07	\N
984	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:05:47.968835+07	\N
985	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:06:47.974417+07	\N
986	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:07:07.972228+07	\N
987	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:08:07.976455+07	\N
988	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:08:27.974792+07	\N
989	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:09:47.978155+07	\N
992	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:12:27.984775+07	\N
999	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:18:07.99776+07	\N
1001	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:19:48.000861+07	\N
1004	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:23:08.006784+07	\N
1006	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:24:28.009224+07	\N
1009	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:27:08.015751+07	\N
1011	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:28:28.018238+07	\N
1504	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:33:48.873585+07	\N
1506	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:35:08.8765+07	\N
1508	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:37:08.883816+07	\N
1514	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:41:48.891756+07	\N
1518	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:45:08.901099+07	\N
1520	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:46:08.903819+07	\N
1523	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:48:28.908166+07	\N
1526	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:51:08.915037+07	\N
1530	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:53:48.920994+07	\N
1535	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:57:28.930905+07	\N
1544	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:03:08.945217+07	\N
1955	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:00:29.64019+07	\N
1957	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:02:09.64514+07	\N
1960	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:04:29.649946+07	\N
1962	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:05:49.653251+07	\N
1964	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:07:09.65725+07	\N
1972	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:12:29.66933+07	\N
1976	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:15:09.67589+07	\N
1977	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:16:29.679416+07	\N
1978	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:17:09.683112+07	\N
1984	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:21:49.691954+07	\N
1985	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:23:09.695353+07	\N
1990	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:26:49.705309+07	\N
2344	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:05:30.375679+07	\N
2350	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:09:10.385851+07	\N
2353	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:11:10.389308+07	\N
2624	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:32:30.861828+07	\N
990	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:10:07.980295+07	\N
994	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:14:07.989058+07	\N
998	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:17:47.995603+07	\N
1519	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:45:48.902477+07	\N
1522	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:47:48.910186+07	\N
1533	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:55:08.928246+07	\N
1536	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:57:48.930709+07	\N
1537	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:58:28.933274+07	\N
1538	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:59:08.936136+07	\N
1542	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:01:48.942661+07	\N
1551	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:08:48.956533+07	\N
1553	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:10:48.960974+07	\N
1556	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:12:28.967344+07	\N
1956	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:01:49.64322+07	\N
1961	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:05:09.65293+07	\N
1967	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:09:09.66571+07	\N
1969	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:10:29.66658+07	\N
1980	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:18:49.686884+07	\N
1989	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:25:49.701493+07	\N
1991	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:27:09.705441+07	\N
1993	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:28:29.708778+07	\N
2347	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:07:10.38404+07	\N
2348	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:07:50.382157+07	\N
2349	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:08:30.382267+07	\N
2626	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:35:10.865188+07	\N
2725	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:47:11.031309+07	\N
2768	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:17:51.105089+07	\N
2769	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:18:31.107273+07	\N
2771	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:19:31.110653+07	\N
2772	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:20:31.111714+07	\N
2773	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:21:11.115006+07	\N
2779	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:25:11.124241+07	\N
2780	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:25:51.125999+07	\N
2786	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:31:11.137619+07	\N
2793	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:36:31.148939+07	\N
2798	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:39:51.159468+07	\N
2803	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:43:11.166243+07	\N
2810	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:48:31.179539+07	\N
991	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:11:07.98134+07	\N
993	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:13:47.987025+07	\N
995	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:15:07.989323+07	\N
997	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:16:27.992735+07	\N
1000	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:19:07.998176+07	\N
1002	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:20:28.00076+07	\N
1003	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:21:48.003646+07	\N
1010	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:28:08.019032+07	\N
1013	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:29:48.024514+07	\N
1015	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:31:08.028959+07	\N
1017	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:33:08.030572+07	\N
1019	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:35:08.0333+07	\N
1524	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:49:48.911217+07	\N
1525	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:49:48.914792+07	\N
1532	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:55:08.924898+07	\N
1534	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 15:56:28.9292+07	\N
1543	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:03:08.942283+07	\N
1546	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:05:48.95069+07	\N
1557	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:13:48.966387+07	\N
1559	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:15:08.972196+07	\N
1968	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:09:49.663635+07	\N
1970	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:11:09.666574+07	\N
1971	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:11:29.66819+07	\N
1973	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:12:29.671926+07	\N
1974	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:13:49.672416+07	\N
1981	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:19:09.686374+07	\N
1986	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:23:49.698042+07	\N
1988	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:25:29.701306+07	\N
1992	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:27:49.708717+07	\N
1994	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:29:49.712514+07	\N
1995	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:31:09.716234+07	\N
2354	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:12:10.391785+07	\N
2356	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:13:50.395168+07	\N
2358	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:15:10.398536+07	\N
2362	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:17:50.404844+07	\N
2366	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:20:30.410531+07	\N
2368	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:21:50.413707+07	\N
2369	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:22:30.416981+07	\N
2370	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:23:10.417215+07	\N
996	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:15:47.992325+07	\N
1005	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:23:28.008675+07	\N
1007	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:25:48.012288+07	\N
1008	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:26:28.01498+07	\N
1012	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:29:48.021089+07	\N
1014	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:31:08.024935+07	\N
1016	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:32:28.026646+07	\N
1018	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:33:48.02986+07	\N
1020	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:35:08.035947+07	\N
1021	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:36:28.034374+07	\N
1022	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:37:28.038367+07	\N
1023	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:37:48.03701+07	\N
1024	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:39:08.040483+07	\N
1025	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:40:28.044172+07	\N
1026	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:41:08.047995+07	\N
1027	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:41:48.049145+07	\N
1028	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:42:48.052468+07	\N
1029	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:43:08.051672+07	\N
1030	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:43:48.054578+07	\N
1031	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:44:28.054853+07	\N
1032	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:45:28.059189+07	\N
1033	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:45:48.057765+07	\N
1034	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:47:08.060519+07	\N
1035	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:47:08.063265+07	\N
1036	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:48:28.063422+07	\N
1037	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:48:48.0652+07	\N
1038	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:49:48.066965+07	\N
1039	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:49:48.069871+07	\N
1040	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:51:08.069832+07	\N
1041	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:52:08.073808+07	\N
1042	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:52:28.072761+07	\N
1043	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:53:28.075609+07	\N
1044	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:53:48.075923+07	\N
1045	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:54:28.079968+07	\N
1046	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:55:08.079482+07	\N
1047	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:55:48.082147+07	\N
1048	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:56:28.082176+07	\N
1049	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 09:57:28.086006+07	\N
1050	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:57:48.086079+07	\N
1051	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 09:59:08.088534+07	\N
1052	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:00:08.092838+07	\N
1053	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:00:28.090859+07	\N
1054	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:01:28.093787+07	\N
1057	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:03:08.097406+07	\N
1059	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:04:28.102606+07	\N
1062	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:06:28.106651+07	\N
1064	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:08:08.110087+07	\N
1067	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:10:28.115614+07	\N
1068	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:11:08.115187+07	\N
1069	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:11:28.117277+07	\N
1071	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:12:28.122244+07	\N
1073	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:14:28.124443+07	\N
1078	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:17:48.130568+07	\N
1081	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:19:08.135817+07	\N
1083	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:21:28.140883+07	\N
1089	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:25:48.150262+07	\N
1090	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:26:08.152337+07	\N
1539	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 15:59:28.934977+07	\N
1540	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:00:28.936472+07	\N
1541	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:01:48.939342+07	\N
1547	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:05:48.953959+07	\N
1550	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:08:28.954522+07	\N
1554	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:11:08.960055+07	\N
1558	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:15:08.969203+07	\N
1561	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:17:08.975019+07	\N
1570	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:23:48.990211+07	\N
1574	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:26:48.998615+07	\N
1987	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:24:29.698207+07	\N
1996	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:31:09.720539+07	\N
1998	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:32:49.720892+07	\N
2000	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:34:09.725049+07	\N
2001	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:35:09.725957+07	\N
2006	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:39:09.734959+07	\N
2011	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:42:49.743451+07	\N
2014	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:44:29.749141+07	\N
2015	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:45:49.749159+07	\N
1055	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:01:48.094232+07	\N
1058	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:04:08.100989+07	\N
1545	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:04:28.945386+07	\N
1548	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:07:08.952029+07	\N
1549	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:07:28.953573+07	\N
1552	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:09:48.957484+07	\N
1555	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:12:28.963983+07	\N
1562	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:17:48.97447+07	\N
1566	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:20:48.983873+07	\N
1568	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:22:28.988258+07	\N
1569	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:23:08.987477+07	\N
1572	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:24:48.991897+07	\N
1573	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:25:48.993209+07	\N
1579	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:31:09.005839+07	\N
1997	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:32:29.718702+07	\N
2007	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:40:09.74037+07	\N
2008	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:40:29.737506+07	\N
2010	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:41:49.740518+07	\N
2012	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:43:09.743772+07	\N
2021	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:51:09.760727+07	\N
2026	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:54:29.769857+07	\N
2029	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:56:49.775503+07	\N
2033	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:00:29.78285+07	\N
2355	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:12:30.39176+07	\N
2372	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:24:30.42008+07	\N
2377	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:27:50.429328+07	\N
2379	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:29:30.431877+07	\N
2381	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:31:10.435536+07	\N
2628	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:36:30.868049+07	\N
2630	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:37:50.870882+07	\N
2631	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:38:10.87348+07	\N
2632	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:39:10.873992+07	\N
2639	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:44:30.886415+07	\N
2726	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:47:51.035862+07	\N
2731	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:51:11.042402+07	\N
2734	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:53:31.048518+07	\N
2740	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:57:51.05768+07	\N
2744	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:00:31.064751+07	\N
2747	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:02:11.07162+07	\N
1056	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:02:48.097768+07	\N
1060	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:05:08.103289+07	\N
1061	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:05:48.10376+07	\N
1063	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:07:08.106586+07	\N
1065	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:08:28.109555+07	\N
1066	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:09:48.112653+07	\N
1070	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:12:28.119505+07	\N
1072	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:13:48.122579+07	\N
1074	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:15:08.124535+07	\N
1075	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:16:08.128829+07	\N
1076	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:16:28.128106+07	\N
1077	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:17:08.130752+07	\N
1079	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:18:08.13327+07	\N
1080	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:19:08.133239+07	\N
1082	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:20:28.136724+07	\N
1084	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:21:48.139754+07	\N
1085	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:22:28.145732+07	\N
1086	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:23:08.143045+07	\N
1087	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:24:08.147094+07	\N
1088	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:24:28.146327+07	\N
1091	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:27:08.153481+07	\N
1092	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:27:48.156902+07	\N
1093	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:28:28.157109+07	\N
1094	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:28:48.158896+07	\N
1095	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:29:48.159291+07	\N
1096	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:31:08.161935+07	\N
1097	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:32:28.166522+07	\N
1098	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:33:28.170461+07	\N
1099	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:33:48.169082+07	\N
1100	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:34:28.171574+07	\N
1101	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:35:08.171804+07	\N
1102	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:36:28.175077+07	\N
1103	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:36:28.177973+07	\N
1104	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:37:28.179752+07	\N
1105	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:37:48.178584+07	\N
1106	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:38:28.182182+07	\N
1107	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:39:08.184677+07	\N
1108	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:40:28.184882+07	\N
1109	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:40:28.188106+07	\N
1110	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:41:48.188847+07	\N
1111	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:42:08.190108+07	\N
1124	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:51:08.222417+07	\N
1560	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:16:28.972593+07	\N
1563	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:19:08.978566+07	\N
1564	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:19:48.981428+07	\N
1571	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:24:28.990456+07	\N
1580	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:32:29.009907+07	\N
1581	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:32:29.012523+07	\N
1582	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:33:49.014117+07	\N
1584	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:35:09.016672+07	\N
1591	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:39:49.028635+07	\N
1593	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:40:49.030827+07	\N
1594	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:41:49.032181+07	\N
1999	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:33:49.722191+07	\N
2002	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:35:49.727944+07	\N
2004	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:37:49.730891+07	\N
2005	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:38:49.734506+07	\N
2009	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:41:29.740716+07	\N
2013	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:44:29.746396+07	\N
2016	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:47:09.752006+07	\N
2019	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:49:09.758166+07	\N
2023	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:52:29.763696+07	\N
2024	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:53:09.766504+07	\N
2027	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:55:09.769676+07	\N
2028	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:56:29.773411+07	\N
2357	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:13:50.399358+07	\N
2360	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:16:30.401944+07	\N
2361	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:16:50.403813+07	\N
2364	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:19:10.408455+07	\N
2374	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:25:50.423767+07	\N
2375	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:26:30.426322+07	\N
2376	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:27:10.427267+07	\N
2383	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:32:30.438841+07	\N
2385	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:33:50.443838+07	\N
2386	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:34:50.445643+07	\N
2391	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:38:30.455578+07	\N
2635	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:41:50.881599+07	\N
2774	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:21:51.114727+07	\N
1112	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:43:08.19138+07	\N
1113	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:43:28.194461+07	\N
1114	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:44:28.194264+07	\N
1115	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:45:08.197519+07	\N
1116	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:45:48.197993+07	\N
1118	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:47:08.200799+07	\N
1119	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:48:08.205217+07	\N
1127	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:53:48.220307+07	\N
1128	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:55:08.220911+07	\N
1130	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:56:28.224579+07	\N
1138	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:01:48.237489+07	\N
1143	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:05:48.247675+07	\N
1565	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:20:28.982038+07	\N
1567	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:21:48.985001+07	\N
1577	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:28:49.001489+07	\N
1583	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:33:49.018952+07	\N
1586	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:36:29.020432+07	\N
1587	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:37:49.022532+07	\N
1603	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:47:09.042979+07	\N
2003	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:36:29.728397+07	\N
2020	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:49:49.758249+07	\N
2031	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:58:29.78037+07	\N
2032	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:59:09.780151+07	\N
2034	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:00:49.785842+07	\N
2359	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:15:10.401698+07	\N
2363	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:18:30.407464+07	\N
2365	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:19:30.410018+07	\N
2367	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:20:50.412457+07	\N
2640	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:44:50.889045+07	\N
2642	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:45:50.892599+07	\N
2643	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:47:10.892713+07	\N
2646	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:48:50.898275+07	\N
2654	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:55:10.910197+07	\N
2656	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:56:30.913806+07	\N
2732	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:51:31.044464+07	\N
2739	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:57:11.057057+07	\N
2741	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:58:11.059582+07	\N
2743	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:59:31.063831+07	\N
1117	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:46:48.202701+07	\N
1120	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:48:28.204128+07	\N
1121	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:49:28.207653+07	\N
1122	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:49:48.207553+07	\N
1123	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:51:08.213347+07	\N
1125	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:52:28.213647+07	\N
1126	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:53:48.217041+07	\N
1129	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:55:08.224141+07	\N
1131	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:57:28.227326+07	\N
1132	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:57:48.227042+07	\N
1133	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 10:58:48.230698+07	\N
1134	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 10:59:08.229756+07	\N
1135	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:00:08.233922+07	\N
1136	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:00:28.233438+07	\N
1137	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:01:28.237815+07	\N
1139	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:02:28.2406+07	\N
1140	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:03:08.241539+07	\N
1141	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:04:28.24476+07	\N
1142	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:04:28.2481+07	\N
1144	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:06:08.249018+07	\N
1145	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:07:08.250771+07	\N
1146	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:08:08.25473+07	\N
1147	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:08:28.254127+07	\N
1148	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:09:28.257615+07	\N
1149	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:09:48.257018+07	\N
1150	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:11:08.260402+07	\N
1151	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:11:48.263401+07	\N
1152	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:12:28.26302+07	\N
1153	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:13:08.265962+07	\N
1154	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:13:48.266061+07	\N
1155	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:15:08.269311+07	\N
1156	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:15:08.272461+07	\N
1157	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:16:08.27302+07	\N
1158	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:16:28.272725+07	\N
1159	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:17:28.27599+07	\N
1160	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:17:48.275525+07	\N
1161	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:19:08.278391+07	\N
1162	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:19:08.281223+07	\N
1163	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:20:28.281574+07	\N
1575	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:27:08.996094+07	\N
1576	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:28:28.998609+07	\N
1578	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:29:49.001913+07	\N
1585	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:35:29.01881+07	\N
1590	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:39:09.02603+07	\N
1595	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:42:09.032931+07	\N
1598	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:44:09.037423+07	\N
1599	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:44:29.037278+07	\N
1600	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:45:09.04056+07	\N
1601	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:45:49.039938+07	\N
1602	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:46:09.043222+07	\N
1606	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:48:29.050142+07	\N
1607	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:49:49.050635+07	\N
2017	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:48:09.755572+07	\N
2371	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:23:30.419223+07	\N
2373	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:25:10.42478+07	\N
2641	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:45:50.889556+07	\N
2655	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:55:30.912335+07	\N
2660	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:59:30.922687+07	\N
2666	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:03:50.934063+07	\N
2745	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:00:31.067825+07	\N
2748	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:03:11.072003+07	\N
2775	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:22:51.121712+07	\N
2778	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:24:31.120517+07	\N
2787	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:32:31.140354+07	\N
2788	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:32:31.14361+07	\N
2791	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:35:11.145741+07	\N
2794	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:37:51.15337+07	\N
2795	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:37:51.156477+07	\N
2797	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:39:11.156292+07	\N
2804	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:43:31.168352+07	\N
2807	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:45:51.172174+07	\N
2809	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:47:11.174849+07	\N
2811	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:48:31.183025+07	\N
2812	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:49:51.18362+07	\N
2813	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:49:51.186479+07	\N
2814	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:51:11.18632+07	\N
1164	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:20:28.285019+07	\N
1165	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:21:48.284788+07	\N
1166	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:21:48.288973+07	\N
1169	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:24:48.292698+07	\N
1175	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:30:28.308039+07	\N
1180	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:33:48.319836+07	\N
1182	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:35:08.321876+07	\N
1191	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:41:48.336018+07	\N
1588	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:37:49.025238+07	\N
1589	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:38:49.026405+07	\N
1592	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:40:29.028807+07	\N
1596	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:43:09.034193+07	\N
1597	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:43:09.037089+07	\N
1605	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:48:29.04715+07	\N
1609	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:51:09.054239+07	\N
1612	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:53:09.059994+07	\N
1615	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:55:09.0637+07	\N
1616	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:56:29.067143+07	\N
1617	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:57:49.071822+07	\N
1620	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:59:49.076666+07	\N
1621	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:00:29.077927+07	\N
2018	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:48:29.755598+07	\N
2022	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 21:51:09.763398+07	\N
2025	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:53:49.766372+07	\N
2030	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 21:57:49.778276+07	\N
2035	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:01:49.786527+07	\N
2043	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:08:29.801886+07	\N
2050	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:13:49.814187+07	\N
2378	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:28:30.428759+07	\N
2380	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:29:50.431287+07	\N
2382	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:32:10.438305+07	\N
2384	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:33:10.470038+07	\N
2388	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:36:30.450086+07	\N
2392	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:39:10.456452+07	\N
2394	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:40:30.458756+07	\N
2397	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:42:50.466331+07	\N
2400	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:44:30.468068+07	\N
2402	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:45:50.470771+07	\N
2406	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:49:50.479563+07	\N
1167	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:23:08.288794+07	\N
1168	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:24:28.291454+07	\N
1170	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:25:48.294156+07	\N
1171	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:27:08.297484+07	\N
1172	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:28:28.301195+07	\N
1173	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:29:28.305836+07	\N
1174	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:29:48.304809+07	\N
1176	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:31:08.308971+07	\N
1177	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:32:28.312619+07	\N
1178	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:32:28.316085+07	\N
1179	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:33:48.315651+07	\N
1181	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:35:08.318737+07	\N
1183	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:36:28.322875+07	\N
1184	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:36:48.324734+07	\N
1185	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:37:48.325595+07	\N
1186	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:38:48.329434+07	\N
1187	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:39:08.328754+07	\N
1188	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:39:48.332741+07	\N
1189	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:40:28.332181+07	\N
1190	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:41:08.335872+07	\N
1192	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:42:08.338498+07	\N
1193	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:43:08.339209+07	\N
1194	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:44:28.344788+07	\N
1195	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:44:48.346344+07	\N
1196	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:45:48.346746+07	\N
1197	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:46:08.348718+07	\N
1198	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:47:08.349947+07	\N
1199	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:47:28.352594+07	\N
1200	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:48:28.352851+07	\N
1201	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:48:48.35647+07	\N
1202	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:49:48.357233+07	\N
1203	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:49:48.361107+07	\N
1204	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:51:08.359727+07	\N
1205	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:51:28.361919+07	\N
1206	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:52:28.363818+07	\N
1207	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:53:48.367194+07	\N
1208	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:53:48.370538+07	\N
1209	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:55:08.369458+07	\N
1210	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:55:48.373188+07	\N
1211	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:56:28.372229+07	\N
1212	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:57:28.378769+07	\N
1213	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:57:48.375798+07	\N
1219	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:03:08.388575+07	\N
1604	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:47:29.046764+07	\N
1608	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:50:49.055305+07	\N
1613	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:53:49.060194+07	\N
1619	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:59:09.074076+07	\N
1622	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:01:29.081209+07	\N
1629	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:06:49.093823+07	\N
1634	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:09:49.102318+07	\N
1635	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:11:09.103265+07	\N
2036	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:02:09.787768+07	\N
2038	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:04:29.792604+07	\N
2041	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:07:09.798857+07	\N
2044	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:09:29.80499+07	\N
2045	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:09:49.804872+07	\N
2049	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:12:49.812941+07	\N
2051	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:15:09.816824+07	\N
2058	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:20:29.82953+07	\N
2060	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:21:49.833472+07	\N
2064	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:24:29.842199+07	\N
2065	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:25:49.842928+07	\N
2067	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:27:09.849821+07	\N
2070	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:29:49.851716+07	\N
2387	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:35:10.445803+07	\N
2396	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:41:50.465672+07	\N
2399	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:43:50.468583+07	\N
2409	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:52:10.486244+07	\N
2411	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:53:50.488335+07	\N
2424	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:03:10.509707+07	\N
2644	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:47:30.895419+07	\N
2647	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:49:50.899+07	\N
2648	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:50:10.900736+07	\N
2652	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:53:30.907379+07	\N
2658	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:58:10.919221+07	\N
2661	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:00:30.924483+07	\N
2663	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:01:50.927676+07	\N
1214	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 11:59:08.379528+07	\N
1216	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:00:28.382353+07	\N
1610	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:51:49.058183+07	\N
1611	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 16:52:29.057471+07	\N
1614	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:54:29.064274+07	\N
1623	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:01:49.080555+07	\N
1624	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:02:49.084089+07	\N
1625	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:03:09.083786+07	\N
1626	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:04:29.088174+07	\N
1627	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:04:49.089602+07	\N
1640	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:14:49.11287+07	\N
1641	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:15:09.112612+07	\N
2037	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:03:09.789414+07	\N
2039	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:05:49.796224+07	\N
2047	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:11:09.808321+07	\N
2052	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:15:29.819148+07	\N
2053	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:16:29.820069+07	\N
2054	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:16:49.821379+07	\N
2056	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:18:29.827163+07	\N
2061	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:22:29.836104+07	\N
2063	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:24:29.83919+07	\N
2069	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:28:29.853053+07	\N
2071	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:30:49.855037+07	\N
2389	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:36:30.453844+07	\N
2390	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:37:50.453362+07	\N
2393	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:40:10.460125+07	\N
2395	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:41:50.461928+07	\N
2398	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:43:10.464942+07	\N
2401	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:44:50.470408+07	\N
2404	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:47:10.474504+07	\N
2405	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:48:30.476839+07	\N
2407	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:50:10.482605+07	\N
2413	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:55:10.493066+07	\N
2415	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:56:30.493747+07	\N
2421	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:00:50.504395+07	\N
2422	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:01:50.506409+07	\N
2425	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:03:50.513016+07	\N
2645	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:48:30.895935+07	\N
1215	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 11:59:08.382531+07	\N
1217	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:01:08.385822+07	\N
1218	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 12:01:48.38552+07	\N
1220	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 12:03:08.393293+07	\N
1618	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 16:58:29.074281+07	\N
1630	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:07:09.093827+07	\N
1636	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 17:11:49.106179+07	\N
1639	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 17:13:49.109496+07	\N
2040	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:06:29.799409+07	\N
2042	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:07:49.803816+07	\N
2046	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:10:49.807937+07	\N
2048	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:12:29.811135+07	\N
2059	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:21:09.833389+07	\N
2068	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:28:29.849829+07	\N
2072	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-24 22:31:09.854656+07	\N
2073	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-24 22:32:09.859894+07	\N
2403	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:46:30.474901+07	\N
2408	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:51:10.482834+07	\N
2410	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:52:30.485063+07	\N
2414	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:55:50.493847+07	\N
2416	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:57:30.496452+07	\N
2418	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 02:58:50.500368+07	\N
2419	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 02:59:10.500009+07	\N
2420	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 03:00:30.502735+07	\N
2423	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 03:02:30.507911+07	\N
2649	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:51:10.901943+07	\N
2650	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 05:52:10.905704+07	\N
2653	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:53:50.907701+07	\N
2657	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:57:50.91732+07	\N
2659	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 05:59:10.920609+07	\N
2662	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:00:30.928965+07	\N
2665	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:03:10.930729+07	\N
2668	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:05:50.937132+07	\N
2671	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:08:30.942308+07	\N
2676	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:11:10.949058+07	\N
2677	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:11:50.951968+07	\N
2681	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 06:14:30.958965+07	\N
2683	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 06:16:30.961276+07	\N
2815	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:51:11.190391+07	\N
2820	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:55:11.197697+07	\N
2821	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:56:31.197655+07	\N
2823	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:57:51.20057+07	\N
2825	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:59:11.203367+07	\N
2833	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:05:51.221534+07	\N
2835	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:07:11.223511+07	\N
2816	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:52:31.18791+07	\N
2822	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:56:31.201412+07	\N
2824	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:58:31.202786+07	\N
2827	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:00:31.20971+07	\N
2830	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:03:11.212681+07	\N
2817	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 07:53:31.191504+07	\N
2818	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:53:51.190953+07	\N
2826	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:00:31.206843+07	\N
2829	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:02:51.213785+07	\N
2831	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:03:51.21588+07	\N
2837	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:08:31.232356+07	\N
2839	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:10:11.232757+07	\N
2841	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:12:31.241544+07	\N
2819	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 07:55:11.194716+07	\N
2828	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:01:51.209972+07	\N
2832	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:04:31.216895+07	\N
2834	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:06:31.224698+07	\N
2836	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:08:31.228233+07	\N
2838	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:09:51.230514+07	\N
2840	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:11:11.234133+07	\N
2842	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:12:31.244278+07	\N
2843	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:13:51.240148+07	\N
2844	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:14:51.243507+07	\N
2845	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:15:11.243305+07	\N
2846	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:16:31.246551+07	\N
2847	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:17:31.249694+07	\N
2848	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:17:51.24895+07	\N
2849	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:19:11.25363+07	\N
2850	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:19:11.256529+07	\N
2851	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:20:31.256031+07	\N
2852	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:20:31.25873+07	\N
2853	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:21:31.259194+07	\N
2854	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:21:51.258612+07	\N
2855	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:23:11.260909+07	\N
2856	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:23:11.263737+07	\N
2857	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:24:31.263908+07	\N
2858	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:25:51.268781+07	\N
2859	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:26:51.272455+07	\N
2860	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:27:11.271648+07	\N
2861	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:27:51.277985+07	\N
2862	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:28:31.27752+07	\N
2863	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:29:11.282739+07	\N
2864	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:29:51.280808+07	\N
2865	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:30:11.283409+07	\N
2866	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:31:11.284576+07	\N
2867	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:32:31.288815+07	\N
2868	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:32:31.291596+07	\N
2869	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:33:31.292255+07	\N
2870	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:33:51.291737+07	\N
2871	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:35:11.29661+07	\N
2872	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:35:11.299647+07	\N
2873	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:36:31.297991+07	\N
2874	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:36:31.301703+07	\N
2881	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:42:11.311312+07	\N
2875	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:37:51.300738+07	\N
2876	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:38:31.304678+07	\N
2877	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:39:11.303623+07	\N
2878	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:40:31.307171+07	\N
2879	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:40:51.309121+07	\N
2880	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:41:51.310534+07	\N
2882	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:43:11.312999+07	\N
2883	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:44:31.316038+07	\N
2884	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:44:31.320061+07	\N
2885	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:45:51.319087+07	\N
2886	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:45:51.321783+07	\N
2887	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:47:11.323078+07	\N
2890	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:49:11.329747+07	\N
2892	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:50:51.33186+07	\N
2894	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:51:51.334432+07	\N
2895	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:52:31.333748+07	\N
2899	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:55:11.340747+07	\N
2900	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:56:31.34379+07	\N
2902	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:57:51.34699+07	\N
2903	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:58:51.352587+07	\N
2904	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:59:11.352716+07	\N
2906	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:00:31.359174+07	\N
2908	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:01:51.358678+07	\N
2909	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:02:31.361974+07	\N
2911	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:04:31.365383+07	\N
2914	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:06:31.372805+07	\N
2918	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:08:31.380193+07	\N
2924	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:12:51.388435+07	\N
2888	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:47:11.326271+07	\N
2889	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:48:31.32534+07	\N
2891	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:49:51.329304+07	\N
2893	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:51:11.332445+07	\N
2896	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:53:11.33813+07	\N
2897	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 08:53:51.337419+07	\N
2898	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:54:31.341128+07	\N
2901	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 08:57:31.347304+07	\N
2905	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:00:31.356142+07	\N
2907	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:01:31.359893+07	\N
2910	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:03:11.362554+07	\N
2912	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:04:31.3681+07	\N
2913	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:05:51.368761+07	\N
2915	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:07:11.372754+07	\N
2916	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:07:31.374807+07	\N
2917	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:08:31.37568+07	\N
2919	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:09:31.38114+07	\N
2920	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:09:51.380808+07	\N
2921	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:10:31.384327+07	\N
2922	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:11:11.384152+07	\N
2923	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:12:31.387449+07	\N
2925	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:13:51.389827+07	\N
2926	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:15:11.394619+07	\N
2927	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:15:11.397003+07	\N
2928	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:16:31.397468+07	\N
2929	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:17:31.402177+07	\N
2930	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:17:51.400952+07	\N
2931	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:18:31.403081+07	\N
2932	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:19:11.404326+07	\N
2933	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:20:31.407143+07	\N
2934	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:20:31.410098+07	\N
2935	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:21:51.411177+07	\N
2936	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:21:51.416071+07	\N
2937	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:23:11.413781+07	\N
2938	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:23:11.417171+07	\N
2939	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:24:31.417699+07	\N
2940	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:24:31.420413+07	\N
2941	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:25:51.42019+07	\N
2943	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:27:11.42445+07	\N
2942	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:26:11.423115+07	\N
2946	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:29:51.430814+07	\N
2951	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:32:51.437881+07	\N
2952	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:33:51.439096+07	\N
2954	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:35:11.442433+07	\N
2956	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:36:51.447314+07	\N
2958	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:38:11.454604+07	\N
2944	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:28:11.427541+07	\N
2947	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:29:51.434192+07	\N
2949	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:31:11.436243+07	\N
2950	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:32:31.436131+07	\N
2957	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:37:51.449663+07	\N
2961	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:40:31.460652+07	\N
2962	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:41:51.45899+07	\N
2945	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:28:31.428118+07	\N
2955	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:36:31.445762+07	\N
2960	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:40:31.456907+07	\N
2964	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:43:11.465449+07	\N
2948	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:31:11.433187+07	\N
2953	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:34:11.440707+07	\N
2959	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:39:11.453095+07	\N
2963	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:43:11.462453+07	\N
2965	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:44:31.463855+07	\N
2966	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:45:51.467811+07	\N
2967	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:46:31.472841+07	\N
2968	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:47:11.470154+07	\N
2969	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:48:31.473214+07	\N
2970	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:48:31.476344+07	\N
2971	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:49:51.47723+07	\N
2972	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:50:31.47978+07	\N
2973	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:51:11.479969+07	\N
2974	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:52:31.483395+07	\N
2975	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:52:31.486744+07	\N
2976	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:53:51.486232+07	\N
2977	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:54:11.488014+07	\N
2978	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:55:11.489175+07	\N
2979	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:56:31.493539+07	\N
2980	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:57:51.496674+07	\N
2981	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 09:58:11.498797+07	\N
2982	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 09:59:11.499559+07	\N
2983	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:00:11.503655+07	\N
2984	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:00:31.502918+07	\N
2985	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:01:51.505934+07	\N
2986	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:01:51.509259+07	\N
2987	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:02:51.510076+07	\N
2988	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:03:11.50847+07	\N
2989	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:04:31.511637+07	\N
2990	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:05:31.515034+07	\N
2991	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:05:51.514685+07	\N
2992	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:06:31.517461+07	\N
2993	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:07:11.517409+07	\N
2994	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:07:31.519396+07	\N
2995	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:08:31.520687+07	\N
2996	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:08:31.52369+07	\N
2997	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:09:51.523974+07	\N
2998	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:10:11.524828+07	\N
2999	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:11:11.52677+07	\N
3000	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:11:31.528612+07	\N
3001	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:12:31.529762+07	\N
3002	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:12:51.531711+07	\N
3012	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:21:51.551194+07	\N
3031	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:35:11.584124+07	\N
3003	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:13:51.532808+07	\N
3004	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:14:31.539184+07	\N
3005	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:15:11.53532+07	\N
3006	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:16:31.538502+07	\N
3007	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:17:31.542605+07	\N
3008	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:17:51.54171+07	\N
3009	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:19:11.545193+07	\N
3010	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:19:11.549416+07	\N
3011	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:20:31.54823+07	\N
3013	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:22:51.554406+07	\N
3014	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:23:11.554675+07	\N
3015	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:24:31.556592+07	\N
3016	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:25:11.559645+07	\N
3017	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:25:51.559918+07	\N
3018	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:26:11.561175+07	\N
3019	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:27:11.562309+07	\N
3020	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:28:31.566058+07	\N
3021	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:28:51.568365+07	\N
3022	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:29:51.569031+07	\N
3023	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:30:11.570318+07	\N
3024	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:31:11.572458+07	\N
3025	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:31:11.575371+07	\N
3026	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:32:11.576325+07	\N
3027	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:32:31.574788+07	\N
3028	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:33:31.578609+07	\N
3029	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:33:51.578115+07	\N
3030	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:35:11.581039+07	\N
3032	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:36:31.583626+07	\N
3033	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:36:51.58676+07	\N
3034	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:37:51.586673+07	\N
3035	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:38:11.588976+07	\N
3036	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:39:11.594749+07	\N
3037	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:39:11.59784+07	\N
3038	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	7243d86e-17a7-48d5-983a-b46987f0d06b	door_open	Cửa vừa mở	Cảm biến cửa ra vào vừa mở · chế độ "Ra ngoài"	2026-11-25 10:40:31.592957+07	\N
3039	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	48d3996a-4bb4-4134-aa64-2b7abed308a9	129da822-b042-4ba8-8d6c-8088cf9aa672	presence	Phát hiện có người	Cảm biến hiện diện vừa phát hiện chuyển động · chế độ "Ra ngoài"	2026-11-25 10:41:31.597727+07	\N
\.


--
-- Data for Name: oauth_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_codes (code_hash, client_id, user_id, redirect_uri, scope, expires_at, used_at, grant_id) FROM stdin;
\.


--
-- Data for Name: oauth_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_grants (id, client_id, user_id, scope, refresh_hash, created_at, last_used_at, revoked_at) FROM stdin;
cbe7d3a3-6be2-4ac3-b1db-fc2abeef9fb6	msmart-google-home	1d25ddd9-f406-4cd1-a56b-9838d330d1f6		bc878183bd7481ea26849cb7b6573e63a578dc552326457e9a6a5aaab93a0ec7	2026-11-19 17:10:46.98774+07	2026-11-19 17:10:46.98774+07	\N
8afb47b1-eb49-4807-8279-fa7656a391d5	msmart-google-home	1d25ddd9-f406-4cd1-a56b-9838d330d1f6		2e98445740f98ba29af8015ab47ac936fc8a530ae9c98e0049af1b07fa714185	2026-11-19 17:16:14.159327+07	2026-11-19 17:16:14.159327+07	\N
11a63a38-bd12-4820-bbdb-77e0a9c8cd9c	msmart-google-home	1d25ddd9-f406-4cd1-a56b-9838d330d1f6		20022a668a7fbef5b4d546b8f5558a211a276b21aa34e3bfabad6603ad1a9835	2026-11-19 17:19:16.887744+07	2026-11-24 17:23:03.124399+07	\N
\.


--
-- Data for Name: oauth_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_tokens (token_hash, grant_id, expires_at) FROM stdin;
\.


--
-- Data for Name: pending_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pending_actions (rule_id, home_id, device_id, key, state, due_at) FROM stdin;
\.


--
-- Data for Name: push_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_tokens (id, user_id, platform, token, created_at, last_seen_at) FROM stdin;
53f8067b-3d84-418f-b20b-b31e36f3cfef	1398ff97-2866-4c04-b061-7e7abf3d38e0	ios	eFmMDXWvF0Z1l2UBKSRzS1:APA91bF8TmcaDNP-d2sqbMB-oc2pBKgGz8nsIz-mZ0klrMRGQCVbitk9vOEOK0sv5jWQC7sgue2ugajI5DC5Ccd47FhRLNhKxmOmzNfC4Kw9kxYpmjms9R0	2026-11-21 09:16:42.071156+07	2026-11-21 09:16:42.071156+07
119c0b2c-ccf9-4019-9770-03503285a564	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	android	eDOe4nWEROqu1Gs1_nQMYN:APA91bEE4fLwQFDnHR8jyWlq_7r9I3akye8eatURlJWQOZkF9q4L4qYwi6hs2p6Gy13u5FWKP7-0sWbYrDGckEUzEmov_52TovpQWnCnfk0gBjZ1OTSO__c	2026-11-23 21:28:57.205539+07	2026-11-25 08:56:43.868066+07
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, family_id, family_started_at, token_hash, expires_at, used_at, revoked_at, created_at) FROM stdin;
8b782111-a12e-4a2e-a7d8-1825d824fdb0	d90f5d76-5db4-4421-8e83-b2ff84049f92	bc90d591-e048-4a59-8fab-938d8976f6a5	2026-11-13 15:02:22.238751+07	60f75eef20e35fccc0bd74d041ccef29b8430a61e9e5e5d357f20809fc3a006e	2026-12-13 15:02:22.238751+07	\N	\N	2026-11-13 15:02:22.238751+07
2c728535-82fe-4a60-b39e-ca90f4fb7b82	d90f5d76-5db4-4421-8e83-b2ff84049f92	4e4fc67c-cdff-408a-b920-1b5b87bd55f3	2026-11-13 15:02:43.196463+07	62edb90f625aa6079ebd0fca763ff08f489b33f8a854f9e284a703591b19fe32	2026-12-13 15:02:43.196463+07	\N	\N	2026-11-13 15:02:43.196463+07
f37a457f-2dcf-4ccb-9bb9-6052491631fb	d90f5d76-5db4-4421-8e83-b2ff84049f92	3551528c-83bc-4c51-ae64-0b2ff42a85e6	2026-11-13 15:04:28.184004+07	c0df2005d31e51603343e045aee6099649f8eb0c05ed36d1abbf49a34df1a0dd	2026-12-13 15:04:28.184004+07	\N	\N	2026-11-13 15:04:28.184004+07
63a19457-4bb1-4150-a168-88dc79a59772	d90f5d76-5db4-4421-8e83-b2ff84049f92	f44ff1b3-d978-4ed5-9e1b-e86f4d3def2b	2026-11-13 15:05:53.17337+07	e12b906c63e737fee3fa5875fb5a72d8bb776eb55750236c8f8e5a54652f3e72	2026-12-13 15:05:53.17337+07	\N	\N	2026-11-13 15:05:53.17337+07
ecba173a-fc02-45b9-992d-a892d61db21e	d90f5d76-5db4-4421-8e83-b2ff84049f92	bc8b49f3-4ba9-47cd-a7f9-9867697af4b0	2026-11-13 13:41:54.189473+07	ddd996916df43d435747440397dba7ee2d2b36be38b3c422dc74ce80475341df	2026-12-13 13:41:54.189473+07	\N	2026-11-13 13:42:11.501872+07	2026-11-13 13:41:54.189473+07
57da4f42-0fde-4b5d-a3d2-3ab183f9b432	d90f5d76-5db4-4421-8e83-b2ff84049f92	ecddc3cc-7caa-4f10-8779-9a514fdc6727	2026-11-13 13:39:22.305901+07	0bde17177de066bb0d29f9a2d3ecb66b90bf42e93c7b6434bcce8fc905634e80	2026-12-13 13:39:22.305901+07	\N	2026-11-13 13:42:21.600865+07	2026-11-13 13:39:22.305901+07
771605d9-5265-4bb0-947c-c468d3a45ddc	d90f5d76-5db4-4421-8e83-b2ff84049f92	c2e2c4f2-b273-4214-85a5-6b5d7cc224b6	2026-11-13 13:39:39.13658+07	9a1ec7f1c6a35a86caa0172b3bf35c5acdd60529f167f4eaf7c37e6227281c6d	2026-12-13 13:39:39.13658+07	\N	2026-11-13 13:42:21.600865+07	2026-11-13 13:39:39.13658+07
867eef56-cc41-49e7-99b2-a38efcd16960	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9c4070c7-347b-439d-b777-3a8e18999c9f	2026-11-13 13:44:57.064117+07	29b80881890750913534409c4b63e3d40ca77357f273b229c29d4f2312328b97	2026-12-13 13:44:57.064117+07	\N	2026-11-13 13:45:02.053021+07	2026-11-13 13:44:57.064117+07
ff281611-f37e-4ee2-b8df-473c9b5e9a33	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4a82ab3e-adff-4f31-bffc-11a4f4a1b14a	2026-11-13 13:45:42.510876+07	b64882adf45bd9f71f929cbb76ff664cae4d37390bad0d01893d2cf9ed8d3051	2026-12-13 13:45:42.510876+07	\N	2026-11-13 13:47:06.26301+07	2026-11-13 13:45:42.510876+07
0fea4514-35a4-4364-947c-8a8f6fb96c55	d90f5d76-5db4-4421-8e83-b2ff84049f92	aecccca8-e95e-4090-b03d-e4dd4b7b81c3	2026-11-13 14:02:36.105072+07	e312b786a454a4b9b8eb95fce9737b8bfa98ac7aaed701cd19f83ffc555edac2	2026-12-13 14:02:36.105072+07	\N	\N	2026-11-13 14:02:36.105072+07
25ef61e1-d53b-4bb4-bca2-479d52f2c144	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	c7322333-ff59-40a9-8413-2ccda1aad625	2026-11-13 14:02:36.123142+07	8bcba5ec822274ff532db5a4a93c8a3a88429746c703ba6d98848d4129d92f20	2026-12-13 14:02:36.123142+07	\N	\N	2026-11-13 14:02:36.123142+07
6be808b0-fd60-4518-a5c0-97e5b8b48eeb	d90f5d76-5db4-4421-8e83-b2ff84049f92	e5fe6464-c76d-484e-92cd-65b32a56d95f	2026-11-13 14:05:40.250703+07	1d4104030577f0f8e9aa392d4e5ba28cba463eed62587716fccea3fdcdd35234	2026-12-13 14:05:40.250703+07	\N	\N	2026-11-13 14:05:40.250703+07
edc24821-ff00-448a-8346-0131a4d79d05	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	bb1dd350-75d5-4930-aa82-bd7725440f5d	2026-11-13 14:05:40.270015+07	a1baf74965ad501380b3309c4c65d5624fe1f2d54a0dc16314dbd4d2db652414	2026-12-13 14:05:40.270015+07	\N	\N	2026-11-13 14:05:40.270015+07
828f7896-879c-4a46-ab6c-659ab59c60d9	d90f5d76-5db4-4421-8e83-b2ff84049f92	bc680545-3a16-4d69-9a49-0579dcdbcd9c	2026-11-13 14:05:40.355054+07	e37576aea8fc5099cc5faad2555253fae9135f754e4b5293c23c1f4857ad9d38	2026-12-13 14:05:40.355054+07	\N	\N	2026-11-13 14:05:40.355054+07
0b37a747-d049-4cd1-bf94-ae3180da849f	d90f5d76-5db4-4421-8e83-b2ff84049f92	4bfabec8-6e50-4018-8358-8137bfadddc5	2026-11-13 15:06:43.395494+07	5b9221b756a800f4c1fe6525ce7de05811b2c4243ca489bbff3ee1331afe51c1	2026-12-13 15:06:43.395494+07	\N	\N	2026-11-13 15:06:43.395494+07
930776e7-0474-4c9d-ad3b-0826ac766fa7	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	a7b06246-d515-4996-9be2-fc138205ad70	2026-11-13 13:47:28.833935+07	52ba25034479cf3a16ca58ca6f8deb3d1d369b0657aa4c18d513d818e4ce1910	2026-12-13 13:47:28.833935+07	2026-11-13 14:06:51.219713+07	2026-11-13 14:07:07.088486+07	2026-11-13 13:47:28.833935+07
e2a78c66-f86a-4ae5-9f9d-541e4babcba3	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	a7b06246-d515-4996-9be2-fc138205ad70	2026-11-13 13:47:28.833935+07	4723b42e9a7e23fa6e4ef994a3ef90c562c20cef3d4e96871ce4acb1c3db253e	2026-12-13 14:06:51.219713+07	\N	2026-11-13 14:07:07.088486+07	2026-11-13 14:06:51.219713+07
921e6d50-54f9-415e-90d0-aa007a3e1dcc	d90f5d76-5db4-4421-8e83-b2ff84049f92	61878b93-35b6-453b-9b8c-8f048387151c	2026-11-13 14:07:20.179355+07	673d97d0446c9a2e2cad3aa805a67272f6479e5c9b3aca4e79dce309376c7d15	2026-12-13 14:07:20.179355+07	\N	2026-11-13 14:15:12.468921+07	2026-11-13 14:07:20.179355+07
1c6df4bd-0803-4252-a6ca-c60b6a5994eb	d90f5d76-5db4-4421-8e83-b2ff84049f92	3e235b0f-900a-4d13-bf5f-ffdbd5000bd3	2026-11-13 14:27:28.694368+07	262fb3ebbe6b639395337abf15859e68a0f454de41ca7534820873b3c071ed37	2026-12-13 14:27:28.694368+07	\N	\N	2026-11-13 14:27:28.694368+07
6bcc2f1e-38cb-49d2-96bd-b4ba62a9396d	d90f5d76-5db4-4421-8e83-b2ff84049f92	32871775-ff8c-4e05-b023-97c1f427fb1f	2026-11-13 14:27:37.877971+07	54766a91ecfe6c48bc6a4b55ccaec63677505b81a30d533bbcf09b9512716e54	2026-12-13 14:27:37.877971+07	\N	\N	2026-11-13 14:27:37.877971+07
2451b159-ad5d-4db8-993a-46d4d43c5533	d90f5d76-5db4-4421-8e83-b2ff84049f92	8b161c64-f51b-4f9d-a00f-417a1c64c3fe	2026-11-13 14:27:44.704877+07	a66e179747b7f89d8fdcce154733aa4acae567797727649d44feb5bb66f03534	2026-12-13 14:27:44.704877+07	\N	\N	2026-11-13 14:27:44.704877+07
3b507e6c-499a-4b22-81f6-4d2f965fc257	d90f5d76-5db4-4421-8e83-b2ff84049f92	3ada4875-ff4a-4221-a1f2-e831b837caac	2026-11-13 15:07:01.969231+07	5e58cbeb35bb5091702d9c6f11add0326c5eb0275739449d2902c131a5097128	2026-12-13 15:07:01.969231+07	\N	\N	2026-11-13 15:07:01.969231+07
92c5e611-6fb5-41ea-a66b-4d3538ce92fa	d90f5d76-5db4-4421-8e83-b2ff84049f92	9ef31882-752b-456a-97dc-9152fcfd8cd3	2026-11-13 15:08:18.366336+07	5b01f3293679579bba2ae7d66c74683c4f68f85d6eecbf188aa7c58654800962	2026-12-13 15:08:18.366336+07	\N	\N	2026-11-13 15:08:18.366336+07
e9fe18f4-d7fa-4eb4-8124-e1aa77777943	d90f5d76-5db4-4421-8e83-b2ff84049f92	69503f1c-2a04-4f6d-9909-73dc77a32823	2026-11-13 16:16:18.265035+07	90166a3effc14c5cd0735265b11be75c3134cbf4084cb7f88ed1ddf8071e13ef	2026-12-13 16:16:18.265035+07	\N	\N	2026-11-13 16:16:18.265035+07
dd2205f2-dbc9-491e-89bd-40a2d99eb038	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	7ed0c3d0-0ce3-4100-ae11-4abe1e773897	2026-11-13 16:16:18.285823+07	cc590c6e6f72c20e4984478f8c83ee06ccdb3e7d5587d35050e818be561e6e1a	2026-12-13 16:16:18.285823+07	\N	\N	2026-11-13 16:16:18.285823+07
970cf607-0ae4-4a3d-a648-fa7d2242d707	d90f5d76-5db4-4421-8e83-b2ff84049f92	30f543a3-cbd1-4876-8cc5-52f3074f5e43	2026-11-13 16:16:47.393167+07	b54e68f1c4607354a45dbdeacbb58ec5ec31bba7ddff659e67de6ce33894d42a	2026-12-13 16:16:47.393167+07	\N	\N	2026-11-13 16:16:47.393167+07
e47d4cb3-f5cc-48c0-b225-f0bf5f45cad8	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	bd2d063f-b9e4-4e20-bea0-6b05146f04f9	2026-11-13 16:16:47.414023+07	235e4ee65676488b15e8b0871ffad13f5d9f7cc0fc739dc367d9b52d30165c01	2026-12-13 16:16:47.414023+07	\N	\N	2026-11-13 16:16:47.414023+07
3ddbdbb0-f267-4dbb-8020-b3ebed256356	d90f5d76-5db4-4421-8e83-b2ff84049f92	526d8d05-ab9a-43e0-8de4-9f22f97aa84f	2026-11-13 16:16:58.460504+07	6eb15a6058855b5689b8ac23a8d0e4adbf648a3df3563e37e04e893bac348ba4	2026-12-13 16:16:58.460504+07	\N	\N	2026-11-13 16:16:58.460504+07
0d609ed8-45f2-4766-88c7-7f7020f59287	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	7b596c31-4009-4343-8b0a-3ccda48f9803	2026-11-13 16:16:58.479483+07	04ef17c2f21f9984c38320e2e11d827e219194c4dc50d2e0a59d6f7a317891b2	2026-12-13 16:16:58.479483+07	\N	\N	2026-11-13 16:16:58.479483+07
94f0c357-8565-4380-ba13-267aaa3f94df	d90f5d76-5db4-4421-8e83-b2ff84049f92	73e2f86a-cbf0-40e3-bc53-5ccd6c151e80	2026-11-13 16:17:14.030935+07	1d76009c6a604565302143dae950cbc55afa4dac4ed8de3a7cd16fd372c97c01	2026-12-13 16:17:14.030935+07	\N	\N	2026-11-13 16:17:14.030935+07
a1594835-c0fa-4f57-a62a-b6f4df4a2198	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	7c1128af69b6c393b6a3ecbf15d81586bcdd4bfeecd8b59ef58e423449090dd4	2026-12-13 14:45:31.99085+07	2026-11-13 15:00:35.047059+07	2026-11-13 16:30:11.482995+07	2026-11-13 14:45:31.99085+07
9f5f1cd8-57b5-47fb-8032-c0c2b59564b4	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	60cdbbfb2c95e2c195e80cd73abeef1af4ce3cd488fdf8f03845c391c784dcb3	2026-12-13 14:15:25.484888+07	2026-11-13 14:30:28.911151+07	2026-11-13 16:30:11.482995+07	2026-11-13 14:15:25.484888+07
a07a2a44-d228-4dfb-96fb-ac077cabeb02	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	4aead883e7ee1cb258dff3bed65457f6af979c32768b23b3bc89b3457083a332	2026-12-13 14:30:28.911151+07	2026-11-13 14:45:31.99085+07	2026-11-13 16:30:11.482995+07	2026-11-13 14:30:28.911151+07
bc6b47c1-2c2b-4e12-b713-7cc8db5e0de7	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	315686c55aa16b99e872f056e9c9c8d33032f849297b5f987d50740610b49f0e	2026-12-13 15:00:35.047059+07	2026-11-13 15:15:38.499681+07	2026-11-13 16:30:11.482995+07	2026-11-13 15:00:35.047059+07
0461265f-7509-4a30-a04c-bf55528c6351	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	aa1594f3-ecc2-4699-a7e9-e6c009118ddd	2026-11-13 16:17:14.053934+07	c15c7710711d02bfd00214c8a37a1279fff49743c802a99b2258f854039a486a	2026-12-13 16:17:14.053934+07	\N	\N	2026-11-13 16:17:14.053934+07
c555cfe7-dcc7-45a5-b24c-ea4facc7c1fd	d90f5d76-5db4-4421-8e83-b2ff84049f92	531ac313-0a86-4d5d-be3f-c891470d17a2	2026-11-13 16:18:34.405838+07	f036faba877d15e400cdf94529611fe4451117629c4c0f4e8bfce6cdb368c914	2026-12-13 16:18:34.405838+07	\N	\N	2026-11-13 16:18:34.405838+07
04ae1782-f26d-46d6-97c5-accaefa6c18c	d90f5d76-5db4-4421-8e83-b2ff84049f92	a5ac5134-625a-493a-b0f6-5fe4232b6420	2026-11-13 16:21:56.104736+07	5d299a8c32d94fbc0369cbfb7f5a0e86fc3727523ffd5d81a98d9b76d30ca7ac	2026-12-13 16:21:56.104736+07	\N	\N	2026-11-13 16:21:56.104736+07
c07d7818-0eaa-454d-8b37-7c0092d9b316	d90f5d76-5db4-4421-8e83-b2ff84049f92	3d69b3cd-0bd8-4a42-9229-475e1d3eb37b	2026-11-13 16:18:21.197683+07	7f02cb4d2ed16d53fcf1f5998bd32c3e3d0c895f1610ba7ff65224da0d6e8fed	2026-12-13 16:18:21.197683+07	\N	\N	2026-11-13 16:18:21.197683+07
97ff5e25-1700-4427-8493-48b1ceb3a85a	d90f5d76-5db4-4421-8e83-b2ff84049f92	27a5f8e8-f787-4c0f-9a50-2e2c131cf082	2026-11-13 16:21:30.570001+07	f36f7e1903df935f5a17a7cb15021471a41fedc43058cc1dfea2017f585325ca	2026-12-13 16:21:30.570001+07	\N	\N	2026-11-13 16:21:30.570001+07
7f98a343-78ae-4e81-a08a-2db5d99d3d24	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	6563cff2-9183-4419-9a61-e814ec6f7635	2026-11-13 16:18:21.329666+07	3c2c606df44e5f5acd6db3968e8a0596d6a588733e78b188dd6eb1770ded94ed	2026-12-13 16:18:21.329666+07	\N	\N	2026-11-13 16:18:21.329666+07
8fa32daa-d843-44d3-a899-2893c414100e	d90f5d76-5db4-4421-8e83-b2ff84049f92	c2d9d135-bfd4-448d-ae8d-e72d90f74156	2026-11-13 16:22:55.556358+07	336dfda38966bc22f4a8b0048e1be8ef10aacf5d14b1a4ae3665f21da39e7dce	2026-12-13 16:22:55.556358+07	\N	\N	2026-11-13 16:22:55.556358+07
6ef6f986-4fea-430e-8f51-dfd2dafc7176	d90f5d76-5db4-4421-8e83-b2ff84049f92	f1a06574-ffed-4da7-b8f5-65a69d612c21	2026-11-13 16:23:00.958347+07	197bc733d66b14ed5c6f18c4644e46b6ebe19691aab13412380afa20bfaa16ec	2026-12-13 16:23:00.958347+07	\N	\N	2026-11-13 16:23:00.958347+07
dbdb1e7b-6e0f-44b1-804a-231795bffdc7	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	ce82f5f25216ebd2a22534742fbb7453d20a7384353e63363c3ee9407c9b1f67	2026-12-13 15:15:38.499681+07	2026-11-13 15:30:41.585019+07	2026-11-13 16:30:11.482995+07	2026-11-13 15:15:38.499681+07
392bb930-f888-4956-a826-aa883c2b7d03	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	cdb56d2dda0fbc73bdd83f106c77d1ea7773142c82ad5dc29ec47147b59fc8dc	2026-12-13 15:30:41.585019+07	2026-11-13 15:45:44.668511+07	2026-11-13 16:30:11.482995+07	2026-11-13 15:30:41.585019+07
c970187c-65ea-4f0e-959e-01b3eef636f5	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	36ee7bce0b796b290e2544ffeeafb2b22b729a8d9dfb289b45e83d098c6a0ebc	2026-12-13 15:45:44.668511+07	2026-11-13 16:00:42.259015+07	2026-11-13 16:30:11.482995+07	2026-11-13 15:45:44.668511+07
1a35aeda-4bd9-4d6b-9488-4f2f12b27b7a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	7875621a5fb96663175daad53880a9bf91b262df6bfe99f1a8b5460a4f71000a	2026-12-13 16:00:42.259015+07	2026-11-13 16:25:10.515649+07	2026-11-13 16:30:11.482995+07	2026-11-13 16:00:42.259015+07
4833e466-9458-4541-b945-c727edc59bb2	6a8de966-ee0f-41d9-ac99-79cdcfa18d61	2cb489d4-906b-46a0-b73d-d73d5766d2c6	2026-11-13 16:18:34.421323+07	f634bd0e95e1c908f786c99da768ecd0818f25ef484a0715bce3297a12d840c9	2026-12-13 16:18:34.421323+07	\N	\N	2026-11-13 16:18:34.421323+07
fbd37699-325c-4d43-97a7-8164284e6ad1	d90f5d76-5db4-4421-8e83-b2ff84049f92	89b91f9d-d07b-492f-8a4d-f6c5a656aed8	2026-11-13 16:22:46.965007+07	3c861b1ddf13a392e6d573f1aee967d2cb0359300180f86c48269c352a143415	2026-12-13 16:22:46.965007+07	\N	\N	2026-11-13 16:22:46.965007+07
1058d0d3-a43e-4e49-a343-582e61566d95	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	09d88673-cff7-4e3d-99e7-1bb730504451	2026-11-13 14:15:25.484888+07	08437a3722ff7abd0f75344b47c549b6465bcb2db50bb369254bc2686bb374b1	2026-12-13 16:25:10.515649+07	\N	2026-11-13 16:30:11.482995+07	2026-11-13 16:25:10.515649+07
8bf0de60-b552-4720-be5d-75c9129d11a6	d90f5d76-5db4-4421-8e83-b2ff84049f92	05fe4b79-d63a-437d-b19c-d166a6fed1c0	2026-11-13 16:23:05.083741+07	0c9788f471a42d990a9115b8af48b81a9f98355b3daf31af1f96d5140b4f1470	2026-12-13 16:23:05.083741+07	\N	2026-11-13 16:31:59.258527+07	2026-11-13 16:23:05.083741+07
92c2c2bc-c774-4cb6-a2de-f55774e80ade	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	32009fe7-914e-4181-92d3-6fda45e03e41	2026-11-13 16:34:11.988049+07	b577a3925f8c568d152f62c7f4864376e6197a921c47a33017c59c0396067d4c	2026-12-13 16:34:11.988049+07	\N	2026-11-13 16:36:44.203571+07	2026-11-13 16:34:11.988049+07
b460b947-7df9-4f44-9e41-2b0009af40ae	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	dd329af1-ee46-42f7-9636-1ac462e82f17	2026-11-13 16:36:55.945367+07	40b362146ddc36c3f12f4f1eef31fd2a80c02225df7f5eeb9d5bd10bb1b7958b	2026-12-13 16:36:55.945367+07	\N	\N	2026-11-13 16:36:55.945367+07
c86af650-6abf-4c2f-8419-f14ce3d4988d	d90f5d76-5db4-4421-8e83-b2ff84049f92	7955656a-dc9c-42c0-aac7-b856d5881ffd	2026-11-13 17:12:36.660796+07	0cf3fc53a5303edda32d7b581c92f5aff05f251cebb308f29699cd639ee214ce	2026-12-13 17:12:36.660796+07	\N	2026-11-13 17:12:36.668408+07	2026-11-13 17:12:36.660796+07
5f97f864-40de-4141-9446-c62c034b2f76	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	c641c898-317a-4c9d-a442-8bd68988e94e	2026-11-13 17:14:11.524095+07	75f1bb1d062907a57f2651c305412f9e1b899aa979d4ceab3aaf9114bea3bc54	2026-12-13 17:14:11.524095+07	\N	2026-11-13 17:22:02.506143+07	2026-11-13 17:14:11.524095+07
c2dc77e0-0a49-4564-8348-47524ecb8522	d90f5d76-5db4-4421-8e83-b2ff84049f92	7a354f58-d7fe-4d8b-a725-03bf485d0b74	2026-11-13 17:42:44.197857+07	b4e8bbda870aaf9ae88197d7d57a7752e408095f0758ac9c7bb0079fa76535dc	2026-12-13 17:42:44.197857+07	\N	2026-11-13 17:42:44.203567+07	2026-11-13 17:42:44.197857+07
b61febf6-4580-4b40-a46c-f284d6afa722	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	90b65923-574f-4ed0-8253-8786202c7405	2026-11-13 17:22:16.263649+07	d8dc433cc2f9c949d6cd161d3b75b87af9f53775f334544f54089b89ce2cc9ff	2026-12-13 17:22:16.263649+07	2026-11-13 17:53:46.24172+07	\N	2026-11-13 17:22:16.263649+07
8ccf9a07-9461-411c-b85d-bea0472482d7	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	90b65923-574f-4ed0-8253-8786202c7405	2026-11-13 17:22:16.263649+07	91ffe085bd20a5e2f795ea0f44244467adceb37b7551cfccd138139b51790a19	2026-12-13 17:53:46.24172+07	2026-11-13 21:28:42.623566+07	\N	2026-11-13 17:53:46.24172+07
0d294e15-c910-4ef0-b754-d50cd11983e3	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	fcd191baa5cc9c447cd82e3e1814a0543b5a9dbd6f760ac880069c54afed2925	2026-12-21 17:45:17.064451+07	2026-11-21 18:00:06.915848+07	2026-11-21 23:10:56.595214+07	2026-11-21 17:45:17.064451+07
7ad4b14b-2129-4253-9e5a-cc553d8d5a91	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	90b65923-574f-4ed0-8253-8786202c7405	2026-11-13 17:22:16.263649+07	917e4ff667e27e825205ede9baa9d0df5b9f4691e2fd3c41c1da809b08f0d670	2026-12-13 21:28:42.623566+07	2026-11-14 07:28:31.548562+07	\N	2026-11-13 21:28:42.623566+07
1b28bb40-8a54-45f0-9fd4-30b7e179f100	44fc6c0c-18d1-4558-a5fd-3beeeb073e22	90b65923-574f-4ed0-8253-8786202c7405	2026-11-13 17:22:16.263649+07	175807a6f4c643668058756def9b1ab5aa702e0aa123315cae241f92f5ca7fbe	2026-12-14 07:28:31.548562+07	\N	\N	2026-11-14 07:28:31.548562+07
980a2230-486f-4a7c-a30e-a304d7424161	1398ff97-2866-4c04-b061-7e7abf3d38e0	e332a703-80a8-4acc-935d-396817dd8138	2026-11-20 22:15:12.077804+07	c7272b3f76aef58e86247689acaadd1a7ecfbb477b2070e99500fd56f4b1eb1c	2026-12-20 22:15:12.077804+07	\N	\N	2026-11-20 22:15:12.077804+07
dccdefaa-e27c-4e29-a935-28756f31a83f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	6358c7139057b7065665718218b4df573e8b7e0c2c642f510db5f0a65e2208e9	2026-12-13 17:23:22.362427+07	2026-11-13 17:53:16.823117+07	2026-11-20 15:52:54.829554+07	2026-11-13 17:23:22.362427+07
f090fc6f-a401-4faf-94b8-e553cf35e635	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	43133e235ea7b09844f6f1ccd388827e999435858f139f7d050461cb517f6847	2026-12-13 17:53:16.823117+07	2026-11-13 21:29:33.077203+07	2026-11-20 15:52:54.829554+07	2026-11-13 17:53:16.823117+07
4b132ddd-0e59-42c4-b0df-f86b021cc40e	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	a6129a28ee2c74631900c5356cca35d88b9db0c7ab28aba6975c51ac526dc684	2026-12-21 09:16:41.53504+07	2026-11-21 09:31:45.234622+07	\N	2026-11-21 09:16:41.53504+07
7f8afd13-9f8a-471f-afe7-d1130f979126	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	7f6ab4effee460ad8c17164c7a1cf9bd4a17609aceeb30bbd00bf7172d69c0ef	2026-12-13 21:29:33.077203+07	2026-11-14 07:29:19.76571+07	2026-11-20 15:52:54.829554+07	2026-11-13 21:29:33.077203+07
44cb49eb-a120-4b9e-a825-6a3ca74eb4ce	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	1d1e09dca4e09d5a89de6ac8e36f7f20f1ff99588bb30adc7c3b1c85d3214caf	2026-12-14 07:29:19.76571+07	2026-11-14 07:52:40.327046+07	2026-11-20 15:52:54.829554+07	2026-11-14 07:29:19.76571+07
e17a0aca-6386-4bb6-a0e7-632e3c277a15	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	394ed50b8b95806e147f74dbf9cc8c7334f7096fd1cafa67d1dd336abbb1f93b	2026-12-21 09:46:48.758632+07	2026-11-21 10:01:52.046271+07	\N	2026-11-21 09:46:48.758632+07
33851996-1355-4581-867e-a271a2273c98	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	d617ced8440b39a862d688aae2b4899eed993bf76c2b8a34e305ae7df4cb76c5	2026-12-14 07:52:40.327046+07	2026-11-14 12:24:08.400955+07	2026-11-20 15:52:54.829554+07	2026-11-14 07:52:40.327046+07
e3e25728-ba8f-4e5b-8c3e-d4791588fffe	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	89835cee-d71f-4cde-bb50-49e718beb138	2026-11-13 17:23:22.362427+07	3229891d0acb0a56daab21c301ed984d04338538d200e563ef8eeb1aadba1b6c	2026-12-14 12:24:08.400955+07	\N	2026-11-20 15:52:54.829554+07	2026-11-14 12:24:08.400955+07
1d181519-22cf-4885-9e39-788430ce6a6d	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	075ee3b893ebee2838d806fb693e8bdb44bad227c4587de0efbd9eef57579665	2026-12-21 10:31:58.773884+07	2026-11-21 10:47:02.125848+07	\N	2026-11-21 10:31:58.773884+07
521a974d-c7ab-4180-a551-b915062a2345	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3ec6b28e-e277-44ff-b1b1-be2eb0b806c5	2026-11-18 09:29:42.992629+07	be25c34e62de064bd1e0ed17525eea3e7f8725d7d987acc8e80c0f692a05b5c5	2026-12-18 09:29:42.992629+07	2026-11-18 09:44:46.233211+07	2026-11-20 15:52:54.829554+07	2026-11-18 09:29:42.992629+07
461da9e0-b9bb-4dea-9ad3-dc5fd5bae16d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3ec6b28e-e277-44ff-b1b1-be2eb0b806c5	2026-11-18 09:29:42.992629+07	931863aa24829904e46d9ce94df57315042482edfaf4669e2c46662742131b0f	2026-12-18 09:44:46.233211+07	2026-11-18 09:59:49.449304+07	2026-11-20 15:52:54.829554+07	2026-11-18 09:44:46.233211+07
3651bc44-8f63-4c17-9a8f-cf9e6eb14e8c	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	09ec788668fa5738c80280a1f7e877055ceb4a49614c58f5892779caac5c5af9	2026-12-21 10:47:02.125848+07	2026-11-21 11:02:05.47905+07	\N	2026-11-21 10:47:02.125848+07
59a840d7-02c9-4b47-a36d-569225a5bcbe	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3ec6b28e-e277-44ff-b1b1-be2eb0b806c5	2026-11-18 09:29:42.992629+07	84e28ad7d76cccca08411c47f77c1a0dbefdbd52f42ca90f0428464460e9048f	2026-12-18 09:59:49.449304+07	\N	2026-11-20 15:52:54.829554+07	2026-11-18 09:59:49.449304+07
fcfd0abf-972c-4baf-9689-c4b169cd0cdd	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	458a868933aa4cafb9b5d0fd4c759ef8cde9553f9f5fdcb24ac1f6e06d5bcb07	2026-12-18 13:30:40.614147+07	2026-11-18 13:45:44.17156+07	2026-11-20 15:52:54.829554+07	2026-11-18 13:30:40.614147+07
677547cb-6f7c-4c48-92dc-eb31988d6def	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	68a27908bee38b4f450a5a741348677d691347a89b28a58da41d30ad63717d93	2026-12-21 11:32:11.531022+07	2026-11-21 11:47:15.085292+07	\N	2026-11-21 11:32:11.531022+07
a71f133f-11ac-459c-a140-290539ab1776	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	70a16138ad1460d9bdbf45789b992752647ef39009087676179de4b97c0a19e6	2026-12-21 12:17:22.019723+07	2026-11-21 12:32:25.443467+07	\N	2026-11-21 12:17:22.019723+07
ec6ea355-ba5b-4588-ae31-0f6445dcfc03	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	897baff308627b038877c7f44b7d1014adbb950c6a0ec4e9f8ee164af68b211c	2026-12-21 07:56:43.298722+07	2026-11-21 08:15:37.59099+07	2026-11-21 15:01:51.856572+07	2026-11-21 07:56:43.298722+07
f965c23f-68f2-46da-9323-dbeef3a6b9d1	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	6c3c227326e05b54579ce3d55dae4a0de39f37042affbd01aaba5f41498716c8	2026-12-21 13:03:54.804877+07	2026-11-21 14:32:33.325431+07	2026-11-21 15:01:51.856572+07	2026-11-21 13:03:54.804877+07
4fa590e7-46ce-4cf0-b3d6-bf4fa47c8b1d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	5189c7eb1df13d7eed69dcc606328ad96ff7d753bcd674155861ba4fe54e9c97	2026-12-21 15:01:51.840999+07	\N	2026-11-21 15:01:51.856572+07	2026-11-21 15:01:51.840999+07
712051df-0985-46e7-9413-2cbb810fb7cb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	dd8e9c3f41a9693b7e4c59e0a32626b1ef479213347f76ef78657b9d06a0b51a	2026-12-21 22:35:11.75038+07	2026-11-21 22:55:11.583648+07	2026-11-21 23:10:56.595214+07	2026-11-21 22:35:11.75038+07
205148b9-6f5c-4560-b272-e85572481a98	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	943fc2a9a7ee72ce361558ef8bb1f28c762a99d40031c86231a1e52051c11dd6	2026-12-20 21:15:37.487519+07	2026-11-20 21:35:19.364665+07	2026-11-21 22:59:13.28242+07	2026-11-20 21:15:37.487519+07
fe89ae7a-5fa1-40f1-8319-03e2bf5c9922	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	2c17547d2c50aac39066b489360051b4c8c1a9f0338d2baedbe557d79845157b	2026-12-14 12:37:18.28078+07	2026-11-14 12:52:45.791178+07	2026-11-20 15:32:38.409558+07	2026-11-14 12:37:18.28078+07
6068edc9-773d-433b-8610-f18943b6a5cc	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	f0ff03d6745b5e55845421cacc943b6bd29d670d64820c08e36e86969ca91d6e	2026-12-21 21:30:38.538709+07	2026-11-21 22:59:10.392018+07	2026-11-21 22:59:13.28242+07	2026-11-21 21:30:38.538709+07
8d2e252c-0259-45ff-baa7-02f14974d76c	1398ff97-2866-4c04-b061-7e7abf3d38e0	2fe5a4f0-21aa-4d16-876a-5d21636c3d0f	2026-11-21 09:17:08.955052+07	90be7fca956bbde1e4ad660b91a31b392400a644101232166b5127719d96b5a7	2026-12-21 09:17:08.955052+07	\N	\N	2026-11-21 09:17:08.955052+07
374524ae-c360-4b5f-8807-eed91eb03310	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	2b6222174aadbf34af3864b547e3962bbba86c2b16396e725dd0eb805b694e59	2026-12-20 21:35:19.364665+07	2026-11-20 22:53:05.095858+07	2026-11-21 22:59:13.28242+07	2026-11-20 21:35:19.364665+07
90980c44-623a-489c-9d87-3f8a9727471a	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	71492dafa2278ca714931273cf343bb6a63f80d1e7103239d378433175d3c9c8	2026-12-21 09:31:45.234622+07	2026-11-21 09:46:48.758632+07	\N	2026-11-21 09:31:45.234622+07
fb3f0163-85df-4dc0-acd2-3c92aaa90d1b	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	58aa55ccc0b80f2eb5d2d487e065892d1633df22ed0c65df5e1b15de1b21f1e8	2026-12-21 10:01:52.046271+07	2026-11-21 10:16:55.374065+07	\N	2026-11-21 10:01:52.046271+07
e9ccffcb-a4a8-4c51-ac73-879cde526e87	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	932780ae1934791a950b577fe7e112e7e97077b337222eaa1c8533ee1e5fe242	2026-12-21 11:02:05.47905+07	2026-11-21 11:17:08.781269+07	\N	2026-11-21 11:02:05.47905+07
e06d111d-46a9-4b75-814a-3fbcba3f8488	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	668380b8c9fdbbb4d87457471b79e2edb5f54d20d4bfd2b6b9b2690361ff64b3	2026-12-18 13:45:44.17156+07	2026-11-18 14:00:48.032237+07	2026-11-20 15:52:54.829554+07	2026-11-18 13:45:44.17156+07
122de997-db49-49c7-b8db-887e4aaafb8a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	226307e98eba9b3474fdb6fdb3b3d4916567e7f2d84e61a85385ba7bfa1ff5e0	2026-12-18 14:00:48.032237+07	2026-11-18 14:15:51.48023+07	2026-11-20 15:52:54.829554+07	2026-11-18 14:00:48.032237+07
0cdb01b3-cc8c-4c10-9a46-cd8c625e0143	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	834c2bd79396141eff1a47a808ab9c6df0369d3d5f2666d4f28c5d562321c4ad	2026-12-21 11:47:15.085292+07	2026-11-21 12:02:18.448705+07	\N	2026-11-21 11:47:15.085292+07
a22d1253-5e8b-42ac-acc3-954560a78192	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	4e38a620e7cf69c43094632f0f4130665d6d2fade86f2f7fa264cf4cac6d4c34	2026-12-18 14:15:51.48023+07	2026-11-18 14:30:54.952015+07	2026-11-20 15:52:54.829554+07	2026-11-18 14:15:51.48023+07
f9b0aac4-0a46-4e8e-a9cc-d2a281e1ae4d	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	f77f5bcf112392522c351f9bf72535609a81cbafc915cea071b74dd9f5ee1814	2026-12-21 12:32:25.443467+07	2026-11-21 12:47:28.757367+07	\N	2026-11-21 12:32:25.443467+07
f6ba2238-2b28-45ad-a2a1-7a18777130a8	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	456399a757e5b838ac8aa43ce46a89710ae7e3c67dce5fd5a94078912bb9e988	2026-12-18 14:30:54.952015+07	2026-11-18 14:45:57.592418+07	2026-11-20 15:52:54.829554+07	2026-11-18 14:30:54.952015+07
160d99bd-c09e-41ee-9fad-f0b96b69ab32	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	ef9479bfcef329b3b1ec1551918a513fcdc178aff2e8bafe9fc6791f40c66c35	2026-12-18 14:45:57.592418+07	2026-11-18 15:01:01.035131+07	2026-11-20 15:52:54.829554+07	2026-11-18 14:45:57.592418+07
3813c991-ff90-4075-a138-f69a5d429eee	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	3ac7ad354fed57fcc082243663fdb912274236e75fc83ebcf0e2d588db558ce8	2026-12-20 22:53:05.095858+07	2026-11-21 07:27:40.045848+07	2026-11-21 22:59:13.28242+07	2026-11-20 22:53:05.095858+07
8de0fbd4-4855-480e-8a73-8ef86cf18d8f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	c86571408e3fa8c296ef636ed2922f0874a4ba8037d4f2fbf12114baad29920d	2026-12-18 15:01:01.035131+07	2026-11-18 15:16:04.482939+07	2026-11-20 15:52:54.829554+07	2026-11-18 15:01:01.035131+07
d68b7a10-87a3-4209-ae10-6e5baad8b776	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	c46408f8a891d600aae4d90dde19b4ce6bf821c944c235ede226a2ba01430881	2026-12-20 21:20:53.062018+07	2026-11-20 22:00:52.20289+07	2026-11-21 15:01:51.856572+07	2026-11-20 21:20:53.062018+07
78b6d672-b537-4884-9aff-3f6c8d493e8d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	828a63e056cdc7f13aaf4e54d00c83f1d1e98543ef39d1f94ca216d1a49a4e69	2026-12-18 15:16:04.482939+07	2026-11-18 15:31:08.145383+07	2026-11-20 15:52:54.829554+07	2026-11-18 15:16:04.482939+07
656d4937-e928-4eb0-847e-2e0a80f11440	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	518140f73d3a1dacb068534937b7544462872656e2710501f40599c83026f0f8	2026-12-20 22:32:50.523964+07	2026-11-21 07:39:39.304935+07	2026-11-21 15:01:51.856572+07	2026-11-20 22:32:50.523964+07
29f473e3-3856-4350-8125-803908044eaa	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	74dbf75a0aaf56185f6ce83965f5bcccd6d88ccfe73f47da8484829286ae9b79	2026-12-18 15:31:08.145383+07	2026-11-18 15:46:11.775503+07	2026-11-20 15:52:54.829554+07	2026-11-18 15:31:08.145383+07
9ec5ac1f-a39d-4c61-bc57-9c0b0c59eebb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	740a7941520f8d42fca023a20bd4c0711fa287de423444d703e60b17975c77d3	2026-12-21 08:15:37.59099+07	2026-11-21 09:18:39.402438+07	2026-11-21 15:01:51.856572+07	2026-11-21 08:15:37.59099+07
aadc0a55-74c5-4e7f-98d0-ce1e2d70fb1f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	63ec7d49c81d7ce7e6b47d1d30fb145290b2d038e679c71d3f3760b65262a8e9	2026-12-18 15:46:11.775503+07	2026-11-18 16:01:14.300449+07	2026-11-20 15:52:54.829554+07	2026-11-18 15:46:11.775503+07
c21bb4bd-6aee-4269-9e0f-b0f33ac8afe6	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	9ea2d738a55d4c6f09d91fb99ecf2da9de7e50488c66d390f9dbb63718c447cb	2026-12-21 14:32:33.325431+07	2026-11-21 14:46:46.826563+07	2026-11-21 15:01:51.856572+07	2026-11-21 14:32:33.325431+07
fe1c69c9-cda5-4699-9173-a4034c7e2cb3	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	09c22df96a9df34984738b53a7bde3a8ca8fdd76e9e04f729b8d90c6a93ce91c	2026-12-18 16:01:14.300449+07	2026-11-18 16:16:17.675853+07	2026-11-20 15:52:54.829554+07	2026-11-18 16:01:14.300449+07
ee641c37-43b6-4306-9cd4-f47f40c33d4f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	a03ce5041e6e9073706c930047fad5a7fdc6ee0c6bf078a741b7f55ecfd693c5	2026-12-18 16:16:17.675853+07	2026-11-18 16:31:20.804538+07	2026-11-20 15:52:54.829554+07	2026-11-18 16:16:17.675853+07
63f538fb-d258-4925-8ad8-ab27f5c66f0e	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	dc0d3b79b49deb9b93787967c2c4a024daa4e1449ab8953ef21dc3a17ff0d1c1	2026-12-18 16:31:20.804538+07	2026-11-18 16:46:24.141539+07	2026-11-20 15:52:54.829554+07	2026-11-18 16:31:20.804538+07
e79e9b03-1e60-4669-a9f9-c24bdc5683bb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	9434bce6c42001fde531dfd2df82599b5548c13efa033f2fa2326563a9b0541e	2026-12-18 16:46:24.141539+07	2026-11-18 17:01:27.508268+07	2026-11-20 15:52:54.829554+07	2026-11-18 16:46:24.141539+07
3e57a0f8-b1ab-45b8-98c9-dccf21980090	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	f07e90498796f003638dc9e2b2226200eee25ec46fdbd98b9f6dd518784eaa9d	2026-12-18 17:01:27.508268+07	2026-11-18 17:16:30.879612+07	2026-11-20 15:52:54.829554+07	2026-11-18 17:01:27.508268+07
1e2d5985-bd45-4129-9957-04e5c7966ca4	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	8b8fe3851908658a4e2ff26e38f93990a90d86b904815572a0a508e4bf6407e8	2026-12-18 17:16:30.879612+07	2026-11-18 17:31:33.276046+07	2026-11-20 15:52:54.829554+07	2026-11-18 17:16:30.879612+07
158b2139-4fb8-46cf-b194-aadb5abbc27b	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	a29b9570-27c6-4bfd-a3d1-4a2c653f9d55	2026-11-18 13:30:40.614147+07	b1d0cb45c941f52281d1c8c297001a60df1f1fa4721cf8725e756479f8635168	2026-12-18 17:31:33.276046+07	\N	2026-11-20 15:52:54.829554+07	2026-11-18 17:31:33.276046+07
5e645705-c42e-49ff-977c-c4f6b1796631	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	8dc120597146777c8f03d1d7ee3b073cba6a3c2ce44529ea065b7a5aa52faea0	2026-12-21 16:59:56.416295+07	2026-11-21 17:19:02.882833+07	2026-11-21 23:10:56.595214+07	2026-11-21 16:59:56.416295+07
9280a3aa-072b-4b75-a7e7-a60989d75de8	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	ed4bff6f07e519c5ba23616d4b0425fb57c68dacf4b91c3f1fb1753ea11bb00e	2026-12-21 18:00:06.915848+07	2026-11-21 21:23:36.258743+07	2026-11-21 23:10:56.595214+07	2026-11-21 18:00:06.915848+07
7a4bb91a-0cf9-44d2-a1c4-e66972c6a759	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	da8477fc135193ebe7dd604d18a1eaa5f87ae43a2f8de178c7014bf505cd7651	2026-12-21 21:37:44.401332+07	2026-11-21 22:09:52.947713+07	2026-11-21 23:10:56.595214+07	2026-11-21 21:37:44.401332+07
1459848a-c9ae-4a8a-9457-102ce7473075	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	1245d344c9fa12a90d10025051eb2e9d839bc5a60a10cab67ca9f37344d63b8b	2026-12-21 22:55:11.583648+07	2026-11-21 23:10:38.208079+07	2026-11-21 23:10:56.595214+07	2026-11-21 22:55:11.583648+07
65c87e30-ef36-4391-b52b-d58cb8469f6e	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	b5d043337351c02ecf4ca07f075bfbed2ccd88ed9c58f97ac5f96d7e25969f25	2026-12-14 12:52:45.791178+07	2026-11-14 13:09:40.307028+07	2026-11-20 15:32:38.409558+07	2026-11-14 12:52:45.791178+07
831ce376-eee2-438f-840e-aae1fec346fd	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	165660d9c1a2bcd7c07cb8da84f253784713f4021019ebd27e843e5d71ddbfb7	2026-12-21 23:16:55.409715+07	2026-11-21 23:34:15.93662+07	2026-11-23 21:16:43.544739+07	2026-11-21 23:16:55.409715+07
674b85be-a274-402c-9f8b-556ff9dc2e64	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	3df12e02b7e9af2249d935722ea98f5323572bfaeb3ac0379ca7b58756edd2ef	2026-12-14 13:09:40.307028+07	2026-11-14 14:03:29.665879+07	2026-11-20 15:32:38.409558+07	2026-11-14 13:09:40.307028+07
8ce4f328-54a6-4b57-a387-ed2ce595e781	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	df57be5841702f4502462ba581d46585f22a774dc72e45bab984a5f3f7e18bd6	2026-12-14 14:03:29.665879+07	2026-11-14 15:09:54.566016+07	2026-11-20 15:32:38.409558+07	2026-11-14 14:03:29.665879+07
c04fe323-4708-43bf-a991-b974455d9854	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	bcbbc9e4f4043311827fe2024e305a917b43c2c61ac2d25fc52925432a87e860	2026-12-14 15:09:54.566016+07	2026-11-14 22:46:31.800357+07	2026-11-20 15:32:38.409558+07	2026-11-14 15:09:54.566016+07
8e614e89-b034-4312-859a-67c1dfbce93a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	93796369b0821a2461ad143a8766ce0429f6c233f06943fcfe3491aff55fdb96	2026-12-14 22:46:31.800357+07	2026-11-14 23:02:38.968447+07	2026-11-20 15:32:38.409558+07	2026-11-14 22:46:31.800357+07
ad5dbda8-9238-44d6-abc4-9652e4eeb294	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	a836e950d9f259e3af884d277565926007ff411e7bf122a650a0b0ac5ab6a53e	2026-12-14 23:02:38.968447+07	2026-11-17 10:17:24.672523+07	2026-11-20 15:32:38.409558+07	2026-11-14 23:02:38.968447+07
53b9cdb8-c2de-406e-8494-6ed997b615c5	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	65a859c47b2611bc74da2d5fff2d99391e99a8f872cd41d9bfcf313ec80f65a6	2026-12-17 10:17:24.672523+07	2026-11-17 10:41:32.463923+07	2026-11-20 15:32:38.409558+07	2026-11-17 10:17:24.672523+07
f17bcd48-8f2a-4537-9722-b1e53156d85d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	a13ecdfb0620bb4646851085e0a529ac62d714b221dc2012abd315f43b7a058f	2026-12-17 10:41:32.463923+07	2026-11-17 11:23:46.243551+07	2026-11-20 15:32:38.409558+07	2026-11-17 10:41:32.463923+07
52e63cfa-6698-4a41-a967-af3b59bf659b	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	afbfc9bf07ad86f3837473cd076f427c13393fbad1efe0ebfdec3b3c3c8ff5e1	2026-12-17 11:23:46.243551+07	2026-11-17 11:39:11.63097+07	2026-11-20 15:32:38.409558+07	2026-11-17 11:23:46.243551+07
9c7d95e2-e729-4784-9f14-ea0996e01a98	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	bb5f27ed7366a8be6df832b01125e6d6a0bcaaabba00e171090b1d50bb98f915	2026-12-17 11:39:11.63097+07	2026-11-17 11:53:16.298062+07	2026-11-20 15:32:38.409558+07	2026-11-17 11:39:11.63097+07
e0b28a45-b57f-4d8b-814b-98319c644977	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	4c8b3f427d6ad53cff02051844976a59cb90a15c2a49917a5ea6ab2e070158e1	2026-12-17 11:53:16.298062+07	2026-11-17 12:22:43.328601+07	2026-11-20 15:32:38.409558+07	2026-11-17 11:53:16.298062+07
8e50ace7-a29c-446e-b1f9-3b23ae2bfa77	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	c70974194ca657e7eceaf5f15d0f7b10d7edb2994f4ad7e6dab135369b875078	2026-12-17 12:22:43.328601+07	2026-11-17 12:38:47.93241+07	2026-11-20 15:32:38.409558+07	2026-11-17 12:22:43.328601+07
35a4a59e-546e-4a67-9762-494a36d4a4f7	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	65f7df58828bc7c4a5c99f9f8b54ce068d89a6194c9f7df1d115c16ffbf34a04	2026-12-17 12:38:47.93241+07	2026-11-17 13:14:45.756362+07	2026-11-20 15:32:38.409558+07	2026-11-17 12:38:47.93241+07
fc17db91-49cf-49aa-aeaf-584dc8e174ac	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	e07e0503368a489c266f980203d1bb36c2a815ddfe91ac75f36c925733f621b9	2026-12-17 13:14:45.756362+07	2026-11-17 17:23:25.412529+07	2026-11-20 15:32:38.409558+07	2026-11-17 13:14:45.756362+07
83f37cc5-08e4-4cf0-9306-1964dfc36b26	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	1d34ca4cc3ffd8c11e421af59612c631bd945246967a3b99ee2fa13439bfb995	2026-12-17 17:23:25.412529+07	2026-11-19 13:08:08.783902+07	2026-11-20 15:32:38.409558+07	2026-11-17 17:23:25.412529+07
39757466-b208-43bf-b35a-9bd0074062c3	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	733826e557764330111ff0ce35d4870ab9a7205a97a85517ff6292fa504f484b	2026-12-19 13:08:08.783902+07	2026-11-19 13:38:07.631707+07	2026-11-20 15:32:38.409558+07	2026-11-19 13:08:08.783902+07
6af04963-f92c-4680-865c-eed1ed1ce87d	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	d69f4895752c289221436b79786e1eae62b2a6649ee51c4cad7f38148ee3c1cc	2026-12-19 13:38:07.631707+07	2026-11-19 15:44:35.710212+07	2026-11-20 15:32:38.409558+07	2026-11-19 13:38:07.631707+07
ba955321-dfc7-4ff5-9e5f-ae26e4ee5d97	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	377a51100d714b516466504971b0230b76eaa1c4b985aa215dfe0c31ace2adcd	2026-12-19 15:44:35.710212+07	2026-11-19 16:53:51.350294+07	2026-11-20 15:32:38.409558+07	2026-11-19 15:44:35.710212+07
5593fbab-fb88-4713-9999-2e21bc7fe8bb	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	41988d9f5593e8b08a68110c7276ae41c669391c9d41aa81641c79d60f307625	2026-12-19 16:53:51.350294+07	2026-11-19 17:13:53.624478+07	2026-11-20 15:32:38.409558+07	2026-11-19 16:53:51.350294+07
bca55e52-a64c-4aa5-b178-86974cabe6f6	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	04d36e5d312c6eaccb6d94c7d67e4e94c55b3a96835ba65fc5e68d8037f1cde4	2026-12-19 17:13:53.624478+07	2026-11-19 17:46:36.141904+07	2026-11-20 15:32:38.409558+07	2026-11-19 17:13:53.624478+07
0d3db326-dfd4-467f-b040-214ba2cf75a9	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	e9fe1cd0d7c1bc56ba0cdd8d50109405ae446407f87d1c05aeddb161f4f6dc8e	2026-12-19 17:46:36.141904+07	2026-11-19 19:00:31.981413+07	2026-11-20 15:32:38.409558+07	2026-11-19 17:46:36.141904+07
e74e61c9-d4bb-4f2f-b251-f40fd3d41464	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	33cfbc8fbdfda1f22ea233d41bdb5e4d25406db86f4e7fd636d1e6a3d0832dfb	2026-12-19 19:00:31.981413+07	2026-11-19 21:08:55.443536+07	2026-11-20 15:32:38.409558+07	2026-11-19 19:00:31.981413+07
c9dc1630-15d9-4a9c-8623-47a29fc0bb10	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	0a2572e93a4d3db74e1dc97575c5401590199de135e45c6f376721333efee61e	2026-12-19 21:08:55.443536+07	2026-11-19 21:24:39.749665+07	2026-11-20 15:32:38.409558+07	2026-11-19 21:08:55.443536+07
6942bed3-b630-404e-b0ae-66d8abb2b208	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	5619909de193e047322446edfa566d42626ee9471f08172d7fa2d3158f64549a	2026-12-19 21:24:39.749665+07	2026-11-19 21:39:16.979955+07	2026-11-20 15:32:38.409558+07	2026-11-19 21:24:39.749665+07
84aed6c9-c8a5-4fb0-a962-fb6fa9c96692	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	ed6cced8d9a93d5cf0459ead1a4c3fdf3795be5a51e31a9826334d65b7503e26	2026-12-19 21:39:16.979955+07	2026-11-19 21:54:55.982798+07	2026-11-20 15:32:38.409558+07	2026-11-19 21:39:16.979955+07
5df0c028-a532-4ccb-84bc-56f0468b1552	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	b59cb6c9e9f431d0f28448d4a1dea1e7ed332c432e8be2a7df4c313d5a293a9f	2026-12-19 21:54:55.982798+07	2026-11-19 22:10:35.894306+07	2026-11-20 15:32:38.409558+07	2026-11-19 21:54:55.982798+07
75c442d4-3340-4888-a7ea-80a7358b6432	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	358bf5cdf5cc295e8691012d2d61c54b3d17aa64cc0e9313474e0abe7d6fbde9	2026-12-19 22:10:35.894306+07	2026-11-19 23:00:06.032784+07	2026-11-20 15:32:38.409558+07	2026-11-19 22:10:35.894306+07
fc02a939-f4ce-4aa2-bc65-2b941f315847	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	9c501c04772db74383f434104f701d3c57f33f76e02fdffe54a4f15022f85e00	2026-12-19 23:00:06.032784+07	2026-11-20 07:55:48.400526+07	2026-11-20 15:32:38.409558+07	2026-11-19 23:00:06.032784+07
6894a6f9-00e6-414e-9fc0-7fd7695afb05	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	c95002e490bf09d366ca7cd30301491298c29599095dbb8651069ca5ea17f604	2026-12-20 07:55:48.400526+07	2026-11-20 08:20:13.579036+07	2026-11-20 15:32:38.409558+07	2026-11-20 07:55:48.400526+07
da44906c-5952-4d0e-baab-5249c1e43c86	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	3e84f42635159440b358216297092695a07cc5502bc06dce62388f62d0608f48	2026-12-20 08:20:13.579036+07	2026-11-20 08:35:36.526311+07	2026-11-20 15:32:38.409558+07	2026-11-20 08:20:13.579036+07
2cfd778b-4946-4803-b29b-73472e42dd28	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	6d4be321120a13186330bc79d50fce7caf7da49f1ed49a27ed26fe742592af4e	2026-12-20 08:35:36.526311+07	2026-11-20 09:29:14.677223+07	2026-11-20 15:32:38.409558+07	2026-11-20 08:35:36.526311+07
efb4e170-54b4-4973-9b01-7a246922b64a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	72038a100bf6d234d0fe25fa5f37524cbc83377e9de3b8cf5a6a08abb57f0a62	2026-12-20 09:29:14.677223+07	2026-11-20 09:44:58.180517+07	2026-11-20 15:32:38.409558+07	2026-11-20 09:29:14.677223+07
0a06c61c-d43a-4057-bf7c-b9deb96202dc	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	62f26dd1383d9c22f164149dceb3e6a0a973f6836c97392b0a39815e401bfd1a	2026-12-20 09:44:58.180517+07	2026-11-20 10:17:51.4379+07	2026-11-20 15:32:38.409558+07	2026-11-20 09:44:58.180517+07
2f72cc8a-eec7-4086-881f-15d44540b4a7	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	b585a639f6b2a5a381a2214f3e121bc5bbb5c9c25727a160765342481df318b2	2026-12-20 10:17:51.4379+07	2026-11-20 10:57:25.245947+07	2026-11-20 15:32:38.409558+07	2026-11-20 10:17:51.4379+07
de646f83-391f-430c-a0f7-884ce18c3f99	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	b0084f02935ccb9ddd9afb48a117f785fb461ad24402cb3ff882c00e8439f6d7	2026-12-20 10:57:25.245947+07	2026-11-20 11:14:45.32671+07	2026-11-20 15:32:38.409558+07	2026-11-20 10:57:25.245947+07
f07bae8b-8870-436b-8f35-209d3e58bd03	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	e6db185fd48aee0eb72f5ddbe77d0c1b762f6812b893f21378dbd0653f1069b2	2026-12-20 11:14:45.32671+07	2026-11-20 13:35:04.524535+07	2026-11-20 15:32:38.409558+07	2026-11-20 11:14:45.32671+07
1097f448-2c64-4b55-87bb-8c068db5a586	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	b935f8160a77a67411cfd199dbbacd0e21b38e3ed0f5439174ab784b2dad6ca3	2026-12-20 13:35:04.524535+07	2026-11-20 13:51:24.696635+07	2026-11-20 15:32:38.409558+07	2026-11-20 13:35:04.524535+07
e6a83ce8-f9ff-486b-8e72-bfa790c63fda	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	acc0c93a7bce129788117effea0985560fc26ce8e6f174af2585ec39b0f42e6e	2026-12-20 13:51:24.696635+07	2026-11-20 14:12:18.817737+07	2026-11-20 15:32:38.409558+07	2026-11-20 13:51:24.696635+07
cdcfeeb9-119c-40fb-881f-e77d914dcf00	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	37d1a22db9ff251c1b1795de5db24c2276c9f08fd4ffe2db9383417aba144c1b	2026-12-20 14:12:18.817737+07	2026-11-20 15:19:45.807389+07	2026-11-20 15:32:38.409558+07	2026-11-20 14:12:18.817737+07
fac6e929-e07f-4ad8-b0da-eaaec16a07d2	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	3babf8cf-d3dd-446e-9f87-bd4464733e76	2026-11-14 12:37:18.28078+07	372c2aac6a5b9afeb751a211f0cf1b4e5c6db7a01d51aa923a6853b88a566992	2026-12-20 15:19:45.807389+07	\N	2026-11-20 15:32:38.409558+07	2026-11-20 15:19:45.807389+07
093e2a1b-14a3-498c-a1ed-0b1117ecd3c0	ac1cf0b9-aa2c-4f49-b369-027b1a662deb	1526965c-d5ce-4949-b9b2-7595e78123ab	2026-11-20 15:52:23.218989+07	7543a4df6f80d161b13cc28f06946f2907ca249845d40ae6886699d76cde5062	2026-12-20 15:52:23.218989+07	\N	2026-11-20 15:52:28.738855+07	2026-11-20 15:52:23.218989+07
c18400a9-c021-43c1-8559-0d51d0780bf8	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	8fcc1dfb-26b6-4222-811c-684ddc730265	2026-11-20 15:52:54.831272+07	ec91df7c3a130e338116cbe63c22aa3c64676418d5b40f48fceb168586d5f820	2026-12-20 15:52:54.831272+07	\N	2026-11-20 15:53:46.919697+07	2026-11-20 15:52:54.831272+07
0ea0fd5c-27c2-42c6-af4b-00eb8756b2e4	1398ff97-2866-4c04-b061-7e7abf3d38e0	318658cf-a5df-46f2-8ff9-7a93a08c3a67	2026-11-20 17:34:29.547522+07	32e72597c7e2151eaaed40fa628740d2bfccb23c2d6e5f999db31655a7b6f74f	2026-12-20 17:34:29.547522+07	\N	\N	2026-11-20 17:34:29.547522+07
91c3cef8-fdfe-49c1-9ce3-d27888520f37	1398ff97-2866-4c04-b061-7e7abf3d38e0	3377c641-664f-401f-9b09-555513478819	2026-11-20 17:36:04.351199+07	60d1df034ed39e2907949cb469188bb671bb539285ef0d48c15e9daf7064a98e	2026-12-20 17:36:04.351199+07	\N	\N	2026-11-20 17:36:04.351199+07
5e5c738f-9964-4832-9098-486db54f6904	1398ff97-2866-4c04-b061-7e7abf3d38e0	0172a874-8c95-470e-84e4-fdd88a74fc50	2026-11-20 17:36:23.426716+07	4e7569332b678b919d75c5f34e1e3dfe87ddcc37c82318e12fb9fe82bfdbf4d5	2026-12-20 17:36:23.426716+07	\N	\N	2026-11-20 17:36:23.426716+07
1e27d7a4-0a40-443b-b126-87cac64673b8	1398ff97-2866-4c04-b061-7e7abf3d38e0	4f31005e-90ae-407b-89ca-0cc5c5479add	2026-11-20 18:25:59.262178+07	0c34825ccf3332549613e65f22e25b09a2e14cdc449c42d0de69277b5448b394	2026-12-20 18:25:59.262178+07	2026-11-20 19:01:22.672021+07	2026-11-20 19:01:29.32133+07	2026-11-20 18:25:59.262178+07
da61d14b-4457-4ad6-8e7c-92d00a0faa71	1398ff97-2866-4c04-b061-7e7abf3d38e0	4f31005e-90ae-407b-89ca-0cc5c5479add	2026-11-20 18:25:59.262178+07	970a8fdd957b46721fb1ddab5e64ed617590bab9aeebd04ac47a2a77ced2a4ad	2026-12-20 19:01:22.672021+07	\N	2026-11-20 19:01:29.32133+07	2026-11-20 19:01:22.672021+07
f0652e50-1124-4957-80e7-34c2ed1ba22c	feee6658-cda5-43b0-b70e-f38b39b592d4	89cc8e4e-015b-4bed-9c62-cbf4e3f68b40	2026-11-22 07:32:46.85696+07	a220f4cd3397d4ffcb8f5d843ad04d6eac119a024d9a2c7ee6bea38f1aa65b41	2026-12-22 07:32:46.85696+07	\N	2026-11-22 07:43:10.346038+07	2026-11-22 07:32:46.85696+07
885d169d-8fe0-46b1-8c48-259491d012ee	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	7eb65fd217412fc86766d087d0baab4051cc7ab671c44faa348f0d2c9582e80a	2026-12-21 10:16:55.374065+07	2026-11-21 10:31:58.773884+07	\N	2026-11-21 10:16:55.374065+07
0f25625a-8d37-4183-a7f6-98f3c470f157	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	940020667beb44c824fdca646eed293c517c0ade3497095d42c6ce7df2478c18	2026-12-21 11:17:08.781269+07	2026-11-21 11:32:11.531022+07	\N	2026-11-21 11:17:08.781269+07
e35f538e-b683-48e3-bfa7-b18eba5823dc	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	e72afeeb2812054a075be90327ef616a0fa3c99eaebca70e13d346e75616eb44	2026-12-21 12:02:18.448705+07	2026-11-21 12:17:22.019723+07	\N	2026-11-21 12:02:18.448705+07
26583a1b-a6fa-4148-9cca-983462063984	1398ff97-2866-4c04-b061-7e7abf3d38e0	e69dea72-a274-465c-8166-e523fdb13749	2026-11-21 09:16:41.53504+07	f6d08edc6cd5964eaa874ac1afb53f30a62a0e49076181d90843954aebdadbdd	2026-12-21 12:47:28.757367+07	\N	\N	2026-11-21 12:47:28.757367+07
813f6af4-6dae-4731-9faf-c7385b976da9	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	4c5b38068f1d373c8dbcce60022202c40395ca437211b38c4dfa2d7b8dc8e9ed	2026-12-20 19:41:21.357028+07	2026-11-20 21:15:37.487519+07	2026-11-21 22:59:13.28242+07	2026-11-20 19:41:21.357028+07
0e2a08c6-152b-44c4-be3f-4c70cf8a0550	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	cf233dbb765a45c7570b8f29c4166b473530c9e8d3b10eae8e44681794ad28c6	2026-12-20 16:07:19.402737+07	2026-11-20 18:30:08.456182+07	2026-11-21 15:01:51.856572+07	2026-11-20 16:07:19.402737+07
6d965714-c9b7-4424-a152-43aeaa28f00f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	d8b6513118d04678450fb0dc483c854c72e48605b4a9064cc74c83735914ae0e	2026-12-20 18:30:08.456182+07	2026-11-20 19:35:18.725379+07	2026-11-21 15:01:51.856572+07	2026-11-20 18:30:08.456182+07
3310467f-9a8a-40f3-bc50-a907b31c1c22	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	a220ee0df82db15ecdd8a7a751a9c671b8844160eac1cae2583bd70b6b70106f	2026-12-20 19:35:18.725379+07	2026-11-20 19:52:29.881156+07	2026-11-21 15:01:51.856572+07	2026-11-20 19:35:18.725379+07
0bf846c4-53e1-48d9-ab3d-99b1d5c5dcde	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	a94bee75c92f4c7e9cd0f6742fd31156022d0d9cc2a77a6d1faf8b656de47a6e	2026-12-20 19:52:29.881156+07	2026-11-20 20:14:52.416658+07	2026-11-21 15:01:51.856572+07	2026-11-20 19:52:29.881156+07
90443b6a-a119-4b29-a27a-6d263b0ce9bd	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	2e52af857b4a0ba9233ee7720ea308be6dea899d38ef21180807a7f7f5f15e81	2026-12-20 20:14:52.416658+07	2026-11-20 20:34:14.577974+07	2026-11-21 15:01:51.856572+07	2026-11-20 20:14:52.416658+07
98ddf50f-a81c-4054-a8af-d795ac02d94a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	032a316df61bf6f87147cda29f652244fc98b6c42d49f4ffd3bff273e6a706d9	2026-12-20 20:34:14.577974+07	2026-11-20 21:20:53.062018+07	2026-11-21 15:01:51.856572+07	2026-11-20 20:34:14.577974+07
859fc51d-5472-4d9c-bcde-f0fe91ddcc86	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	55585e443b263debc858018928695930ec4cc92dc8bfa5cf74048506a360eaee	2026-12-20 22:00:52.20289+07	2026-11-20 22:32:50.523964+07	2026-11-21 15:01:51.856572+07	2026-11-20 22:00:52.20289+07
820d34ad-af2e-40b9-b773-9ed62ef5d286	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	4dcca8d5d88a4fdb2e3faa4a410dc4c9c0cb23e94bc6b3d4f8570cf77c9a481b	2026-12-21 07:39:39.304935+07	2026-11-21 07:56:43.298722+07	2026-11-21 15:01:51.856572+07	2026-11-21 07:39:39.304935+07
4e671ae3-3f59-4af3-8ed1-4005315f6378	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	4f9fe9ea81085449377ccc8f8e755e73517dd16f448d349fc23b26e6ce9eacdf	2026-12-21 09:18:39.402438+07	2026-11-21 13:03:54.804877+07	2026-11-21 15:01:51.856572+07	2026-11-21 09:18:39.402438+07
f6f6f4c5-03a8-4698-8468-7d712e4864cc	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	1ee8a7e1-1153-4d2b-93b4-a46705e25121	2026-11-20 16:07:19.402737+07	ff4aa20d31ccfb38e3419b643a7f623131f6c76a095ff10f958e54e2179b5e68	2026-12-21 14:46:46.826563+07	2026-11-21 15:01:51.840999+07	2026-11-21 15:01:51.856572+07	2026-11-21 14:46:46.826563+07
7b27c2c1-5581-48da-994d-bc59fa46f40a	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	af71220947373858e4dfaa9e9c4d67190f9b0bb1841856b93ee2695bff785fc8	2026-12-20 19:24:34.308024+07	2026-11-20 19:41:21.357028+07	2026-11-21 22:59:13.28242+07	2026-11-20 19:24:34.308024+07
024f9fc7-5172-4dd5-b50c-987b580e54d8	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	2f693bcf06141329ab9bd2cd2a307215d6e9db292b42a9f79db621c7ea2f622a	2026-12-21 08:26:54.807974+07	2026-11-21 21:30:38.538709+07	2026-11-21 22:59:13.28242+07	2026-11-21 08:26:54.807974+07
f824a87d-6edb-4517-a4a8-3f6efd83fd28	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	1e42f6b35ad98b5be4603e75f4ff67020b33f6d296a92892bbbee8dc3ef5597b	2026-12-21 07:27:40.045848+07	2026-11-21 08:26:54.807974+07	2026-11-21 22:59:13.28242+07	2026-11-21 07:27:40.045848+07
860111ee-7f09-4402-b101-51ebfaf2568a	feee6658-cda5-43b0-b70e-f38b39b592d4	62940449-b7a6-4b09-be36-8a0e94d69b92	2026-11-20 19:24:34.308024+07	3bc0bebbe06df8fc24b0a80364e66230f1cf362521dbda5fbbd7aa62d4084278	2026-12-21 22:59:10.392018+07	\N	2026-11-21 22:59:13.28242+07	2026-11-21 22:59:10.392018+07
43bd60f3-2b81-4158-a9de-5587b16462b5	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	52c5fbde34a2aded0f670752097e57000b36873caf98dc04cfa62ca91278785b	2026-12-21 17:19:02.882833+07	2026-11-21 17:45:17.064451+07	2026-11-21 23:10:56.595214+07	2026-11-21 17:19:02.882833+07
f0a5d444-91ad-4f80-83cf-7c329d157de5	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	0c8c316e657ef4a19696ab560dfb672baa4ed6401eb057620ddfd68b2ac19ec1	2026-12-21 21:23:36.258743+07	2026-11-21 21:37:44.401332+07	2026-11-21 23:10:56.595214+07	2026-11-21 21:23:36.258743+07
8f77d80f-d3ef-4c89-9bef-f1f7dbce81b2	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	400fe42aaffa7c9fd40fadded6d2ac2e9f4fcbdaf1c5267274ba1769ec894e96	2026-12-21 22:09:52.947713+07	2026-11-21 22:35:11.75038+07	2026-11-21 23:10:56.595214+07	2026-11-21 22:09:52.947713+07
e3822e95-4120-4eb9-b94e-3ea01df1f177	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	4591e33f-be5d-4ea8-8c4a-38edfa8891d6	2026-11-21 16:59:56.416295+07	041fdde5ad5207ffeccedb3f8f705b17a3440bf9e9479dc181b56d2525248bd5	2026-12-21 23:10:38.208079+07	\N	2026-11-21 23:10:56.595214+07	2026-11-21 23:10:38.208079+07
5cb60d44-35fc-4049-956f-3f2941667519	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	e0de4d35c5e9796248010e38c7a479c139d40c2010ec6999925c8605c4c5f603	2026-12-22 13:10:48.703961+07	2026-11-23 09:25:48.533332+07	\N	2026-11-22 13:10:48.703961+07
77d8a28d-48a3-4739-afb1-254964d55604	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	d2a1ec1d68f494ff39b8f2e845b8a94b2145b45c6756faead8548dd0e1da80e4	2026-12-23 09:25:48.533332+07	2026-11-23 09:40:51.437026+07	\N	2026-11-23 09:25:48.533332+07
013baab3-d114-4e99-a40b-d5be534b3653	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	9a711fc72d88eb172d5df69536cebde8101d58bdfd09e9757de22a36d63dc9ae	2026-12-23 09:40:51.437026+07	2026-11-23 09:55:54.86278+07	\N	2026-11-23 09:40:51.437026+07
1d2ec4b7-e8ed-46ff-9b04-736797cc9c5a	1398ff97-2866-4c04-b061-7e7abf3d38e0	c082ed77-fcbc-4f78-ac41-21e939dd9009	2026-11-23 10:10:56.871189+07	2f197cbaaa4421c309e44fc3e6042ae36a74af1a919620bf2d059c184dffd1c0	2026-12-23 10:10:56.871189+07	\N	\N	2026-11-23 10:10:56.871189+07
8a88adf5-263b-43ea-8516-c8fbeca3569d	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	2fc650cb24eb658469fa6c1fc84015d38accd335c9410b5709af49c502fdf8c8	2026-12-23 09:55:54.86278+07	2026-11-23 10:10:57.947825+07	\N	2026-11-23 09:55:54.86278+07
1f469481-4b82-4668-924e-bad5d612c7f7	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	57decb74f587af4cafbd4a223a5abcf00a6e47789862bc79f255b2515a9689a2	2026-12-23 10:10:57.947825+07	2026-11-23 10:40:44.590629+07	\N	2026-11-23 10:10:57.947825+07
ecfa3926-aee4-4751-a7c7-d27b15fb6cf5	1398ff97-2866-4c04-b061-7e7abf3d38e0	d61cb85b-503d-41d7-8735-7c468ca8cf9f	2026-11-22 13:10:48.703961+07	27d72e9d8dfbe8604d6c057160dd35c4f5d47c6ac02d0837d749cf73aacf798e	2026-12-23 10:40:44.590629+07	\N	\N	2026-11-23 10:40:44.590629+07
a67a1764-c380-4ea3-9129-f97ba46b81a8	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	daf479ad72a92a656cf7dfbff06306cc03978b9ef7376080eae34b0453718558	2026-12-25 07:54:04.133525+07	2026-11-25 08:18:08.261713+07	\N	2026-11-25 07:54:04.133525+07
6aedfb35-5a94-49b4-a236-d891a8b98584	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	507a6e8f9f94fcf3b0368a0f8af2da94fbde33d6eea3be29d62680bd598040e6	2026-12-21 23:56:20.402231+07	2026-11-22 01:09:41.426476+07	2026-11-23 21:16:43.544739+07	2026-11-21 23:56:20.402231+07
11f6e148-4783-457f-b22b-5729a4c3d26c	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	3510b09ead3536397fc6feb17713b3745ae0a8b36c3c431c9afcc8fd7862f66f	2026-12-22 01:56:09.209596+07	2026-11-22 08:56:58.35426+07	2026-11-23 21:16:43.544739+07	2026-11-22 01:56:09.209596+07
91f69f00-4f63-473d-9a75-042526e31ec3	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	b290f3efa4775e4b545de0ccec24f364d91fafa1f32fa1fec3a001c304c27189	2026-12-22 08:56:58.35426+07	2026-11-22 11:18:53.523216+07	2026-11-23 21:16:43.544739+07	2026-11-22 08:56:58.35426+07
ba43fbd5-ca47-4217-b219-0701371c9216	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	4e2d6755141478963984f8f46c8f4bb3f2089b57e42b9acac951b173899bf881	2026-12-22 12:39:06.965379+07	2026-11-22 14:40:21.509435+07	2026-11-23 21:16:43.544739+07	2026-11-22 12:39:06.965379+07
bea68441-0d0d-4db0-b953-48a1f654eb8c	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	2ad39d14b754560ade8ee36b4092d904b6c99d27d71f2c79ffc1ee9a010b9cbe	2026-12-22 14:40:21.509435+07	2026-11-22 15:58:05.461341+07	2026-11-23 21:16:43.544739+07	2026-11-22 14:40:21.509435+07
3ee110b4-9efb-4ced-84f0-bcff86c46bd6	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	c53cc27f87fd823690325948de617691dea2c97bfd834468ee6c1616ae8af073	2026-12-22 21:22:58.607306+07	2026-11-22 22:33:26.722556+07	2026-11-23 21:16:43.544739+07	2026-11-22 21:22:58.607306+07
5ab6ce90-48bc-4e14-a1a8-2911a3aba65b	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	a0913913e1fb9fa6ea80a8fb39ce5a062267e578c1e7ff26a4ce99bd2fa22011	2026-12-21 23:34:15.93662+07	2026-11-21 23:56:20.402231+07	2026-11-23 21:16:43.544739+07	2026-11-21 23:34:15.93662+07
28d6858b-34c8-4af5-b68f-184376bab8da	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	1f88c57c42e6af20f38ecd265e02c6b7f59a14dc1819386522d8287cbad402ba	2026-12-22 01:09:41.426476+07	2026-11-22 01:56:09.209596+07	2026-11-23 21:16:43.544739+07	2026-11-22 01:09:41.426476+07
0b693212-16ce-4a58-8cbc-41aa92b2d079	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	801b4cb38a5d0a76aae711d7395f10dc73ed4856bbce617914a1e5112531b604	2026-12-22 11:18:53.523216+07	2026-11-22 12:39:06.965379+07	2026-11-23 21:16:43.544739+07	2026-11-22 11:18:53.523216+07
42dc87f4-6ada-4ed8-bdae-607f5f874a52	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	8b80e0c922bb56d4e0124faf9a44d358192b54eaa34b84406144398d9c996e0c	2026-12-22 15:58:05.461341+07	2026-11-22 21:22:58.607306+07	2026-11-23 21:16:43.544739+07	2026-11-22 15:58:05.461341+07
dd5daaaf-5df3-4c24-81ab-1e99dc9ee91e	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	5c05931203d8b7eb0236be0de7d8d605c824bace7699e99ee328f368e4ef11b2	2026-12-22 22:33:26.722556+07	2026-11-22 23:55:53.038383+07	2026-11-23 21:16:43.544739+07	2026-11-22 22:33:26.722556+07
dcfa51da-c3a4-431f-ad40-1d741365ea14	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	0f8ca8bfb7000f8649d4fbae5e2195505a436ec62962b87068dbbbfcb017bfbb	2026-12-22 23:55:53.038383+07	2026-11-23 08:12:10.073221+07	2026-11-23 21:16:43.544739+07	2026-11-22 23:55:53.038383+07
792d3007-2338-427a-8318-82b5b04ce1a9	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	d9e9e7e1273ee71a077a3d628a0271d9838964ffe10257c8418ad0af0519ea9b	2026-12-23 08:12:10.073221+07	2026-11-23 18:26:37.471603+07	2026-11-23 21:16:43.544739+07	2026-11-23 08:12:10.073221+07
dee21bb7-c6e0-49c0-ab4b-2730f0f49bba	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	aae368d4396bdbf0177471b669db554ddf5c0ce482b97eff4991816d16b59c37	2026-12-23 18:26:37.471603+07	2026-11-23 21:16:30.838137+07	2026-11-23 21:16:43.544739+07	2026-11-23 18:26:37.471603+07
7a7f72a3-6d79-4107-8b72-6053447299e2	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	bc677b68-8cb3-48f2-9640-d9e2385af0ab	2026-11-21 23:16:55.409715+07	287315321e7e2aafc0aa24092aa4bb3eed2e5d3c2aca8657db0e3d987c718a68	2026-12-23 21:16:30.838137+07	\N	2026-11-23 21:16:43.544739+07	2026-11-23 21:16:30.838137+07
38c59dbc-d34d-4417-bf2d-57e817050533	1398ff97-2866-4c04-b061-7e7abf3d38e0	5f483fa3-4195-4d43-9077-169914da4ead	2026-11-23 21:16:58.019558+07	c44905a7705c15f1501e415ad7c30a64936e35524d3af5d854b392f11539d0e6	2026-12-23 21:16:58.019558+07	\N	2026-11-23 21:28:47.379615+07	2026-11-23 21:16:58.019558+07
8e6b3dcc-4085-4712-be89-4adfbcc6d4dc	1398ff97-2866-4c04-b061-7e7abf3d38e0	95b327dd-92f5-4064-a1e5-c83253bcf319	2026-11-23 21:40:17.811648+07	5aa4db5bcf2db9d2a5027def1002d902e3dab83120f77c82e143a6cac9a96d85	2026-12-23 21:40:17.811648+07	\N	2026-11-23 21:40:45.721601+07	2026-11-23 21:40:17.811648+07
e8b1f4f1-402d-4e08-8779-d324bf35efd4	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	98eb758c5f463962c544305e27c43293f76b629e9e52f5648715ad208ef9491d	2026-12-23 21:28:55.506712+07	2026-11-23 21:44:47.559422+07	\N	2026-11-23 21:28:55.506712+07
d47d89ce-d27d-43c8-abf5-14fc1c6da4e8	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	2684592e02557444a3efa69483fb8a0e850eca9875c3e482a3e82ab80cc28b58	2026-12-23 21:44:47.559422+07	2026-11-23 21:44:47.806977+07	\N	2026-11-23 21:44:47.559422+07
a3d4e901-abeb-407a-99f2-bfe62729ad8a	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	de618b1161f971f78bad7c85190ff6752894e4f34b362e7155ce34603fa7b1f5	2026-12-23 21:44:47.806977+07	2026-11-24 15:53:55.979599+07	\N	2026-11-23 21:44:47.806977+07
51001376-e1aa-48e1-8552-0cd1f8bf6e40	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	cba964797bda9447319c32045bf57ae0b67c5ac48b82123cb066ba69a3a41de0	2026-12-24 15:53:55.979599+07	2026-11-24 20:04:22.251364+07	\N	2026-11-24 15:53:55.979599+07
54dbc532-7770-42a7-9ace-1eaaa9874e2f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	3da928a6e309244e68fc8563fbef94a896c0adce93f9cb235bb27fa22f7bed65	2026-12-24 20:04:22.251364+07	2026-11-24 20:58:36.181993+07	\N	2026-11-24 20:04:22.251364+07
c9e70b36-15ff-40ae-80fe-7e825ce9f78f	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	664fbef2e598c66b1abfb571e348c5fbee26ff19d94f3740e8a04ca7cdbe4dc1	2026-12-24 20:58:36.181993+07	2026-11-25 00:22:57.551305+07	\N	2026-11-24 20:58:36.181993+07
5d7a4ca1-83a8-41ba-a120-4305272847e4	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	70b3d6fe19cd368b43be2e405f42e5b26d6183722fc9e30d743fae8ac10b2908	2026-12-25 00:22:57.551305+07	2026-11-25 07:54:04.133525+07	\N	2026-11-25 00:22:57.551305+07
a0847bbd-8f2a-4e5e-af0f-f2a8d07663a2	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	7e64e533b1dc83cc5d466ad12530fdbea30e5f0a70b777a98aec92c5fd4cb5fa	2026-12-25 08:18:08.261713+07	2026-11-25 08:56:42.324872+07	\N	2026-11-25 08:18:08.261713+07
e1a667fa-5a21-4901-ab74-21719db18917	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	9661e813-7152-4fc2-b678-abe979caaa29	2026-11-23 21:28:55.506712+07	f851958117f03b9b868225c7e32b02030369770f5b30aa1c893669f37ace2557	2026-12-25 08:56:42.324872+07	\N	\N	2026-11-25 08:56:42.324872+07
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rooms (id, home_id, name, created_at, icon) FROM stdin;
ba900188-d4bf-4da5-99d5-f618d913485c	728b0ae0-61ca-498a-a580-8ed0c52dde5c	Phòng khách	2026-11-13 10:33:49.590503+07	\N
8c0a988f-b5cf-49ad-9528-56e9899ebcb0	728b0ae0-61ca-498a-a580-8ed0c52dde5c	Phòng ngủ	2026-11-13 10:33:49.598367+07	\N
171fb96c-0737-4a29-9c33-c1c0cc4e0c12	2efeb3d2-7c8e-4763-9a5f-5784853467cb	phòng khách	2026-11-13 11:00:08.703388+07	\N
4b06d730-f1a1-463d-a065-0617172efe37	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Phòng vệ sinh	2026-11-13 11:25:06.029556+07	\N
91ea803f-be1b-4266-b99a-5ce89acab422	2efeb3d2-7c8e-4763-9a5f-5784853467cb	phòng ngủ	2026-11-13 11:15:51.505416+07	\N
b315ab85-c840-4792-9179-50c80522490a	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Ban công	2026-11-14 07:54:11.166057+07	balcony
7810bf84-a854-4a1a-aed1-519f076c015d	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Bếp	2026-11-19 21:16:49.551139+07	kitchen
6d547385-b419-473c-bd16-8e597ae94a97	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Phòng khách	2026-11-20 17:34:30.351905+07	living
e04fb436-aee8-4c49-a368-d031775a4152	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Phòng ngủ	2026-11-20 17:34:31.053397+07	\N
8d8e4422-06a9-47a7-88ee-da2dedc1cc1b	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Phòng tắm	2026-11-20 17:34:31.704152+07	\N
0cdb8e7e-2d60-47bb-929d-c255bc51d771	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Ban công	2026-11-20 17:34:32.046766+07	balcony
\.


--
-- Data for Name: scenes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scenes (id, home_id, name, icon, actions, auto_enabled, auto_time, auto_days, last_run_at, last_status, created_at, alert_devices, auto_leave, speaker_ids, speak_text) FROM stdin;
b310ae31-4815-49f3-afca-338ab6bbddba	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Đi ngủ	bed	[{"payload": {"state": "OFF"}, "device_id": "6bad8227-ab69-4c75-90db-f31625b7f2e8"}, {"payload": {"state": "OFF"}, "device_id": "e7032d71-ca10-40c1-a394-2ae85e0d3876"}, {"payload": {"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}, "device_id": "3be4014d-efe5-43a5-9ea3-bfc8a227aafe"}]	f	\N	{1,2,3,4,5,6,7}	2026-11-21 09:17:47.314387+07	\N	2026-11-21 09:17:47.314387+07	{7243d86e-17a7-48d5-983a-b46987f0d06b}	f	{}	\N
86bca8b6-1d3e-45cc-ae15-1fb66fe734cf	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Về nhà	home	[{"payload": {"state": "ON"}, "device_id": "6bad8227-ab69-4c75-90db-f31625b7f2e8"}, {"payload": {"state": "ON"}, "device_id": "e7032d71-ca10-40c1-a394-2ae85e0d3876"}]	f	\N	{1,2,3,4,5,6,7}	2026-11-21 09:17:47.476477+07	\N	2026-11-21 09:17:47.476477+07	{}	f	{}	\N
d5869621-e101-4df0-b713-d53e0d594a5f	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Về nhà	home	[{"payload": {"state_1": "ON"}, "device_id": "672cc8fd-9b2c-402d-af29-7d2c0da7b15d"}, {"payload": {"state_1": "ON"}, "device_id": "c02a6a8e-fa64-4450-aebc-c216bf81316d"}]	f	18:00:00	{1,2,3,4,5,6,7}	2026-11-20 08:24:47.614623+07	\N	2026-11-20 08:24:47.614623+07	{}	f	{}	\N
48d3996a-4bb4-4134-aa64-2b7abed308a9	5572ca83-3a71-4ab9-a970-9fa7034ffc7d	Ra ngoài	away	[{"payload": {"state": "OFF"}, "device_id": "6bad8227-ab69-4c75-90db-f31625b7f2e8"}, {"payload": {"state": "OFF"}, "device_id": "cfc70a3e-3783-4ea3-a4cc-92f9d6cf314e"}, {"payload": {"state": "OFF"}, "device_id": "e7032d71-ca10-40c1-a394-2ae85e0d3876"}]	f	\N	{1,2,3,4,5,6,7}	2026-11-21 09:17:47.657401+07	\N	2026-11-21 09:17:47.657401+07	{129da822-b042-4ba8-8d6c-8088cf9aa672,7243d86e-17a7-48d5-983a-b46987f0d06b}	f	{}	\N
9e4852ed-e4ac-4423-8177-b904a0635d08	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Đi ngủ	bed	[{"payload": {"state": "OFF"}, "device_id": "2c50892d-29d3-48e2-9f82-d19d7c153b8e"}, {"payload": {"state_1": "OFF", "state_2": "OFF"}, "device_id": "672cc8fd-9b2c-402d-af29-7d2c0da7b15d"}, {"payload": {"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}, "device_id": "c02a6a8e-fa64-4450-aebc-c216bf81316d"}, {"payload": {"state_1": "OFF", "state_2": "OFF"}, "device_id": "1de602d8-fbb7-4675-966a-a66291cdc033"}, {"payload": {"state": "OFF"}, "device_id": "9ecd9ea0-2409-4a5e-ba9c-e194b277027d"}]	f	18:00:00	{1,2,3,4,5,6,7}	2026-11-22 11:20:50.246174+07	\N	2026-11-22 11:20:50.246174+07	{}	f	{}	\N
4c81b8a8-6123-4134-b8ce-a0be2b2500f3	2efeb3d2-7c8e-4763-9a5f-5784853467cb	Ra ngoài	away	[{"payload": {"state": "OFF"}, "device_id": "2c50892d-29d3-48e2-9f82-d19d7c153b8e"}, {"payload": {"state_1": "OFF", "state_2": "OFF"}, "device_id": "672cc8fd-9b2c-402d-af29-7d2c0da7b15d"}, {"payload": {"state_1": "OFF", "state_2": "OFF", "state_3": "OFF"}, "device_id": "c02a6a8e-fa64-4450-aebc-c216bf81316d"}, {"payload": {"state_1": "OFF", "state_2": "OFF"}, "device_id": "1de602d8-fbb7-4675-966a-a66291cdc033"}, {"payload": {"state": "OFF"}, "device_id": "9ecd9ea0-2409-4a5e-ba9c-e194b277027d"}]	f	18:00:00	{1,2,3,4,5,6,7}	2026-11-25 08:18:26.155318+07	\N	2026-11-20 08:23:17.985214+07	{092d9377-d458-4ac0-98a1-fcb1982508cf,aaad431d-119c-4a97-9ed0-ed5c152411b6}	t	{}	\N
\.


--
-- Data for Name: speakers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.speakers (id, home_id, name, cast_id, host, port, created_at, gateway_id) FROM stdin;
\.


--
-- Data for Name: tenant_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenant_members (tenant_id, user_id, role, created_at) FROM stdin;
911236fb-22ec-448b-a599-be539a6e8665	d90f5d76-5db4-4421-8e83-b2ff84049f92	owner	2026-11-13 10:33:49.551294+07
e665bb28-ac94-4a20-ad8a-33bf0c109fde	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	owner	2026-11-13 10:59:09.536163+07
aa0cab41-42bd-45f8-87da-dd066cb90080	1398ff97-2866-4c04-b061-7e7abf3d38e0	owner	2026-11-20 17:34:29.771848+07
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, created_at) FROM stdin;
911236fb-22ec-448b-a599-be539a6e8665	Khách hàng Demo	2026-11-13 10:33:49.551294+07
e665bb28-ac94-4a20-ad8a-33bf0c109fde	Gia đình quan ngguyen	2026-11-13 10:59:09.536163+07
d8f54e4d-99cb-4a37-be27-fa22eef15292	T	2026-11-13 14:05:40.303176+07
aa0cab41-42bd-45f8-87da-dd066cb90080	LD22808	2026-11-20 17:34:29.771848+07
\.


--
-- Data for Name: user_identities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_identities (provider, subject, user_id, email, created_at, last_login_at, apple_refresh_token, apple_client_id) FROM stdin;
google	109508801925385411665	ac1cf0b9-aa2c-4f49-b369-027b1a662deb	newmoon223107@gmail.com	2026-11-20 15:52:23.212335+07	2026-11-20 15:52:23.212335+07	\N	\N
google	113245904989169284874	feee6658-cda5-43b0-b70e-f38b39b592d4	luongthihue240601@gmail.com	2026-11-22 07:32:46.851772+07	2026-11-22 07:32:46.851772+07	\N	\N
google	110464254529249222057	1d25ddd9-f406-4cd1-a56b-9838d330d1f6	trongquan1297@gmail.com	2026-11-20 15:52:54.82654+07	2026-11-23 21:28:55.504084+07	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, created_at) FROM stdin;
d90f5d76-5db4-4421-8e83-b2ff84049f92	owner@example.com	$argon2id$v=19$m=19456,t=2,p=1$LxPtM6nC3KXksL/t+LCT2w$TsNPuUiJLTe5Cnr00Dt6Roa+ClQrJBN86Xt+KjdtimA	Chủ nhà	2026-11-13 10:33:49.473171+07
6a8de966-ee0f-41d9-ac99-79cdcfa18d61	stranger@example.com	$argon2id$v=19$m=19456,t=2,p=1$YcZ4gOnO/mjnHKwdbDhiaQ$3b4eT1xeLdTtHn5GwlVaoa5k8gvi2moyWzLd62m9Kx8	X	2026-11-13 10:34:04.550504+07
44fc6c0c-18d1-4558-a5fd-3beeeb073e22	quannt@blockchain.vn	$argon2id$v=19$m=19456,t=2,p=1$+kO15HNh26zUJACYKJGJhg$WuVZ0yL3DQMcOEbxvvDfVi17DR5tFpZpJnbzuFArifM	Quan	2026-11-13 13:47:28.832677+07
ac1cf0b9-aa2c-4f49-b369-027b1a662deb	newmoon223107@gmail.com		Nguyen Quan	2026-11-20 15:52:23.212335+07
1d25ddd9-f406-4cd1-a56b-9838d330d1f6	trongquan1297@gmail.com		quan ngguyen	2026-11-13 10:58:48.633017+07
1398ff97-2866-4c04-b061-7e7abf3d38e0	appreview@newmoon.cloud	$argon2id$v=19$m=19456,t=2,p=1$YonvdMz+cD0oU+MXV+pQ/Q$xPNaLViHjw2lYnGcWlGucRQ4+inALDq8kH/fj6kPzTY	Apple Review	2026-11-20 17:34:29.544127+07
feee6658-cda5-43b0-b70e-f38b39b592d4	luongthihue240601@gmail.com		Thị Huệ	2026-11-20 19:24:34.305902+07
\.


--
-- Name: command_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.command_log_id_seq', 631, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 3039, true);


--
-- Name: _sqlx_migrations _sqlx_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._sqlx_migrations
    ADD CONSTRAINT _sqlx_migrations_pkey PRIMARY KEY (version);


--
-- Name: cameras cameras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_pkey PRIMARY KEY (id);


--
-- Name: command_log command_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_log
    ADD CONSTRAINT command_log_pkey PRIMARY KEY (id);


--
-- Name: device_rules device_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_rules
    ADD CONSTRAINT device_rules_pkey PRIMARY KEY (id);


--
-- Name: devices devices_gateway_id_ieee_address_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_gateway_id_ieee_address_key UNIQUE (gateway_id, ieee_address);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: gateways gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_pkey PRIMARY KEY (id);


--
-- Name: gateways gateways_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_token_hash_key UNIQUE (token_hash);


--
-- Name: home_invites home_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_invites
    ADD CONSTRAINT home_invites_pkey PRIMARY KEY (token_hash);


--
-- Name: home_members home_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_members
    ADD CONSTRAINT home_members_pkey PRIMARY KEY (home_id, user_id);


--
-- Name: homes homes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homes
    ADD CONSTRAINT homes_pkey PRIMARY KEY (id);


--
-- Name: member_presence member_presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_presence
    ADD CONSTRAINT member_presence_pkey PRIMARY KEY (home_id, user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_codes oauth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_codes
    ADD CONSTRAINT oauth_codes_pkey PRIMARY KEY (code_hash);


--
-- Name: oauth_grants oauth_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_grants oauth_grants_refresh_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_refresh_hash_key UNIQUE (refresh_hash);


--
-- Name: oauth_tokens oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: pending_actions pending_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_actions
    ADD CONSTRAINT pending_actions_pkey PRIMARY KEY (rule_id);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_token_key UNIQUE (token);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: rooms rooms_home_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_home_id_name_key UNIQUE (home_id, name);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: scenes scenes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenes
    ADD CONSTRAINT scenes_pkey PRIMARY KEY (id);


--
-- Name: speakers speakers_home_id_cast_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_home_id_cast_id_key UNIQUE (home_id, cast_id);


--
-- Name: speakers speakers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_pkey PRIMARY KEY (id);


--
-- Name: tenant_members tenant_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_members
    ADD CONSTRAINT tenant_members_pkey PRIMARY KEY (tenant_id, user_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_identities user_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_identities
    ADD CONSTRAINT user_identities_pkey PRIMARY KEY (provider, subject);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cameras_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cameras_home_idx ON public.cameras USING btree (home_id);


--
-- Name: command_log_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX command_log_home_idx ON public.command_log USING btree (home_id, created_at DESC);


--
-- Name: device_rules_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_rules_home_idx ON public.device_rules USING btree (home_id);


--
-- Name: device_rules_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_rules_source_idx ON public.device_rules USING btree (source_device_id) WHERE (kind = 'link'::text);


--
-- Name: device_rules_timer_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX device_rules_timer_uq ON public.device_rules USING btree (device_id, key, kind) WHERE (kind <> 'link'::text);


--
-- Name: devices_gw_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_gw_name_idx ON public.devices USING btree (gateway_id, friendly_name);


--
-- Name: devices_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_home_idx ON public.devices USING btree (home_id);


--
-- Name: gateways_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gateways_home_idx ON public.gateways USING btree (home_id);


--
-- Name: home_members_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX home_members_user_idx ON public.home_members USING btree (user_id);


--
-- Name: homes_tenant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX homes_tenant_idx ON public.homes USING btree (tenant_id);


--
-- Name: notifications_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_home_idx ON public.notifications USING btree (home_id, created_at DESC);


--
-- Name: oauth_grants_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_grants_user_idx ON public.oauth_grants USING btree (user_id);


--
-- Name: oauth_tokens_grant_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX oauth_tokens_grant_idx ON public.oauth_tokens USING btree (grant_id);


--
-- Name: pending_actions_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pending_actions_due_idx ON public.pending_actions USING btree (due_at);


--
-- Name: push_tokens_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_tokens_user_idx ON public.push_tokens USING btree (user_id);


--
-- Name: refresh_tokens_expires_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_expires_idx ON public.refresh_tokens USING btree (expires_at);


--
-- Name: refresh_tokens_family_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_family_idx ON public.refresh_tokens USING btree (family_id);


--
-- Name: refresh_tokens_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: scenes_home_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scenes_home_idx ON public.scenes USING btree (home_id);


--
-- Name: scenes_one_auto_leave; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX scenes_one_auto_leave ON public.scenes USING btree (home_id) WHERE auto_leave;


--
-- Name: tenant_members_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tenant_members_user_idx ON public.tenant_members USING btree (user_id);


--
-- Name: user_identities_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_identities_user ON public.user_identities USING btree (user_id);


--
-- Name: users_email_lower_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_lower_uq ON public.users USING btree (lower(email));


--
-- Name: cameras cameras_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE CASCADE;


--
-- Name: cameras cameras_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: cameras cameras_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE SET NULL;


--
-- Name: command_log command_log_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_log
    ADD CONSTRAINT command_log_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: command_log command_log_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_log
    ADD CONSTRAINT command_log_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: command_log command_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.command_log
    ADD CONSTRAINT command_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: device_rules device_rules_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_rules
    ADD CONSTRAINT device_rules_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_rules device_rules_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_rules
    ADD CONSTRAINT device_rules_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: device_rules device_rules_source_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_rules
    ADD CONSTRAINT device_rules_source_device_id_fkey FOREIGN KEY (source_device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: devices devices_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE CASCADE;


--
-- Name: devices devices_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: devices devices_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE SET NULL;


--
-- Name: devices devices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: gateways gateways_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: gateways gateways_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: home_invites home_invites_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_invites
    ADD CONSTRAINT home_invites_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: home_invites home_invites_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_invites
    ADD CONSTRAINT home_invites_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: home_members home_members_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_members
    ADD CONSTRAINT home_members_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: home_members home_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_members
    ADD CONSTRAINT home_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: homes homes_active_scene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homes
    ADD CONSTRAINT homes_active_scene_id_fkey FOREIGN KEY (active_scene_id) REFERENCES public.scenes(id) ON DELETE SET NULL;


--
-- Name: homes homes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homes
    ADD CONSTRAINT homes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: member_presence member_presence_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_presence
    ADD CONSTRAINT member_presence_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: member_presence member_presence_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_presence
    ADD CONSTRAINT member_presence_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_camera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_camera_id_fkey FOREIGN KEY (camera_id) REFERENCES public.cameras(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_scene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_scene_id_fkey FOREIGN KEY (scene_id) REFERENCES public.scenes(id) ON DELETE SET NULL;


--
-- Name: oauth_codes oauth_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_codes
    ADD CONSTRAINT oauth_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_grants oauth_grants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_grants
    ADD CONSTRAINT oauth_grants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_tokens oauth_tokens_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_tokens
    ADD CONSTRAINT oauth_tokens_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.oauth_grants(id) ON DELETE CASCADE;


--
-- Name: pending_actions pending_actions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_actions
    ADD CONSTRAINT pending_actions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.device_rules(id) ON DELETE CASCADE;


--
-- Name: push_tokens push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rooms rooms_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: scenes scenes_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scenes
    ADD CONSTRAINT scenes_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: speakers speakers_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE SET NULL;


--
-- Name: speakers speakers_home_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_home_id_fkey FOREIGN KEY (home_id) REFERENCES public.homes(id) ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_members
    ADD CONSTRAINT tenant_members_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_members tenant_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_members
    ADD CONSTRAINT tenant_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_identities user_identities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_identities
    ADD CONSTRAINT user_identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict sl7bpm6AuhbGMjmzg31f71rcWbPceePSYiprj3DEssjbMvAd8m8Zc1dECMcAc1Z

